# -*- coding: utf-8 -*-
###################################################
# EStalker -> e2iplayer Host
# Reads portals / MAC / tokens from EStalker plugin path
# /etc/enigma2/estalker/e-portals-data.json
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, GetCookieDir
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps

from Components.config import config, ConfigText, ConfigSelection, getConfigListEntry
import os
import re
import hashlib
import time
import string
import random

try:
    from urllib.parse import quote, urlencode
except ImportError:
    from urllib import quote, urlencode

###################################################
# Paths of EStalker plugin
###################################################
ESTALKER_DIR = "/etc/enigma2/estalker/"
ESTALKER_JSON = os.path.join(ESTALKER_DIR, "e-portals-data.json")
# fallback older names
ESTALKER_JSON_OLD = os.path.join(ESTALKER_DIR, "playlists-data-2.json")

###################################################
# Optional override (if user wants manual portal)
###################################################
config.plugins.iptvplayer.stalker_timezone = ConfigText(default="Europe/London", fixed_size=False)
config.plugins.iptvplayer.stalker_manual_portal = ConfigText(default="", fixed_size=False)
config.plugins.iptvplayer.stalker_manual_mac = ConfigText(default="", fixed_size=False)


def GetConfigList():
    optionList = []
    optionList.append(getConfigListEntry(_("Timezone") + ":", config.plugins.iptvplayer.stalker_timezone))
    optionList.append(getConfigListEntry(_("Manual Portal (optional override)") + ":", config.plugins.iptvplayer.stalker_manual_portal))
    optionList.append(getConfigListEntry(_("Manual MAC (optional override)") + ":", config.plugins.iptvplayer.stalker_manual_mac))
    return optionList


def gettytul():
    return 'EStalker (from plugin)'


class Stalker(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'estalker', 'cookie': 'estalker.cookie'})
        self.MAIN_URL = ''
        self.DEFAULT_ICON_URL = ''
        self.portal = ''
        self.mac = ''
        self.token = ''
        self.token_random = ''
        self.play_token = ''
        self.force_ch_link_check = '0'
        self.current_playlist = None   # full playlist_info dict from EStalker
        self.playlists = []            # all playlists loaded from EStalker

        self.HTTP_HEADER = {
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
            'X-User-Agent': 'Model: MAG250; Link: WiFi',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'Close',
            'Pragma': 'no-cache',
        }

    # ------------------------------------------------------------------
    # Load portals from EStalker plugin
    # ------------------------------------------------------------------
    def _load_estalker_playlists(self):
        """Read e-portals-data.json from EStalker"""
        self.playlists = []
        json_path = ESTALKER_JSON
        if not os.path.isfile(json_path):
            json_path = ESTALKER_JSON_OLD
        if not os.path.isfile(json_path):
            printDBG('EStalker JSON not found: %s' % ESTALKER_JSON)
            return False

        try:
            with open(json_path, 'r') as f:
                data = json_loads(f.read())
            if isinstance(data, list):
                self.playlists = data
            printDBG('Loaded %d playlists from EStalker' % len(self.playlists))
            return len(self.playlists) > 0
        except Exception as e:
            printDBG('Error loading EStalker JSON: %s' % str(e))
            printExc()
            return False

    def _get_playlist_display_name(self, pl):
        info = pl.get('playlist_info', {})
        alias = info.get('alias', '').strip()
        mac = info.get('mac', '')
        domain = info.get('domain', '') or info.get('host', '')
        if alias:
            return '%s  [%s]' % (alias, domain)
        return '%s  [%s]' % (mac, domain)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _normalize_mac(self, mac):
        if not mac:
            return ''
        mac = mac.strip().upper().replace('-', ':').replace('.', ':')
        clean = mac.replace(':', '')
        if re.match(r'^[0-9A-F]{12}$', clean):
            if ':' not in mac:
                mac = ':'.join(clean[i:i + 2] for i in range(0, 12, 2))
            return mac
        return ''

    def _build_headers(self):
        encoded_mac = quote(self.mac, safe='')
        encoded_tz = quote(config.plugins.iptvplayer.stalker_timezone.value or 'Europe/London', safe='')
        headers = dict(self.HTTP_HEADER)
        headers['Cookie'] = 'mac={}; stb_lang=en; timezone={}'.format(encoded_mac, encoded_tz)
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
            headers['Cookie'] += '; token=' + self.token
        return headers

    def _api(self, params, method='GET'):
        if not self.portal:
            return None
        url = self.portal
        if not url.endswith('?'):
            url = url.rstrip('/') + '?'
        headers = self._build_headers()
        try:
            if method.upper() == 'GET':
                query = urlencode(params)
                full_url = url + query
                sts, data = self.cm.getPage(full_url, {'header': headers})
            else:
                sts, data = self.cm.getPage(url, {'header': headers}, post_data=params)

            if not sts or not data:
                printDBG('Stalker API failed action=%s' % params.get('action'))
                return None
            try:
                j = json_loads(data)
            except Exception:
                return None
            if isinstance(j, dict):
                return j.get('js')
            return None
        except Exception:
            printExc()
            return None

    # ------------------------------------------------------------------
    # Auth (reuse token from EStalker if available)
    # ------------------------------------------------------------------
    def _handshake(self):
        printDBG('Stalker._handshake')
        self.token = ''
        self.token_random = ''

        params = {
            'type': 'stb',
            'action': 'handshake',
            'token': '',
            'prehash': '0',
            'JsHttpRequest': '1-xml'
        }
        js = self._api(params)
        if not js:
            params['mac'] = self.mac
            js = self._api(params)

        if not js or not isinstance(js, dict):
            return False

        token = js.get('token')
        self.token_random = js.get('random', '')

        if not token and 'missing' in str(js.get('msg', '')).lower():
            fake = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(32))
            prehash = hashlib.sha1(fake.encode()).hexdigest()
            # temporary header with fake token
            old = self.token
            self.token = fake
            params = {
                'type': 'stb',
                'action': 'handshake',
                'JsHttpRequest': '1-xml',
                'mac': self.mac,
                'prehash': prehash
            }
            js = self._api(params)
            self.token = old
            if js and isinstance(js, dict):
                token = js.get('token')
                self.token_random = js.get('random', '')

        if not token:
            return False
        self.token = token
        return True

    def _get_profile(self):
        printDBG('Stalker._get_profile')
        sn = hashlib.md5(self.mac.encode()).hexdigest().upper()[:13]
        device_id = hashlib.sha256(self.mac.encode()).hexdigest().upper()
        hw_version_2 = hashlib.sha1(self.mac.encode()).hexdigest()
        prehash = hashlib.sha1((sn + self.mac).encode()).hexdigest()
        signature2 = hashlib.sha256((device_id + device_id).encode()).hexdigest().upper()
        timestamp = str(int(time.time()))

        metrics = {
            'mac': self.mac,
            'sn': sn,
            'model': 'MAG250',
            'type': 'STB',
            'uid': '',
            'random': self.token_random or ''
        }
        metrics_json = quote(json_dumps(metrics, separators=(',', ':')))

        params = {
            'type': 'stb',
            'action': 'get_profile',
            'JsHttpRequest': '1-xml',
            'hd': '1',
            'ver': 'ImageDescription: 0.2.18-r23-250; ImageDate: Thu Sep 13 11:31:16 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c',
            'num_banks': '2',
            'sn': sn,
            'stb_type': 'MAG250',
            'client_type': 'STB',
            'image_version': '218',
            'video_out': 'hdmi',
            'device_id': device_id,
            'device_id2': device_id,
            'signature': signature2,
            'auth_second_step': '1',
            'hw_version': '1.7-BD-00',
            'not_valid_token': '0',
            'metrics': metrics_json,
            'hw_version_2': hw_version_2,
            'timestamp': timestamp,
            'api_signature': '262',
            'prehash': prehash,
        }
        js = self._api(params)
        if not js or not isinstance(js, dict) or not js.get('id'):
            params = {
                'type': 'stb',
                'action': 'get_profile',
                'JsHttpRequest': '1-xml',
                'sn': sn,
                'device_id': '',
                'timestamp': timestamp,
            }
            js = self._api(params)

        if not js or not isinstance(js, dict):
            return False

        self.play_token = js.get('play_token')
        self.force_ch_link_check = str(js.get('force_ch_link_check', '0'))
        return True

    def _setup_from_playlist(self, pl):
        """Set portal/mac/token from one EStalker playlist entry"""
        info = pl.get('playlist_info', {})
        self.current_playlist = pl

        # Manual override first
        manual_portal = config.plugins.iptvplayer.stalker_manual_portal.value.strip()
        manual_mac = self._normalize_mac(config.plugins.iptvplayer.stalker_manual_mac.value)
        if manual_portal and manual_mac:
            self.portal = manual_portal
            self.mac = manual_mac
            self.token = ''
            self.token_random = ''
        else:
            self.mac = self._normalize_mac(info.get('mac', ''))
            self.portal = (info.get('portal') or '').strip()
            self.token = info.get('token', '') or ''
            self.token_random = info.get('token_random', '') or ''
            self.play_token = info.get('play_token', '') or ''
            self.force_ch_link_check = str(info.get('force_ch_link_check', '0'))

            # if portal empty → build from host + path_prefix
            if not self.portal:
                host = info.get('host') or info.get('domain') or ''
                path_prefix = info.get('path_prefix', '')
                protocol = info.get('protocol', 'http://')
                if host:
                    if path_prefix:
                        self.portal = protocol + host.rstrip('/') + '/' + path_prefix.strip('/') + '/server/load.php'
                    else:
                        # try common paths
                        self.portal = protocol + host.rstrip('/') + '/c/portal.php'

        if not self.portal or not self.mac:
            return False

        self.MAIN_URL = self.portal
        printDBG('Using portal=%s mac=%s token=%s' % (self.portal, self.mac, bool(self.token)))

        # if we already have a valid token from EStalker → try to use it
        if self.token:
            # quick check: try a light request
            test = self._api({'type': 'stb', 'action': 'get_profile', 'JsHttpRequest': '1-xml'})
            if test and isinstance(test, dict) and test.get('id'):
                printDBG('Reusing token from EStalker')
                return True
            # token expired → re-auth
            self.token = ''

        if not self._handshake():
            return False
        if not self._get_profile():
            return False
        return True

    def _ensure_auth(self):
        if self.portal and self.mac and self.token:
            return True
        # will be set when user selects a portal
        return False

    # ------------------------------------------------------------------
    # create_link
    # ------------------------------------------------------------------
    def _create_link(self, cmd, content_type='itv'):
        if not cmd:
            return None
        if str(cmd).startswith('/media/') and 'file_' not in str(cmd):
            cmd = cmd.replace('/media/', '/media/file_')

        # catchup uses type=tv_archive
        api_type = content_type
        if content_type in ('tv_archive', 'catchup', 'archive'):
            api_type = 'tv_archive'

        params = {
            'type': api_type,
            'action': 'create_link',
            'cmd': cmd,
            'series': '',
            'forced_storage': '',
            'disable_ad': '0',
            'download': '0',
            'force_ch_link_check': self.force_ch_link_check or '0',
            'JsHttpRequest': '1-xml'
        }
        js = self._api(params)
        if js and isinstance(js, dict):
            link = js.get('cmd')
            if link:
                if link.startswith('ffmpeg '):
                    link = link[7:].strip()
                # replace %mac% placeholder if present
                if '%mac%' in link.lower():
                    link = re.sub(r'%mac%', self.mac, link, flags=re.IGNORECASE)
                return link
        return None

    # ------------------------------------------------------------------
    # Menus
    # ------------------------------------------------------------------
    def listMainMenu(self, cItem):
        printDBG('Stalker.listMainMenu')
        self.playlists = []
        if not self._load_estalker_playlists():
            self.addDir({
                'category': 'info',
                'title': _('No portals found in EStalker'),
                'desc': _('Make sure EStalker plugin is installed and you have added portals.\nPath: %s') % ESTALKER_JSON
            })
            # still allow manual
            if config.plugins.iptvplayer.stalker_manual_portal.value and config.plugins.iptvplayer.stalker_manual_mac.value:
                self.addDir({
                    'category': 'select_portal',
                    'title': _('Use Manual Portal (from settings)'),
                    'playlist_idx': -1
                })
            return

        for idx, pl in enumerate(self.playlists):
            info = pl.get('playlist_info', {})
            name = self._get_playlist_display_name(pl)
            status = info.get('status', 0)
            expiry = info.get('expiry', '')
            desc = ''
            if expiry:
                desc = _('Expiry: %s') % expiry
            if status:
                desc += ' | status=%s' % status

            self.addDir({
                'category': 'select_portal',
                'title': name,
                'desc': desc,
                'playlist_idx': idx,
                'icon': self.DEFAULT_ICON_URL
            })

    def listAfterSelect(self, cItem):
        """After user chooses a portal → show Live / VOD / Series"""
        idx = cItem.get('playlist_idx', -1)

        if idx == -1:
            # manual
            fake_pl = {'playlist_info': {
                'portal': config.plugins.iptvplayer.stalker_manual_portal.value.strip(),
                'mac': config.plugins.iptvplayer.stalker_manual_mac.value.strip()
            }}
            ok = self._setup_from_playlist(fake_pl)
        else:
            if idx < 0 or idx >= len(self.playlists):
                self._load_estalker_playlists()
            if idx < 0 or idx >= len(self.playlists):
                self.addDir({'category': 'info', 'title': _('Invalid portal index')})
                return
            ok = self._setup_from_playlist(self.playlists[idx])

        if not ok:
            self.addDir({
                'category': 'info',
                'title': _('Authentication failed'),
                'desc': _('Portal or MAC invalid / handshake failed')
            })
            return

        MAIN_CAT_TAB = [
            {'category': 'live_genres', 'title': _('Live TV'), 'playlist_idx': idx},
            {'category': 'vod_categories', 'title': _('VOD / Movies'), 'playlist_idx': idx},
            {'category': 'series_categories', 'title': _('Series'), 'playlist_idx': idx},
            {'category': 'catchup_channels', 'title': _('Catchup / Archive'), 'playlist_idx': idx},
            {'category': 'ipa_menu', 'title': _('IPAudioPro export'), 'playlist_idx': idx},
            {'category': 'search', 'title': _('Search'), 'search_item': True, 'playlist_idx': idx},
            {'category': 'search_history', 'title': _('Search history')},
        ]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listLiveGenres(self, cItem):
        printDBG('Stalker.listLiveGenres')
        if not self._ensure_auth():
            # re-setup if needed
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        params = {'type': 'itv', 'action': 'get_genres', 'JsHttpRequest': '1-xml'}
        js = self._api(params)
        if not js:
            return

        genres = js if isinstance(js, list) else (js.get('data') or js.get('genres') or [])
        if not genres and isinstance(js, dict):
            genres = list(js.values()) if js else []

        self.addDir({
            'category': 'live_channels',
            'title': _('All Channels'),
            'genre': '*',
            'playlist_idx': cItem.get('playlist_idx', 0)
        })

        for g in genres:
            if not isinstance(g, dict):
                continue
            title = g.get('title') or g.get('name') or g.get('genre') or ''
            gid = g.get('id') or g.get('genre_id') or g.get('cid') or ''
            if not title:
                continue
            self.addDir({
                'category': 'live_channels',
                'title': title,
                'genre': str(gid),
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listLiveChannels(self, cItem):
        printDBG('Stalker.listLiveChannels')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        genre = cItem.get('genre', '*')
        page = cItem.get('page', 1)

        if genre == '*':
            params = {
                'type': 'itv',
                'action': 'get_all_channels',
                'sortby': 'name',
                'JsHttpRequest': '1-xml'
            }
        else:
            params = {
                'type': 'itv',
                'action': 'get_ordered_list',
                'genre': genre,
                'sortby': 'name',
                'p': str(page),
                'force_ch_link_check': self.force_ch_link_check or '0',
                'JsHttpRequest': '1-xml'
            }

        js = self._api(params)
        if not js:
            return

        data = js.get('data') if isinstance(js, dict) else js
        if not isinstance(data, list):
            data = []

        for ch in data:
            if not isinstance(ch, dict):
                continue
            name = ch.get('name') or ch.get('title') or ''
            cmd = ch.get('cmd') or ''
            logo = ch.get('logo') or ch.get('logo_url') or ''
            if not name:
                continue
            url = 'stalker://live/' + str(ch.get('id', '')) + '|' + str(cmd)
            self.addVideo({
                'title': name,
                'url': url,
                'icon': logo,
                'cmd': cmd,
                'content_type': 'itv'
            })

        total = js.get('total_items') if isinstance(js, dict) else 0
        try:
            total = int(total)
        except Exception:
            total = 0
        if total and page * 14 < total:
            self.addDir({
                'category': 'live_channels',
                'title': _('Next page'),
                'genre': genre,
                'page': page + 1,
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listVodCategories(self, cItem):
        printDBG('Stalker.listVodCategories')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        params = {'type': 'vod', 'action': 'get_categories', 'JsHttpRequest': '1-xml'}
        js = self._api(params)
        if not js:
            return

        cats = js if isinstance(js, list) else (js.get('data') or [])
        for c in cats:
            if not isinstance(c, dict):
                continue
            title = c.get('title') or c.get('category_name') or c.get('name') or ''
            cid = c.get('id') or c.get('category_id') or ''
            if not title:
                continue
            self.addDir({
                'category': 'vod_list',
                'title': title,
                'cat_id': str(cid),
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listVod(self, cItem):
        printDBG('Stalker.listVod')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        cat_id = cItem.get('cat_id', '*')
        page = cItem.get('page', 1)

        params = {
            'type': 'vod',
            'action': 'get_ordered_list',
            'category': cat_id,
            'sortby': 'added',
            'p': str(page),
            'JsHttpRequest': '1-xml'
        }
        js = self._api(params)
        if not js:
            return

        data = js.get('data') if isinstance(js, dict) else []
        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get('name') or item.get('title') or ''
            cmd = item.get('cmd') or ''
            logo = item.get('screenshot_uri') or item.get('logo') or ''
            if not name:
                continue
            url = 'stalker://vod/' + str(item.get('id', '')) + '|' + str(cmd)
            self.addVideo({
                'title': name,
                'url': url,
                'icon': logo,
                'cmd': cmd,
                'content_type': 'vod',
                'desc': item.get('description') or item.get('year') or ''
            })

        total = js.get('total_items') if isinstance(js, dict) else 0
        try:
            total = int(total)
        except Exception:
            total = 0
        if total and page * 14 < total:
            self.addDir({
                'category': 'vod_list',
                'title': _('Next page'),
                'cat_id': cat_id,
                'page': page + 1,
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listSeriesCategories(self, cItem):
        printDBG('Stalker.listSeriesCategories')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        params = {'type': 'series', 'action': 'get_categories', 'JsHttpRequest': '1-xml'}
        js = self._api(params)
        if not js:
            params['type'] = 'vod'
            js = self._api(params)
        if not js:
            return

        cats = js if isinstance(js, list) else (js.get('data') or [])
        for c in cats:
            if not isinstance(c, dict):
                continue
            title = c.get('title') or c.get('category_name') or c.get('name') or ''
            cid = c.get('id') or c.get('category_id') or ''
            if not title:
                continue
            self.addDir({
                'category': 'series_list',
                'title': title,
                'cat_id': str(cid),
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listSeries(self, cItem):
        printDBG('Stalker.listSeries')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        cat_id = cItem.get('cat_id', '*')
        page = cItem.get('page', 1)

        params = {
            'type': 'series',
            'action': 'get_ordered_list',
            'category': cat_id,
            'sortby': 'added',
            'p': str(page),
            'JsHttpRequest': '1-xml'
        }
        js = self._api(params)
        if not js:
            return

        data = js.get('data') if isinstance(js, dict) else []
        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get('name') or item.get('title') or ''
            cmd = item.get('cmd') or ''
            logo = item.get('screenshot_uri') or item.get('logo') or ''
            if not name:
                continue
            self.addDir({
                'category': 'series_seasons',
                'title': name,
                'cmd': cmd,
                'series_id': str(item.get('id', '')),
                'icon': logo,
                'desc': item.get('description') or '',
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

        total = js.get('total_items') if isinstance(js, dict) else 0
        try:
            total = int(total)
        except Exception:
            total = 0
        if total and page * 14 < total:
            self.addDir({
                'category': 'series_list',
                'title': _('Next page'),
                'cat_id': cat_id,
                'page': page + 1,
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listSeriesSeasons(self, cItem):
        printDBG('Stalker.listSeriesSeasons')
        if not self._ensure_auth():
            return
        # simplified: treat as playable for now
        self.addVideo({
            'title': cItem.get('title', '') + ' - Play',
            'url': 'stalker://series/' + cItem.get('series_id', '') + '|' + cItem.get('cmd', ''),
            'cmd': cItem.get('cmd', ''),
            'content_type': 'series',
            'icon': cItem.get('icon', '')
        })


    # ------------------------------------------------------------------
    # IPAudioPro export (same path/format as Xtream2Audio plugin)
    # ------------------------------------------------------------------
    def _ipa_paths(self):
        return (
            "/etc/enigma2/IPAudioPro.json",
            "/etc/IPAudioPro.json",
            "/hdd/IPAudioPro.json",
            "/tmp/IPAudioPro.json",
        )

    def _ipa_find_file(self):
        for p in self._ipa_paths():
            if os.path.isfile(p):
                return p
        return self._ipa_paths()[0]

    def _ipa_load_all(self):
        data = {"Playlist": {"streams": []}}
        path = None
        for p in self._ipa_paths():
            if os.path.isfile(p):
                path = p
                break
        if not path:
            return data
        try:
            with open(path, "r") as f:
                content = f.read().strip()
            if not content:
                return data
            raw = json_loads(content)
            if isinstance(raw, dict):
                data = raw
            if "Playlist" not in data or not isinstance(data.get("Playlist"), dict):
                data["Playlist"] = {"streams": []}
            if "streams" not in data["Playlist"] or not isinstance(data["Playlist"]["streams"], list):
                data["Playlist"]["streams"] = []
        except Exception:
            printExc()
        return data

    def _ipa_write(self, data):
        text = json_dumps(data, indent=4)
        for path in self._ipa_paths():
            try:
                d = os.path.dirname(path)
                if d and not os.path.isdir(d):
                    os.makedirs(d)
                with open(path, "w") as f:
                    f.write(text)
                printDBG("IPAudioPro wrote %s" % path)
                return path
            except Exception as e:
                printDBG("IPAudioPro write fail %s: %s" % (path, str(e)))
        return None

    def _ipa_add_streams(self, streams, group=None):
        data = self._ipa_load_all()
        if group:
            data[group] = {"streams": list(streams)}
            target = data[group]["streams"]
        else:
            if "Playlist" not in data or not isinstance(data["Playlist"], dict):
                data["Playlist"] = {"streams": []}
            if not isinstance(data["Playlist"].get("streams"), list):
                data["Playlist"]["streams"] = []
            target = data["Playlist"]["streams"]
            existing = set()
            for s in target:
                if isinstance(s, dict) and s.get("url"):
                    existing.add(s["url"])
            for s in streams:
                u = s.get("url")
                if u and u not in existing:
                    target.append(s)
                    existing.add(u)
        path = self._ipa_write(data)
        return path, len(target)

    def listIpaMenu(self, cItem):
        idx = cItem.get("playlist_idx", 0)
        self.addDir({
            "category": "ipa_export_all",
            "title": _("Export ALL Live → IPAudioPro (Playlist)"),
            "playlist_idx": idx,
            "desc": _("Appends into Playlist.streams like Xtream2Audio"),
        })
        self.addDir({
            "category": "ipa_export_all_group",
            "title": _("Export ALL Live as new group"),
            "playlist_idx": idx,
        })
        self.addDir({
            "category": "ipa_export_genres",
            "title": _("Export by genre → IPAudioPro"),
            "playlist_idx": idx,
        })
        path = self._ipa_find_file()
        data = self._ipa_load_all()
        groups = list(data.keys())
        n = 0
        try:
            n = len(data.get("Playlist", {}).get("streams", []))
        except Exception:
            pass
        self.addDir({
            "category": "info",
            "title": _("File: %s") % path,
            "desc": _("Groups: %s | Playlist streams: %d") % (", ".join(groups), n),
        })

    def listIpaGenres(self, cItem):
        if not self._ensure_auth():
            idx = cItem.get("playlist_idx", 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return
        params = {"type": "itv", "action": "get_genres", "JsHttpRequest": "1-xml"}
        js = self._api(params)
        if not js:
            self.addDir({"category": "info", "title": _("No genres")})
            return
        genres = js if isinstance(js, list) else (js.get("data") or js.get("genres") or [])
        for g in genres:
            if not isinstance(g, dict):
                continue
            title = g.get("title") or g.get("name") or g.get("genre") or ""
            gid = g.get("id") or g.get("genre_id") or g.get("cid") or ""
            if not title:
                continue
            self.addDir({
                "category": "ipa_export_genre",
                "title": title,
                "genre": str(gid),
                "playlist_idx": cItem.get("playlist_idx", 0),
            })

    def doIpaExport(self, cItem, genre=None, as_group=False):
        if not self._ensure_auth():
            idx = cItem.get("playlist_idx", 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                self.addDir({"category": "info", "title": _("Auth failed")})
                return

        if genre and genre != "*":
            params = {
                "type": "itv",
                "action": "get_ordered_list",
                "genre": genre,
                "sortby": "name",
                "p": "1",
                "JsHttpRequest": "1-xml",
            }
        else:
            params = {
                "type": "itv",
                "action": "get_all_channels",
                "sortby": "name",
                "JsHttpRequest": "1-xml",
            }
        js = self._api(params)
        if not js:
            self.addDir({"category": "info", "title": _("No channels from API")})
            return
        data = js.get("data") if isinstance(js, dict) else js
        if not isinstance(data, list):
            data = []

        streams = []
        for ch in data:
            if not isinstance(ch, dict):
                continue
            name = ch.get("name") or ch.get("title") or ""
            cmd = ch.get("cmd") or ""
            if not name:
                continue
            url = None
            if "://" in str(cmd):
                url = str(cmd)
            elif cmd:
                url = self._create_link(cmd, "itv")
            if not url:
                continue
            if url.startswith("ffmpeg "):
                url = url[7:].strip()
            streams.append({"name": name, "display_name": name, "url": url})

        if not streams:
            self.addDir({"category": "info", "title": _("0 streams to export")})
            return

        group = None
        if as_group or (genre and genre != "*"):
            mac = self.mac or "portal"
            if genre and genre != "*":
                group = "EStalker %s - %s" % (mac, cItem.get("title") or genre)
            else:
                group = "EStalker %s" % mac

        path, total = self._ipa_add_streams(streams, group=group)
        if path:
            self.addDir({
                "category": "info",
                "title": _("OK: %d streams (total in target %d)") % (len(streams), total),
                "desc": path + ((" [" + group + "]") if group else " [Playlist]"),
            })
        else:
            self.addDir({
                "category": "info",
                "title": _("FAILED to write IPAudioPro file"),
                "desc": ", ".join(self._ipa_paths()),
            })

    # ------------------------------------------------------------------
    # Catchup / Archive (Stalker)
    # ------------------------------------------------------------------
    def listCatchupChannels(self, cItem):
        printDBG('Stalker.listCatchupChannels')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        # get all channels and filter those with archive
        params = {
            'type': 'itv',
            'action': 'get_all_channels',
            'JsHttpRequest': '1-xml'
        }
        js = self._api(params)
        if not js:
            return

        data = js.get('data') if isinstance(js, dict) else js
        if not isinstance(data, list):
            data = []

        for ch in data:
            if not isinstance(ch, dict):
                continue
            archive = str(ch.get('archive', ch.get('tv_archive', '0'))).lower()
            if archive not in ('1', 'true', 'yes'):
                continue
            name = ch.get('name') or ch.get('title') or ''
            ch_id = ch.get('id') or ch.get('ch_id') or ''
            cmd = ch.get('cmd') or ''
            logo = ch.get('logo') or ch.get('logo_url') or ''
            duration = ch.get('tv_archive_duration') or ch.get('archive_duration') or ''
            if not name or not ch_id:
                continue
            self.addDir({
                'category': 'catchup_epg',
                'title': name,
                'ch_id': str(ch_id),
                'cmd': cmd,
                'icon': logo,
                'playlist_idx': cItem.get('playlist_idx', 0),
                'desc': _('Archive duration: %s') % duration if duration else ''
            })

    def listCatchupEPG(self, cItem):
        printDBG('Stalker.listCatchupEPG')
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        ch_id = cItem.get('ch_id', '')
        if not ch_id:
            return

        # request EPG simple data table for today and previous days
        from datetime import datetime, timedelta
        today = datetime.now().date()
        for day_offset in range(0, 8):  # last 7 days + today
            d = today - timedelta(days=day_offset)
            date_value = d.strftime('%Y-%m-%d')
            params = {
                'type': 'epg',
                'action': 'get_simple_data_table',
                'ch_id': ch_id,
                'date': date_value,
                'JsHttpRequest': '1-xml'
            }
            js = self._api(params)
            if not js:
                continue

            programmes = []
            if isinstance(js, dict):
                programmes = js.get('data') or []
            elif isinstance(js, list):
                programmes = js

            if not isinstance(programmes, list):
                continue

            for prog in programmes:
                if not isinstance(prog, dict):
                    continue
                # prefer archive-marked items
                mark = str(prog.get('mark_archive', prog.get('has_archive', '0'))).lower()
                # still show if we have cmd / id
                title = prog.get('name') or prog.get('title') or _('Unknown')
                time_str = prog.get('time') or prog.get('t_time') or prog.get('start') or ''
                duration = prog.get('duration') or ''
                cmd = prog.get('cmd') or prog.get('real_id') or prog.get('id') or ''
                event_id = prog.get('id') or prog.get('real_id') or ''
                descr = prog.get('descr') or prog.get('description') or ''

                if not cmd and not event_id:
                    continue

                display = title
                if time_str:
                    display = '[%s %s] %s' % (date_value, time_str, title)

                # store enough info for create_link
                self.addVideo({
                    'title': display,
                    'url': 'stalker://catchup/%s|%s' % (ch_id, cmd),
                    'icon': cItem.get('icon', ''),
                    'cmd': str(cmd),
                    'content_type': 'tv_archive',
                    'ch_id': ch_id,
                    'event_id': str(event_id),
                    'archive_date': date_value,
                    'desc': descr
                })

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG('Stalker.listSearchResult [%s]' % searchPattern)
        if not self._ensure_auth():
            idx = cItem.get('playlist_idx', 0)
            if self.playlists and idx < len(self.playlists):
                self._setup_from_playlist(self.playlists[idx])
            if not self._ensure_auth():
                return

        params = {
            'type': 'itv',
            'action': 'get_ordered_list',
            'search': searchPattern,
            'JsHttpRequest': '1-xml'
        }
        js = self._api(params)
        if not js:
            return
        data = js.get('data') if isinstance(js, dict) else []
        for ch in data:
            if not isinstance(ch, dict):
                continue
            name = ch.get('name') or ''
            cmd = ch.get('cmd') or ''
            if not name:
                continue
            self.addVideo({
                'title': name,
                'url': 'stalker://live/search|' + str(cmd),
                'cmd': cmd,
                'content_type': 'itv',
                'icon': ch.get('logo', '')
            })

    # ------------------------------------------------------------------
    # getLinksForVideo
    # ------------------------------------------------------------------
    def getLinksForVideo(self, cItem):
        printDBG('Stalker.getLinksForVideo [%s]' % cItem)
        linksTab = []

        if not self._ensure_auth():
            # try last known playlist
            if self.playlists:
                self._setup_from_playlist(self.playlists[0])
            if not self._ensure_auth():
                return linksTab

        cmd = cItem.get('cmd', '')
        content_type = cItem.get('content_type', 'itv')

        if not cmd and '|' in cItem.get('url', ''):
            cmd = cItem['url'].split('|', 1)[-1]

        if not cmd:
            return linksTab

        need_create = (
            content_type in ('tv_archive', 'catchup', 'archive') or
            '://' not in str(cmd) or
            self.force_ch_link_check == '1' or
            str(cmd).startswith('/media/') or
            str(cmd).startswith('ffrt')
        )

        stream = None
        if need_create:
            stream = self._create_link(cmd, content_type)
        else:
            stream = cmd

        if stream:
            if stream.startswith('ffmpeg '):
                stream = stream[7:].strip()
            headers = self._build_headers()
            stream = strwithmeta(stream, {
                'User-Agent': headers.get('User-Agent', ''),
                'Cookie': headers.get('Cookie', '')
            })
            linksTab.append({'name': 'Stalker Stream', 'url': stream, 'need_resolve': 0})

        return linksTab

    # ------------------------------------------------------------------
    # handleService
    # ------------------------------------------------------------------
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('Stalker.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get('name', '')
        category = self.currItem.get('category', '')

        self.currList = []

        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'select_portal':
            self.listAfterSelect(self.currItem)
        elif category == 'live_genres':
            self.listLiveGenres(self.currItem)
        elif category == 'live_channels':
            self.listLiveChannels(self.currItem)
        elif category == 'vod_categories':
            self.listVodCategories(self.currItem)
        elif category == 'vod_list':
            self.listVod(self.currItem)
        elif category == 'series_categories':
            self.listSeriesCategories(self.currItem)
        elif category == 'series_list':
            self.listSeries(self.currItem)
        elif category == 'series_seasons':
            self.listSeriesSeasons(self.currItem)
        elif category == 'catchup_channels':
            self.listCatchupChannels(self.currItem)
        elif category == 'catchup_epg':
            self.listCatchupEPG(self.currItem)
        elif category == 'ipa_menu':
            self.listIpaMenu(self.currItem)
        elif category == 'ipa_export_genres':
            self.listIpaGenres(self.currItem)
        elif category == 'ipa_export_all':
            self.doIpaExport(self.currItem, genre=None, as_group=False)
        elif category == 'ipa_export_all_group':
            self.doIpaExport(self.currItem, genre=None, as_group=True)
        elif category == 'ipa_export_genre':
            self.doIpaExport(self.currItem, genre=self.currItem.get('genre'), as_group=True)
        elif category in ['search', 'search_next_page']:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == 'search_history':
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _('Type: '))
        elif category == 'info':
            pass
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, Stalker(), True, [])
