# -*- coding: utf-8 -*-
#########################################################
# E2iPlayer Host for Shoffree (https://shoffree.cc/) - migrated from .sbs
# VERSION MARKER: shoffree-v6-2026-07-26
# (decrypts streem/watch payload, follows movie "watch now"
#  link, uses gettytul()/IPTVHost, no strify/BoundingCoord/
#  getDirectM3U8TSRoutes imports)
#########################################################
###################################################
# LOCAL import
###################################################
# localization library
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
# host main class
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
# tools - write on log, write exception infos
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc
# library for json (instead of standard json.loads)
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads
###################################################
# FOREIGN import
###################################################
import re
import base64
###################################################


def GetConfigList():
    return []


def gettytul():
    return 'https://shoffree.cc/'  # main url of host


class Shoffree(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'Shoffree', 'cookie': 'shoffree.cookie'})
        self.MAIN_URL = gettytul()
        self.DEFAULT_ICON_URL = 'https://shoffree.cc/assets/images/180_shoffree.png'
        self.HEADER = self.cm.getDefaultHeader(browser='chrome')
        self.defaultParams = {
            'header': self.HEADER,
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': True,
            'cookiefile': self.COOKIE_FILE
        }

    def getPage(self, baseUrl, addParams=None, post_data=None):
        if addParams is None:
            addParams = dict(self.defaultParams)
        return self.cm.getPage(baseUrl, addParams, post_data)

    ###################################################
    # MAIN MENU
    ###################################################
    def listMainMenu(self, cItem):
        printDBG('Shoffree.listMainMenu')

        MAIN_CAT_TAB = [
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u064f\u0636\u0627\u0641 \u062d\u062f\u064a\u062b\u0627\u064b'), 'url': self.getFullUrl('recent')},
            {'category': 'list_items', 'title': _('\u0623\u062d\u062f\u062b \u0627\u0644\u062d\u0644\u0642\u0627\u062a'), 'url': self.getFullUrl('episodes')},
            {'category': 'list_items', 'title': _('\u0628\u062b \u0645\u0628\u0627\u0634\u0631'), 'url': self.getFullUrl('live')},
            {'category': 'list_items', 'title': _('\u062a\u062d\u0645\u064a\u0644 \u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0643\u0627\u0645\u0644\u0629'), 'url': self.getFullUrl('fullseries')},
            {'category': 'list_items', 'title': _('\u0631\u0645\u0636\u0627\u0646 \u0645\u0639\u0646\u0627'), 'url': self.getFullUrl('ramadan')},
            {'category': 'list_items', 'title': _('\u0645\u0635\u0627\u0631\u0639\u0629 \u062d\u0631\u0629'), 'url': self.getFullUrl('wrestling')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u0633\u0631\u062d\u064a\u0627\u062a'), 'url': self.getFullUrl('theater')},
            {'category': 'list_items', 'title': _('\u0623\u0646\u0645\u064a \u0648\u0643\u0631\u062a\u0648\u0646'), 'url': self.getFullUrl('anime')},
            {'category': 'sub_movies', 'title': _('\u0627\u0644\u0623\u0641\u0644\u0627\u0645')},
            {'category': 'sub_series', 'title': _('\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a')},
        ] + self.searchItems()

        self.listsTab(MAIN_CAT_TAB, cItem)

        self.MOVIES_CAT_TAB = [
            {'category': 'list_items', 'title': _('\u0627\u0644\u0623\u0641\u0644\u0627\u0645 \u0627\u0644\u0639\u0631\u0628\u064a\u0629'), 'url': self.getFullUrl('movies/arabic')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0623\u0641\u0644\u0627\u0645 \u0627\u0644\u0623\u062c\u0646\u0628\u064a\u0629'), 'url': self.getFullUrl('movies/english')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0623\u0641\u0644\u0627\u0645 \u0627\u0644\u062a\u0631\u0643\u064a\u0629'), 'url': self.getFullUrl('movies/turkish')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0623\u0641\u0644\u0627\u0645 \u0627\u0644\u0647\u0646\u062f\u064a\u0629'), 'url': self.getFullUrl('movies/indian')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0623\u0641\u0644\u0627\u0645 \u0627\u0644\u0643\u0648\u0631\u064a\u0629'), 'url': self.getFullUrl('movies/korean')},
            {'category': 'list_items', 'title': _('\u0623\u0641\u0644\u0627\u0645 \u0627\u0644\u0623\u0646\u0645\u064a'), 'url': self.getFullUrl('movies/anime')},
        ]

        self.SERIES_CAT_TAB = [
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0627\u0644\u0639\u0631\u0628\u064a\u0629'), 'url': self.getFullUrl('series/arabic')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0627\u0644\u0623\u062c\u0646\u0628\u064a\u0629'), 'url': self.getFullUrl('series/english')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0627\u0644\u062a\u0631\u0643\u064a\u0629'), 'url': self.getFullUrl('series/turkish')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0627\u0644\u0647\u0646\u062f\u064a\u0629'), 'url': self.getFullUrl('series/indian')},
            {'category': 'list_items', 'title': _('\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0627\u0644\u0643\u0648\u0631\u064a\u0629'), 'url': self.getFullUrl('series/korean')},
        ]

    def listSubMovies(self, cItem):
        printDBG('Shoffree.listSubMovies')
        self.listsTab(self.MOVIES_CAT_TAB, cItem)

    def listSubSeries(self, cItem):
        printDBG('Shoffree.listSubSeries')
        self.listsTab(self.SERIES_CAT_TAB, cItem)

    ###################################################
    # LIST ITEMS (WITH PAGINATION)
    ###################################################
    def listItems(self, cItem):
        printDBG('Shoffree.listItems url[%s]' % cItem['url'])
        url = cItem['url']
        page = cItem.get('page', 1)

        sts, data = self.getPage(url)
        if not sts or not data:
            printDBG('listItems: failed to load page')
            return

        # Extract items from video-card articles
        articles = re.findall(r'<article\b[^>]*class="[^"]*video-card[^"]*"[^>]*>', data)

        items = []
        for art in articles:
            title_m = re.search(r'data-title="([^"]+)"', art)
            url_m = re.search(r'data-url="([^"]+)"', art)
            thumb_m = re.search(r'data-thumb="([^"]+)"', art)
            if title_m and url_m:
                items.append((
                    title_m.group(1),
                    url_m.group(1),
                    thumb_m.group(1) if thumb_m else ''
                ))

        if not items:
            # Theater/wrestling-style pages: no data-* attributes, items are
            # plain <a href="..." title="..." ...> <img src="...">
            bookmark_items = re.findall(
                r'<a href="([^"]+)" title="([^"]+)"[^>]*>\s*<img src="([^"]+)"',
                data
            )
            items = [(title, href, thumb) for href, title, thumb in bookmark_items]

        if items:
            for title, item_url, thumb in items:
                params = dict(cItem)
                params.update({
                    'category': 'list_qualities',
                    'title': title,
                    'url': self.getFullUrl(item_url),
                    'icon': thumb,
                    'desc': title,
                })
                self.addDir(params)
        else:
            # Fallback: Schema JSON-LD
            json_match = re.search(r'<script type="application/ld\+json">(.*?)</script>', data, re.DOTALL)
            if json_match:
                try:
                    js_data = json_loads(json_match.group(1))
                    graph = js_data.get('@graph', [])
                    for g in graph:
                        if g.get('@type') == 'CollectionPage':
                            itemList = g.get('mainEntity', {}).get('itemListElement', [])
                            for elem in itemList:
                                item = elem.get('item', {})
                                title = item.get('name', '')
                                item_url = item.get('url', '')
                                thumb = item.get('image', '')
                                desc = item.get('description', '') or title
                                if item_url:
                                    params = dict(cItem)
                                    params.update({
                                        'category': 'list_qualities',
                                        'title': title,
                                        'url': item_url,
                                        'icon': thumb,
                                        'desc': desc,
                                    })
                                    self.addDir(params)
                except Exception:
                    printExc()

        # Pagination
        # The site's pagination links use single-quoted attributes, e.g.:
        # <a href='.../page/2' class='page-link' onclick='event.preventDefault(); loadContent(2);'>2</a>
        # We read the target page number straight out of loadContent(N) so
        # this works regardless of the link's visible text (number, "next",
        # "prev", arrows, etc.) or which quote style is used.
        page_links = {}
        for pm in re.finditer(
            r"<a\s+href=[\"']([^\"']+)[\"'][^>]*page-link[^>]*loadContent\((\d+)\)",
            data
        ):
            href, pg = pm.group(1), int(pm.group(2))
            page_links[pg] = href

        next_url = page_links.get(page + 1)
        if not next_url:
            # Fallback for older/different quote styles
            next_match = re.search(r'<a[^>]*href="([^"]+)"[^>]*>\u0627\u0644\u062a\u0627\u0644\u064a &raquo;</a>', data)
            if next_match:
                next_url = next_match.group(1)

        if next_url:
            params = dict(cItem)
            params.update({
                'category': 'list_items',
                'title': _('\u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u062a\u0627\u0644\u064a\u0629 >>'),
                'url': self.getFullUrl(next_url),
                'page': page + 1,
            })
            self.addDir(params)

        if page > 1:
            prev_url = page_links.get(page - 1)
            if not prev_url:
                # Build it from the current url by adjusting the /page/N segment
                if re.search(r'/page/\d+', url):
                    prev_url = re.sub(r'/page/\d+', '/page/%d' % (page - 1), url)
                else:
                    prev_url = url
            params = dict(cItem)
            params.update({
                'category': 'list_items',
                'title': _('\u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629 <<'),
                'url': self.getFullUrl(prev_url),
                'page': page - 1,
            })
            self.addDir(params)

    ###################################################
    # EPISODE LIST (for series root pages like /serie/ID/slug)
    ###################################################
    def _listEpisodesFromData(self, cItem, data):
        # Series root pages (e.g. /serie/ID/slug) use this markup:
        episodes = re.findall(
            r'<a href="([^"]+)"[^>]*class="ep-shoffree-card[^"]*"[^>]*data-num="(\d+)"[^>]*>.*?<span class="ep-title-label">([^<]*)</span>',
            data, re.DOTALL
        )
        if episodes:
            for ep_url, ep_num, ep_title in episodes:
                params = dict(cItem)
                params.update({
                    'category': 'list_qualities',
                    'title': ep_title.strip() or ('Episode %s' % ep_num),
                    'url': self.getFullUrl(ep_url),
                    'desc': ep_title.strip(),
                })
                self.addDir(params)
            return True

        # Some watch-page sidebars use this alternate markup instead:
        episodes = re.findall(
            r'<a href="([^"]+)"[^>]*class="playlist-item"[^>]*data-ep-id="(\d+)"[^>]*data-ep="(\d+)"[^>]*>.*?<h4>([^<]*)</h4>',
            data
        )
        if not episodes:
            return False

        for ep_url, ep_id, ep_num, ep_title in episodes:
            params = dict(cItem)
            params.update({
                'category': 'list_qualities',
                'title': ep_title.strip() or ('Episode %s' % ep_num),
                'url': self.getFullUrl(ep_url),
                'desc': ep_title.strip(),
            })
            self.addDir(params)
        return True

    ###################################################
    # DECRYPT THE inline CONFIG/RAWDATA BLOCK
    # Some watch pages (mainly series episodes) embed the server list
    # directly via a similar XOR scheme (hex XOR straight to JSON, no
    # base64 layer this time): (function(a,b,c){...})("KEY","HEX1","HEX2")
    # HEX1 decrypts to a "config" object, HEX2 to a "rawData" array of
    # {name, url} server entries - no AJAX call needed at all.
    ###################################################
    def _decryptConfigRawData(self, data):
        m = re.search(
            r"\(function\([^)]*\)\s*\{.*?String\['fromCharCode'\].*?\}\)\(\"([^\"]+)\",\s*\"([^\"]+)\",\s*\"([^\"]+)\"\)",
            data, re.DOTALL
        )
        if not m:
            return None, None
        key, hex1, hex2 = m.group(1), m.group(2), m.group(3)

        def xor_json(hexstr):
            try:
                pairs = re.findall('..', hexstr)
                chars = [chr(int(hp, 16) ^ ord(key[i % len(key)])) for i, hp in enumerate(pairs)]
                return json_loads(''.join(chars))
            except Exception:
                return None

        config = xor_json(hex1)
        raw_data = xor_json(hex2)
        return config, raw_data

    ###################################################
    # DECRYPT THE OBFUSCATED "streem/watch" PLAYER PAGE
    # The page ships an XOR+Base64 encrypted blob that a browser
    # decrypts client-side with JS and document.write()s. We replicate
    # that here in pure Python so we can read the real embed HTML.
    ###################################################
    def _decryptStreemPayload(self, data):
        m = re.search(r'\(function\s*\(_key,\s*_payload\)\s*\{.*?\}\)\("([^"]+)",\s*"([^"]+)"\)', data, re.DOTALL)
        if not m:
            return None
        key = m.group(1)
        payload = m.group(2)
        try:
            hex_pairs = re.findall('..', payload)
            out = bytearray()
            klen = len(key)
            for i, hp in enumerate(hex_pairs):
                out.append(int(hp, 16) ^ ord(key[i % klen]))
            b64_str = out.decode('latin1')
            raw = base64.b64decode(b64_str)
            return raw.decode('utf-8', errors='replace')
        except Exception:
            printExc()
            return None

    def _resolveMoreServerUrl(self, url):
        # topcinemaa play.php?to=HOST/PATH just wraps the real embed url
        m = re.search(r'[?&]to=([^&]+)', url)
        if m:
            target = m.group(1)
            if not target.startswith('http'):
                target = 'https://' + target
            return target
        return url

    ###################################################
    # QUALITIES / SERVERS FOR A SINGLE VIDEO
    ###################################################
    def listQualities(self, cItem):
        printDBG('Shoffree.listQualities [%s]' % cItem['url'])
        url = cItem['url']

        sts, data = self.getPage(url)
        if not sts or not data:
            printDBG('listQualities: failed to load page')
            return

        # Series root pages (e.g. /serie/10357/slug) are info/episode-list
        # pages, not watch pages - they have no servers of their own. If we
        # can see an episode playlist on this page, show that list first
        # instead of treating it as a (non-existent) direct video.
        if ('ep-shoffree-card' in data or 'playlist-item' in data) and '/watch/' not in url:
            if self._listEpisodesFromData(cItem, data):
                return

        # Strategy 1: some watch pages (mainly series episodes) embed an
        # encrypted server list directly - no streem/watch hop or AJAX
        # call needed at all if this decrypts successfully.
        config, raw_data = self._decryptConfigRawData(data)
        if isinstance(raw_data, list) and raw_data:
            found_any = False
            for srv in raw_data:
                if not isinstance(srv, dict):
                    continue
                srv_url = self._resolveMoreServerUrl(srv.get('url', ''))
                if not srv_url:
                    continue
                title = srv.get('name') or _('Server')
                params = dict(cItem)
                params.update({'category': 'video', 'title': title, 'url': srv_url})
                self.addVideo(params)
                found_any = True
            if found_any:
                return

        # Strategy 2: if we at least decrypted a config block, it tells us
        # exactly how to build the streem/watch URL (no need to guess via
        # regex on the page - the site builds this URL in JS by string
        # concatenation, so it never appears literally in the HTML).
        forced_stream_url = None
        if isinstance(config, dict) and config.get('Domain_local') and config.get('type_item') and config.get('id_item') and config.get('currentId'):
            forced_stream_url = '%s%s/%s/%s' % (
                config['Domain_local'], config['type_item'], config['id_item'], config['currentId']
            )

        current_url = url
        current_data = data
        stream_iframe = None
        tried_tokens = set()

        if forced_stream_url:
            stream_iframe = True  # sentinel: skip the discovery hop loop below
            stream_url_override = self.getFullUrl(forced_stream_url)
        else:
            stream_url_override = None

        for _hop in range(4):
            if stream_iframe:
                break
            stream_iframe = re.search(r'src="([^"]*streem/watch/[^"]+)"', current_data)
            if not stream_iframe:
                stream_iframe = re.search(r'href="([^"]*streem/watch/[^"]+)"', current_data)
            if not stream_iframe:
                stream_iframe = re.search(r'(https?://[^\s"\'<>]*streem/watch/[^\s"\'<>]+)', current_data)
            if stream_iframe:
                break

            # Not found yet: look for a "watch now" link to a /watch/... page
            # and follow it (movie detail pages link out to a separate watch
            # page instead of embedding the streem iframe directly).
            watch_link = re.search(r'href="([^"]*/watch/[^"]+)"[^>]*rel="watch"', current_data)
            if not watch_link:
                watch_link = re.search(r'rel="watch"[^>]*href="([^"]*/watch/[^"]+)"', current_data)
            if not watch_link:
                watch_link = re.search(r'href="([^"]*/watch/(?:movie|serie)/[^"]+)"', current_data)
            if not watch_link:
                # Current site markup: no rel="watch" and no /movie|serie/
                # segment - just a play-glow button, e.g.
                # <a href="https://site/watch/lockbox-2026" ... class="action-btn play-glow">
                watch_link = re.search(r'<a href="([^"]*/watch/[^"]+)"[^>]*class="[^"]*play-glow[^"]*"', current_data)
            if watch_link:
                next_url = self.getFullUrl(watch_link.group(1))
                if next_url != current_url:
                    current_url = next_url
                    sts_hop, current_data = self.getPage(current_url)
                    if not sts_hop or not current_data:
                        current_data = ''
                        break
                    continue

            # Some pages (theater/wrestling) show a "fake player" that only
            # reveals the real streem iframe after POSTing the item's
            # key_token back to the same page (a click-to-play unlock).
            token_m = re.search(r'name="key_token"\s+value="(\d+)"', current_data)
            if token_m and token_m.group(1) not in tried_tokens:
                tried_tokens.add(token_m.group(1))
                sts_hop, unlocked_data = self.getPage(current_url, dict(self.defaultParams), {'key_token': token_m.group(1)})
                if sts_hop and unlocked_data:
                    current_data = unlocked_data
                    continue

            break

        if not stream_iframe:
            params = dict(cItem)
            params.update({'category': 'video', 'title': _('Direct Link'), 'url': url})
            self.addVideo(params)
            return

        stream_url = stream_url_override if stream_url_override else self.getFullUrl(stream_iframe.group(1))
        sts2, sdata = self.getPage(stream_url)
        if not sts2 or not sdata:
            printDBG('listQualities: failed to load stream page %s' % stream_url)
            return

        decrypted = self._decryptStreemPayload(sdata)

        found_any = False

        if decrypted:
            key_m = re.search(r"const\s+KEY\s*=\s*'([^']+)'", decrypted)
            if key_m:
                api_key = key_m.group(1)
                api_url = stream_url.replace('watch', 'sources', 1)

                header = dict(self.HEADER)
                header['Content-Type'] = 'application/x-www-form-urlencoded'
                header['X-Requested-With'] = 'XMLHttpRequest'
                ajax_params = dict(self.defaultParams)
                ajax_params['header'] = header

                for server_num in range(1, 7):
                    post_data = {'key': api_key, 'server': server_num}
                    sts3, jdata = self.getPage(api_url, ajax_params, post_data)
                    if not sts3 or not jdata:
                        continue
                    try:
                        j = json_loads(jdata)
                    except Exception:
                        continue

                    if j.get('server_status') == 'online' and j.get('sources'):
                        for src in j.get('sources', []):
                            src_url = src.get('file') if isinstance(src, dict) else src
                            label = src.get('label', '') if isinstance(src, dict) else ''
                            if not src_url:
                                continue
                            title = 'Shoffree Server %d' % server_num
                            if label:
                                title += ' - %s' % label
                            params = dict(cItem)
                            params.update({'category': 'video', 'title': title, 'url': src_url})
                            self.addVideo(params)
                            found_any = True
                        continue

                    if j.get('status') == 'error' and j.get('message') == 'Server not found':
                        more_servers = j.get('more_server')
                        if more_servers:
                            for srv in more_servers:
                                srv_url = self._resolveMoreServerUrl(srv.get('url', ''))
                                if not srv_url:
                                    continue
                                title = srv.get('name') or _('Server')
                                params = dict(cItem)
                                params.update({'category': 'video', 'title': title, 'url': srv_url})
                                self.addVideo(params)
                                found_any = True
                            break
                        # else: try next server_num
                        continue

        if not found_any:
            # Fallback: legacy plain-text scan, in case a page isn't
            # encrypted this way (older/different content types).
            servers = re.findall(
                r'(https?://[^\s"\'<>]+(?:streamwish|topcinemaa|earnvids|vidhide|dood|mixdrop)[^\s"\'<>]+)',
                sdata
            )
            m3u8_links = re.findall(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', sdata)

            for mlink in m3u8_links:
                params = dict(cItem)
                params.update({'category': 'video', 'title': 'M3U8 Direct Stream', 'url': mlink})
                self.addVideo(params)
                found_any = True

            for s_url in sorted(set(servers)):
                s_url = self._resolveMoreServerUrl(s_url)
                try:
                    name = 'Server: ' + s_url.split('/')[2]
                except IndexError:
                    name = 'Server'
                params = dict(cItem)
                params.update({'category': 'video', 'title': name, 'url': s_url})
                self.addVideo(params)
                found_any = True

        if not found_any:
            printDBG('listQualities: no servers resolved for %s' % stream_url)

    def exploreItems(self, cItem):
        printDBG('Shoffree.exploreItems [%s]' % cItem['url'])
        url = cItem['url']

        if 'streamwish' in url or 'topcinemaa' in url:
            sts, data = self.getPage(url)
            if sts and data:
                m3u8 = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', data)
                if m3u8:
                    params = dict(cItem)
                    params.update({'category': 'video', 'title': cItem.get('title', 'Shoffree'), 'url': m3u8.group(1)})
                    self.addVideo(params)
                    return

        # Otherwise fall back to the video page as a playable item for resolving
        params = dict(cItem)
        params.update({'category': 'video', 'title': cItem.get('title', 'Shoffree'), 'url': url})
        self.addVideo(params)

    ###################################################
    # GET LINKS FOR VIDEO
    ###################################################
    def getLinksForVideo(self, cItem):
        printDBG('Shoffree.getLinksForVideo [%s]' % cItem)
        urlTab = []
        url = cItem.get('url', '')
        if not url:
            return urlTab

        # These sources come straight from the site's own JSON API and are
        # already final, playable file URLs - no further resolving needed.
        # (Previously only .m3u8 was treated this way, so direct .mp4
        # download links - e.g. from downet.net - were incorrectly sent
        # through the generic host resolver, which doesn't know that host
        # and so produced nothing playable.)
        direct_exts = ('.m3u8', '.mp4', '.mkv', '.ts', '.avi', '.mov', '.webm')
        url_clean = url.split('?', 1)[0].split('#', 1)[0]
        if url_clean.lower().endswith(direct_exts):
            return [{'name': 'Shoffree', 'url': url, 'need_resolve': 0}]

        return self.up.getVideoLinkExt(url)

    def getVideoLinks(self, url):
        printDBG('Shoffree.getVideoLinks [%s]' % url)
        urlTab = []
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return urlTab

    ###################################################
    # SEARCH
    ###################################################
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG('Shoffree.listSearchResult searchPattern[%s]' % searchPattern)
        cItem = dict(cItem)
        cItem['url'] = self.getFullUrl('search?query=%s' % searchPattern)
        cItem['category'] = 'list_items'
        self.listItems(cItem)

    ###################################################
    # DISPATCH
    ###################################################
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('Shoffree.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get('name', '')
        category = self.currItem.get('category', '')
        printDBG('handleService: >> name[%s], category[%s]' % (name, category))

        self.currList = []

        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'sub_movies':
            self.listSubMovies(self.currItem)
        elif category == 'sub_series':
            self.listSubSeries(self.currItem)
        elif category == 'list_items':
            self.listItems(self.currItem)
        elif category == 'list_qualities':
            self.listQualities(self.currItem)
        elif category == 'explore_item':
            self.exploreItems(self.currItem)
        elif category in ('search', 'search_next_page'):
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == 'search_history':
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _('Type: '))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, Shoffree(), True, [])

    def withArticleContent(self, cItem):
        if 'video' == cItem.get('category', ''):
            return True
        return False
