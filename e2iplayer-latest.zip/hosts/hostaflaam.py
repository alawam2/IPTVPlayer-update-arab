# -*- coding: utf-8 -*-
# Last Modified: 2026-07-23 - Fully E2iPlayer Compatible (Unicode Safe & Reorganized)
# Host for Aflaam - E2iPlayer / Enigma2

from __future__ import unicode_literals
import re

from Plugins.Extensions.IPTVPlayer.components.ihost import CBaseHostClass, CHostBase
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc


def GetConfigList():
    return []


def gettytul():
    return "https://aflaam.com/"


class Aflaam(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {"history": "Aflaam"})
        self.HTTP_HEADER = self.cm.getDefaultHeader(browser="firefox")
        self.defaultParams = {"header": self.HTTP_HEADER}
        self.MAIN_URL = gettytul()
        self.DEFAULT_ICON_URL = self.getFullUrl("style/assets/images/logo.png")
        
        # 1. القائمة الرئيسية تحتوي فقط على قسم الأفلام والمسلسلات والبحث (مترجمة عبر E2iPlayer)
        self.MENU = [
            {"category": "movies_menu", "title": _("Movies"), "icon": self.DEFAULT_ICON_URL},
            {"category": "series_menu", "title": _("Series"), "icon": self.DEFAULT_ICON_URL},
        ] + self.searchItems()

    def getPage(self, baseUrl, addParams=None, post_data=None):
        if addParams is None:
            addParams = dict(self.defaultParams)
        return self.cm.getPage(baseUrl, addParams, post_data)

    def listMoviesMenu(self, cItem):
        printDBG("Aflaam.listMoviesMenu |%s|" % cItem)
        url = self.getFullUrl("movies")
        
        # 1. جميع الأفلام
        params = dict(cItem)
        params.update({"good_for_fav": True, "category": "list_items", "title": _("Movies") + " - " + _("All"), "url": url})
        self.addDir(params)
        
        # 2. الأقسام (عربي / أجنبي / هندي)
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Categories"), "url": url, "s": u"\u0627\u0644\u0642\u0633\u0645"})
        self.addDir(params)
        
        # 3. التصنيفات
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Genres"), "url": url, "s": u"\u0627\u0644\u062a\u0635\u0646\u064a\u0641"})
        self.addDir(params)
        
        # 4. سنة الإنتاج
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Year"), "url": url, "s": u"\u0633\u0646\u0629"})
        self.addDir(params)
        
        # 5. التقييم
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Rating"), "url": url, "s": u"\u0627\u0644\u062a\u0642\u064a\u064a\u0645"})
        self.addDir(params)
        
        # 6. الجودة
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Quality"), "url": url, "s": u"\u0627\u0644\u062c\u0648\u062f\u0629"})
        self.addDir(params)

    def listSeriesMenu(self, cItem):
        printDBG("Aflaam.listSeriesMenu |%s|" % cItem)
        url = self.getFullUrl("series")
        
        # 1. جميع المسلسلات
        params = dict(cItem)
        params.update({"good_for_fav": True, "category": "list_items", "title": _("Series") + " - " + _("All"), "url": url})
        self.addDir(params)
        
        # 2. الأقسام (عربي / أجنبي / هندي)
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Categories"), "url": url, "s": u"\u0627\u0644\u0642\u0633\u0645"})
        self.addDir(params)
        
        # 3. التصنيفات
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Genres"), "url": url, "s": u"\u0627\u0644\u062a\u0635\u0646\u064a\u0641"})
        self.addDir(params)
        
        # 4. سنة الإنتاج
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Year"), "url": url, "s": u"\u0633\u0646\u0629"})
        self.addDir(params)
        
        # 5. التقييم
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Rating"), "url": url, "s": u"\u0627\u0644\u062a\u0642\u064a\u064a\u0645"})
        self.addDir(params)
        
        # 6. الجودة
        params = dict(cItem)
        params.update({"category": "list_value", "title": _("Quality"), "url": url, "s": u"\u0627\u0644\u062c\u0648\u062f\u0629"})
        self.addDir(params)

    def listValue(self, cItem):
        printDBG("Aflaam.listValue |%s|" % cItem)
        url = cItem.get("url", self.MAIN_URL).replace('&amp;', '&')
        sts, data = self.getPage(url)
        if not sts:
            return
        
        s_marker = cItem.get("s", "")
        
        # البحث في وسوم HTML بحماية من اختلاف الرموز
        subData = self.cm.ph.getAllItemsBeetwenMarkers(data, s_marker, "</ul>")
        if not subData:
            alt_markers = [
                u"\u0627\u0644\u0623\u0642\u0633\u0627\u0645", # الأقسام
                u"\u0627\u0644\u062a\u0635\u0646\u064a\u0641\u0627\u062a", # التصنيفات
                u"\u0633\u0646\u0629 \u0627\u0644\u0625\u0646\u062a\u0627\u062c" # سنة الإنتاج
            ]
            for alt in alt_markers:
                subData = self.cm.ph.getAllItemsBeetwenMarkers(data, alt, "</ul>")
                if subData:
                    break

        if not subData:
            stsMain, dataMain = self.getPage(self.MAIN_URL)
            if stsMain and s_marker:
                subData = self.cm.ph.getAllItemsBeetwenMarkers(dataMain, s_marker, "</ul>")

        if subData:
            items = re.findall(r'href="([^"]+)".*?>([^<]+)', subData[0], re.DOTALL)
            for itemUrl, title in items:
                cleanTitle = self.cleanHtmlStr(title)
                if not cleanTitle:
                    continue
                cleanUrl = self.getFullUrl(itemUrl.replace('&amp;', '&'))
                params = dict(cItem)
                params.update({
                    "good_for_fav": True,
                    "category": "list_items",
                    "title": cleanTitle,
                    "url": cleanUrl
                })
                if "s" in params:
                    del params["s"]
                self.addDir(params)

    def listItems(self, cItem):
        printDBG("Aflaam.listItems |%s|" % cItem)
        pageUrl = cItem["url"].replace('&amp;', '&')
        sts, data = self.getPage(pageUrl)
        if not sts:
            return

        # 1. جلب عناصر القائمة بواسطة وسوم مرنة
        dataItems = self.cm.ph.getAllItemsBeetwenMarkers(data, 'entry-box', '</h')
        if not dataItems:
            dataItems = self.cm.ph.getAllItemsBeetwenMarkers(data, 'entry-box', '</div>')
        if not dataItems:
            dataItems = self.cm.ph.getAllItemsBeetwenMarkers(data, 'class="entry', '</div>')
        if not dataItems:
            dataItems = self.cm.ph.getAllItemsBeetwenMarkers(data, 'episode-box', '</div>')

        if not dataItems:
            rawItems = re.findall(r'<a[^>]+href="([^"]+/(?:movie|series|episode|watch)/[^"]+)"[^>]*>(.*?)</a>', data, re.DOTALL)
            for itemUrl, itemHtml in rawItems:
                fullUrl = self.getFullUrl(itemUrl.replace('&amp;', '&'))
                title = self.cleanHtmlStr(itemHtml)
                if not title:
                    title = self.cm.ph.getSearchGroups(itemHtml, r'title="([^"]+)"')[0]
                if not title:
                    continue
                icon = self.getFullIconUrl(self.cm.ph.getSearchGroups(itemHtml, r'src="([^"]+)')[0])
                params = dict(cItem)
                params.update({"good_for_fav": True, "title": title, "url": fullUrl, "icon": icon})
                if "s" in params:
                    del params["s"]
                if "series" in fullUrl or "season" in fullUrl:
                    params.update({"category": "list_items"})
                    self.addDir(params)
                else:
                    params.update({"category": "video"})
                    self.addVideo(params)
        else:
            for item in dataItems:
                itemUrl = self.cm.ph.getSearchGroups(item, r'href="([^"]+)')[0].replace('&amp;', '&')
                if not itemUrl:
                    continue
                itemUrl = self.getFullUrl(itemUrl)

                icon = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, r'data-src="([^"]+)')[0])
                if not icon:
                    icon = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, r'src="([^"]+)')[0])
                
                title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'class="entry-title.*?>([^<]+)')[0])
                if not title:
                    title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'alt="([^"]+)')[0])
                if not title:
                    title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'title="([^"]+)')[0])
                if not title:
                    continue

                params = dict(cItem)
                params.update({"good_for_fav": True, "title": title, "url": itemUrl, "icon": icon})
                if "s" in params:
                    del params["s"]
                if "series" in itemUrl or "season" in itemUrl:
                    params.update({"category": "list_items"})
                    self.addDir(params)
                else:
                    params.update({"category": "video"})
                    self.addVideo(params)

        # 2. حساب رقم الصفحة الحالية (مثل ?category=20&page=1)
        currPage = 1
        pageMatch = re.search(r'[?&]page=(d+)', pageUrl)
        if pageMatch:
            try:
                currPage = int(pageMatch.group(1))
            except Exception:
                currPage = 1

        # 3. محاولة استخراج رابط "الصفحة التالية"
        nextPage = ""
        patterns = [
            r'href="([^"]+)"[^>]*rel="next"',
            r'rel="next"[^>]*href="([^"]+)"',
            r'class="[^"]*next[^"]*"[^>]*href="([^"]+)"',
            r'href="([^"]+)"[^>]*class="[^"]*next[^"]*"',
            r'href="([^"]+)"[^>]*>&raquo;',
            u'href="([^"]+)"[^>]*>\u0627\u0644\u062a\u0627\u0644\u064a',
            r'href="([^"]+)"[^>]*>Next'
        ]
        
        for pat in patterns:
            match = self.cm.ph.getSearchGroups(data, pat)[0]
            if match and match != pageUrl and not match.startswith('#'):
                nextPage = match
                break

        nextPageUrl = ""
        if nextPage:
            nextPageUrl = self.getFullUrl(nextPage.replace('&amp;', '&'))

        nextPageNum = 0
        if nextPageUrl:
            nextMatch = re.search(r'[?&]page=(d+)', nextPageUrl)
            if nextMatch:
                try:
                    nextPageNum = int(nextMatch.group(1))
                except Exception:
                    nextPageNum = 0

        # 4. بناء رابط الصفحة التالية مع الحفاظ الكامل على البارامترات مثل category=20&page=2
        if not nextPageUrl or nextPageUrl == pageUrl or (nextPageNum > 0 and nextPageNum <= currPage):
            targetPage = currPage + 1
            if "?page=" in pageUrl or "&page=" in pageUrl:
                nextPageUrl = re.sub(r'([?&]page=)d+', r'g<1>%d' % targetPage, pageUrl)
            else:
                sep = "&" if "?" in pageUrl else "?"
                nextPageUrl = "%s%spage=%d" % (pageUrl, sep, targetPage)

        # 5. إضافة زر الصفحة التالية وتحديد الفئة list_items صراحة لمنع الخروج للقائمة السابقة
        if nextPageUrl and nextPageUrl != pageUrl:
            params = dict(cItem)
            params.update({
                "good_for_fav": False,
                "category": "list_items",
                "title": _("Next page"),
                "url": nextPageUrl
            })
            if "s" in params:
                del params["s"]
            self.addDir(params)

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("Aflaam.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        cItem["url"] = self.getFullUrl("search?q=%s" % urllib_quote(searchPattern))
        self.listItems(cItem)

    def getLinksForVideo(self, cItem):
        printDBG("Aflaam.getLinksForVideo [%s]" % cItem)
        urlTab = []
        sts, data = self.getPage(cItem["url"])
        if not sts:
            return []
        url = re.findall(r'Quality">.*?href="([^"]+)', data, re.DOTALL)
        if url:
            sts, data = self.getPage(url[0])
            if not sts:
                return []
        data = re.findall(r'<source\s+[^>]*src="([^"]+)"\s+[^>]*size="(\d+)"', data, re.DOTALL)
        for url, q in data:
            urlTab.append({"name": q, "url": url, "need_resolve": 0})
        return urlTab

    def getVideoLinks(self, url):
        printDBG("Aflaam.getVideoLinks [%s]" % url)
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return []

    def handleService(self, index, refresh=0, searchPattern="", searchType=""):
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        if self.MAIN_URL is None:
            self.menu()
        name = self.currItem.get("name", "")
        category = self.currItem.get("category", "")
        printDBG("handleService start\nhandleService: name[%s], category[%s] " % (name, category))
        self.currList = []
        if name is None:
            self.listsTab(self.MENU, {"name": "category"})
        elif category == "movies_menu":
            self.listMoviesMenu(self.currItem)
        elif category == "series_menu":
            self.listSeriesMenu(self.currItem)
        elif category in ["list_value", "list_filters"]:
            self.listValue(self.currItem)
        elif category == "list_items":
            self.listItems(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({"search_item": False, "name": "category"})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory({"name": "history", "category": "search"}, "desc", _("Type: "))
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, Aflaam(), True, [])
