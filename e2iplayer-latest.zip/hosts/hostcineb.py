# -*- coding: utf-8 -*-
# Last modified: 2026 - MOHAMED_OS / oe-mirrors compatible
# Cineb Host for E2iPlayer (OpenATV 8 / Python 3.14 Compatible)
# Target file in receiver:
# /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer/hosts/hostcineb.py
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, E2ColoR
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
###################################################
try:
    from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import urljoin
    from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus, urllib_quote
except Exception:
    try:
        from urllib.parse import urljoin, quote_plus as urllib_quote_plus, quote as urllib_quote
    except Exception:
        from urlparse import urljoin
        from urllib import quote_plus as urllib_quote_plus, quote as urllib_quote
###################################################
# FOREIGN import
###################################################
import re
import time
###################################################

def GetConfigList():
    return []

def gettytul():
    return 'https://cineb.vg/'  # main active url of host

class Cineb(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'cineb', 'cookie': 'cineb.cookie'})
        self.MAIN_URL = gettytul()
        self.DEFAULT_ICON_URL = "https://raw.githubusercontent.com/oe-mirrors/e2iplayer/gh-pages/Thumbnails/cineb.png"
        self.TMDB_API_KEY = "9e7096a7575623aa30c66e9cc987e411"
        self.TMDB_BASE = "https://api.themoviedb.org/3"

        self.HEADER = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Referer': self.MAIN_URL
        }
        self.defaultParams = {
            'header': self.HEADER,
            'with_metadata': True,
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': True,
            'cookiefile': getattr(self, 'COOKIE_FILE', '/tmp/cineb.cookie')
        }

    def getPage(self, baseUrl, addParams=None, post_data=None):
        if addParams is None:
            addParams = dict(self.defaultParams)
        try:
            sts, data = self.cm.getPage(baseUrl, addParams, post_data)
            return sts, data
        except Exception as e:
            printDBG("Cineb.getPage exception: " + str(e))
            return False, ''

    def listMainMenu(self, cItem):
        printDBG("Cineb.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'list_trending', 'title': _('Trending Today'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'list_movies', 'title': _('Movies'), 'icon': self.DEFAULT_ICON_URL, 'media_type': 'movie', 'tab_cat': 'popular'},
            {'category': 'list_series', 'title': _('Series'), 'icon': self.DEFAULT_ICON_URL, 'media_type': 'tv', 'tab_cat': 'popular'},
            {'category': 'list_top', 'title': _('Top-IMDb'), 'icon': self.DEFAULT_ICON_URL, 'media_type': 'movie', 'tab_cat': 'top_rated'},
            {'category': 'list_genres', 'title': _('Genres'), 'icon': self.DEFAULT_ICON_URL},
        ] + self.searchItems()
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listTrending(self, cItem):
        printDBG("Cineb.listTrending")
        url = "%s/trending/all/day?api_key=%s" % (self.TMDB_BASE, self.TMDB_API_KEY)
        sts, data = self.getPage(url)
        if not sts or not data:
            return
        try:
            res = json_loads(data)
            items = res.get('results', [])
            for item in items:
                m_type = item.get('media_type', 'movie')
                if m_type not in ['movie', 'tv']:
                    continue
                title = item.get('title') or item.get('name') or ''
                tmdb_id = str(item.get('id', ''))
                poster = "https://image.tmdb.org/t/p/w500%s" % item.get('poster_path') if item.get('poster_path') else self.DEFAULT_ICON_URL
                desc_text = item.get('overview', '')
                year = (item.get('release_date') or item.get('first_air_date') or '')[:4]
                rating = str(item.get('vote_average', ''))

                colored_title = "%s%s%s (%s) [%s]" % (E2ColoR('yellow'), title, E2ColoR('white'), year or 'N/A', rating or 'N/A')
                desc = "%sRating:%s %s | %sYear:%s %s\n%s" % (
                    E2ColoR('green'), E2ColoR('white'), rating or 'N/A',
                    E2ColoR('cyan'), E2ColoR('white'), year or 'N/A',
                    desc_text
                )
                params = dict(cItem)
                params.update({
                    'title': colored_title,
                    'raw_title': title,
                    'tmdb_id': tmdb_id,
                    'media_type': m_type,
                    'icon': poster,
                    'desc': desc
                })
                if m_type == 'movie':
                    self.addVideo(params)
                else:
                    params.update({'category': 'explore_item'})
                    self.addDir(params)
        except Exception as e:
            printExc("listTrending exception: " + str(e))

    def listItems(self, cItem):
        printDBG("Cineb.listItems: %s" % cItem)
        page = cItem.get('page', 1)
        m_type = cItem.get('media_type', 'movie')
        tab_cat = cItem.get('tab_cat', 'popular')
        genre_id = cItem.get('genre_id')

        if genre_id:
            url = "%s/discover/%s?api_key=%s&with_genres=%s&page=%s&sort_by=popularity.desc" % (
                self.TMDB_BASE, m_type, self.TMDB_API_KEY, genre_id, page
            )
        else:
            url = "%s/%s/%s?api_key=%s&page=%s" % (
                self.TMDB_BASE, m_type, tab_cat, self.TMDB_API_KEY, page
            )

        sts, data = self.getPage(url)
        if not sts or not data:
            return
        try:
            res = json_loads(data)
            items = res.get('results', [])
            total_pages = res.get('total_pages', 1)

            for item in items:
                title = item.get('title') or item.get('name') or ''
                tmdb_id = str(item.get('id', ''))
                poster = "https://image.tmdb.org/t/p/w500%s" % item.get('poster_path') if item.get('poster_path') else self.DEFAULT_ICON_URL
                desc_text = item.get('overview', '')
                year = (item.get('release_date') or item.get('first_air_date') or '')[:4]
                rating = str(item.get('vote_average', ''))

                colored_title = "%s%s%s (%s) [%s]" % (E2ColoR('yellow'), title, E2ColoR('white'), year or 'N/A', rating or 'N/A')
                desc = "%sRating:%s %s | %sYear:%s %s\n%s" % (
                    E2ColoR('green'), E2ColoR('white'), rating or 'N/A',
                    E2ColoR('cyan'), E2ColoR('white'), year or 'N/A',
                    desc_text
                )
                params = dict(cItem)
                params.update({
                    'title': colored_title,
                    'raw_title': title,
                    'tmdb_id': tmdb_id,
                    'media_type': m_type,
                    'icon': poster,
                    'desc': desc
                })
                if m_type == 'movie':
                    self.addVideo(params)
                else:
                    params.update({'category': 'explore_item'})
                    self.addDir(params)

            if page < total_pages and page < 50:
                nextParams = dict(cItem)
                nextParams.update({
                    'title': "%s%s >>%s" % (E2ColoR('green'), _('Next Page'), E2ColoR('white')),
                    'page': page + 1
                })
                self.addDir(nextParams)
        except Exception as e:
            printExc("listItems exception: " + str(e))

    def listGenres(self, cItem):
        GENRES = [
            (28, _('Action')),
            (12, _('Adventure')),
            (16, _('Animation')),
            (35, _('Comedy')),
            (80, _('Crime')),
            (99, _('Documentary')),
            (18, _('Drama')),
            (10751, _('Family')),
            (14, _('Fantasy')),
            (27, _('Horror')),
            (10749, _('Romance')),
            (878, _('Sci-Fi')),
            (53, _('Thriller'))
        ]
        for g_id, g_name in GENRES:
            params = dict(cItem)
            params.update({
                'category': 'list_items',
                'title': g_name,
                'genre_id': g_id,
                'media_type': 'movie',
                'tab_cat': 'discover',
                'page': 1
            })
            self.addDir(params)

    def exploreItems(self, cItem, nextCategory):
        printDBG("Cineb.exploreItems: %s" % cItem)
        tmdb_id = cItem.get('tmdb_id')
        if not tmdb_id:
            return
        url = "%s/tv/%s?api_key=%s" % (self.TMDB_BASE, tmdb_id, self.TMDB_API_KEY)
        sts, data = self.getPage(url)
        if not sts or not data:
            return
        try:
            tv_data = json_loads(data)
            seasons = tv_data.get('seasons', [])
            for s in seasons:
                s_num = s.get('season_number', 1)
                if s_num == 0:
                    continue
                s_name = s.get('name') or ("Season %s" % s_num)
                poster = "https://image.tmdb.org/t/p/w500%s" % s.get('poster_path') if s.get('poster_path') else cItem['icon']
                params = dict(cItem)
                params.update({
                    'category': nextCategory,
                    'title': "%s - %s" % (cItem.get('raw_title', cItem['title']), s_name),
                    'season': s_num,
                    'icon': poster,
                    'desc': s.get('overview', cItem.get('desc', ''))
                })
                self.addDir(params)
        except Exception as e:
            printExc("exploreItems exception: " + str(e))

    def listEpisodes(self, cItem):
        printDBG("Cineb.listEpisodes: %s" % cItem)
        tmdb_id = cItem.get('tmdb_id')
        s_num = cItem.get('season', 1)
        url = "%s/tv/%s/season/%s?api_key=%s" % (self.TMDB_BASE, tmdb_id, s_num, self.TMDB_API_KEY)
        sts, data = self.getPage(url)
        if not sts or not data:
            return
        try:
            season_data = json_loads(data)
            episodes = season_data.get('episodes', [])
            for ep in episodes:
                ep_num = ep.get('episode_number', 1)
                ep_name = ep.get('name') or ("Episode %s" % ep_num)
                still = "https://image.tmdb.org/t/p/w500%s" % ep.get('still_path') if ep.get('still_path') else cItem['icon']
                params = dict(cItem)
                params.update({
                    'title': "S%02dE%02d - %s" % (int(s_num), int(ep_num), ep_name),
                    'episode': ep_num,
                    'icon': still,
                    'desc': ep.get('overview', '')
                })
                self.addVideo(params)
        except Exception as e:
            printExc("listEpisodes exception: " + str(e))

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("Cineb.listSearchResult pattern[%s]" % searchPattern)
        query = urllib_quote_plus(searchPattern.strip())
        url = "%s/search/multi?api_key=%s&query=%s" % (self.TMDB_BASE, self.TMDB_API_KEY, query)
        sts, data = self.getPage(url)
        if not sts or not data:
            return
        try:
            items = json_loads(data).get('results', [])
            for item in items:
                m_type = item.get('media_type', 'movie')
                if m_type not in ['movie', 'tv']:
                    continue
                title = item.get('title') or item.get('name') or ''
                tmdb_id = str(item.get('id', ''))
                poster = "https://image.tmdb.org/t/p/w500%s" % item.get('poster_path') if item.get('poster_path') else self.DEFAULT_ICON_URL
                desc_text = item.get('overview', '')
                year = (item.get('release_date') or item.get('first_air_date') or '')[:4]
                rating = str(item.get('vote_average', ''))

                colored_title = "%s%s%s (%s) [%s]" % (E2ColoR('yellow'), title, E2ColoR('white'), year or 'N/A', rating or 'N/A')
                desc = "%sRating:%s %s | %sYear:%s %s\n%s" % (
                    E2ColoR('green'), E2ColoR('white'), rating or 'N/A',
                    E2ColoR('cyan'), E2ColoR('white'), year or 'N/A',
                    desc_text
                )
                params = dict(cItem)
                params.update({
                    'title': colored_title,
                    'raw_title': title,
                    'tmdb_id': tmdb_id,
                    'media_type': m_type,
                    'icon': poster,
                    'desc': desc
                })
                if m_type == 'movie':
                    self.addVideo(params)
                else:
                    params.update({'category': 'explore_item'})
                    self.addDir(params)
        except Exception as e:
            printExc("listSearchResult exception: " + str(e))

    def getLinksForVideo(self, cItem):
        printDBG("Cineb.getLinksForVideo [%s]" % cItem)
        retTab = []
        tmdb_id = cItem.get('tmdb_id')
        m_type = cItem.get('media_type', 'movie')
        season = cItem.get('season', 1)
        episode = cItem.get('episode', 1)

        if not tmdb_id:
            return retTab

        # High-efficiency verified streaming servers (All 7-bit ASCII names)
        SERVERS = [
            ('Videasy 1080p (Fast)', "https://player.videasy.net/movie/%s" % tmdb_id if m_type == 'movie' else "https://player.videasy.net/tv/%s/%s/%s" % (tmdb_id, season, episode)),
            ('VidCore HD (Cineb Official)', "https://vidcore.net/movie/%s?autoPlay=true" % tmdb_id if m_type == 'movie' else "https://vidcore.net/tv/%s/%s/%s?autoPlay=true" % (tmdb_id, season, episode)),
            ('VidFast HD (Fast)', "https://vidfast.pro/movie/%s?autoPlay=true" % tmdb_id if m_type == 'movie' else "https://vidfast.pro/tv/%s/%s/%s?autoPlay=true" % (tmdb_id, season, episode)),
            ('VidSrc RU (Mirror)', "https://vidsrc-embed.ru/embed/movie/%s" % tmdb_id if m_type == 'movie' else "https://vidsrc-embed.ru/embed/tv/%s/%s/%s" % (tmdb_id, season, episode)),
            ('VidSrc In (Backup)', "https://vidsrc.in/embed/movie/%s" % tmdb_id if m_type == 'movie' else "https://vidsrc.in/embed/tv/%s/%s/%s" % (tmdb_id, season, episode))
        ]

        for name, url in SERVERS:
            stream_url = strwithmeta(url, {
                'Referer': self.MAIN_URL,
                'User-Agent': self.HEADER['User-Agent']
            })
            retTab.append({
                'name': name,
                'url': stream_url,
                'need_resolve': 1
            })

        return retTab

    def getVideoLinks(self, videoUrl):
        printDBG("Cineb.getVideoLinks [%s]" % videoUrl)
        if self.cm.isValidUrl(videoUrl):
            return self.up.getVideoLinkExt(videoUrl)
        return []

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        self.currList = []

        if name is None and not category:
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif category == 'list_trending':
            self.listTrending(self.currItem)
        elif category in ['list_movies', 'list_series', 'list_top', 'list_items']:
            self.listItems(self.currItem)
        elif category == 'list_genres':
            self.listGenres(self.currItem)
        elif category == 'explore_item':
            self.exploreItems(self.currItem, 'list_episodes')
        elif category == 'list_episodes':
            self.listEpisodes(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)

class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, Cineb(), True, [])