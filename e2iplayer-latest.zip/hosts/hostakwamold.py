# -*- coding: utf-8 -*-
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import GetIPTVSleep
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads
###################################################
# FOREIGN import
###################################################
import re

###################################################
# NOTE ON ENCODING:
# The Arabic labels below are written as \\uXXXX
# escapes instead of literal UTF-8 characters. This
# is deliberate: some FTP/telnet transfer paths to
# the receiver box re-save the file in a non-UTF-8
# encoding, which corrupts literal Arabic text and
# breaks the "# -*- coding: utf-8 -*-" declaration
# with a SyntaxError. \\uXXXX escapes are plain ASCII
# in the file itself, so they survive any transfer
# encoding untouched; Python decodes them at import
# time regardless.
###################################################


def GetConfigList():
    return []


def gettytul():
    return 'https://ak.sv/old/'  # main url of host


class AkwamOld(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'akwamold', 'cookie': 'akwamold.cookie'})
        self.MAIN_URL = gettytul()
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/pLWdJQn/akoam.png'
        self.HEADER = self.cm.getDefaultHeader(browser='firefox')
        self.HEADER['Referer'] = self.MAIN_URL
        self.HEADER['Origin'] = self.MAIN_URL
        self.defaultParams = {
            'header': self.HEADER,
            'with_metadata': True,
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': True,
            'cookiefile': self.COOKIE_FILE
        }

    def getPage(self, baseUrl, addParams=None, post_data=None):
        if any(ord(c) > 127 for c in baseUrl):
            from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
            baseUrl = urllib_quote_plus(baseUrl, safe="://")
        if addParams is None:
            addParams = dict(self.defaultParams)
        i = 0
        while True:
            addParams['cloudflare_params'] = {'cookie_file': self.COOKIE_FILE, 'User-Agent': self.HEADER.get('User-Agent')}
            sts, data = self.cm.getPageCFProtection(baseUrl, addParams, post_data)
            if sts:
                if 'class="loading"' in data:
                    GetIPTVSleep().Sleep(5)
                    continue
                break
            else:
                i += 1
                if i > 2:
                    break
        return sts, data

    ###################################################
    # MAIN MENU
    ###################################################
    def listMainMenu(self, cItem):
        printDBG('AkwamOld.listMainMenu')
        MAIN_CAT_TAB = [
            {'category': 'list_section', 'title': u'\u0627\u0644\u0623\u0641\u0644\u0627\u0645', 'sub_mode': '0'},
            {'category': 'list_section', 'title': u'\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a', 'sub_mode': '1'},
            {'category': 'list_subsection', 'title': u'\u0627\u0644\u0623\u0646\u0645\u064a', 'url': self.getFullUrl('cat/83/%D8%A7%D9%84%D8%A7%D9%86%D9%85%D9%8A')},
            {'category': 'list_section', 'title': u'\u0622\u062e\u0631', 'sub_mode': '2'},
        ] + self.searchItems()
        self.listsTab(MAIN_CAT_TAB, cItem)

    def uniform_titre(self, name_eng):
        # Pulls a bracketed quality/year tag out of the raw scraped title
        # (e.g. "Movie Name (2024) [HD]") and returns it as a description
        # prefix plus the cleaned title. This was originally assumed to be
        # inherited from the base host class - it isn't, so it's defined
        # here instead (same root cause as the std_url AttributeError).
        desc0 = ''
        m = re.search(r'[\(\[]([^\)\]]+)[\)\]]\s*$', name_eng)
        if m:
            desc0 = m.group(1) + ' - '
            name_eng = (name_eng[:m.start()]).strip()
        return desc0, name_eng

    ###################################################
    # SECTION LIST (was mode 20): lists the actual
    # category links scraped from the site's main page
    # filtered by sub_mode (movies / series / other)
    ###################################################
    def listSection(self, cItem):
        sub_mode = cItem.get('sub_mode', '0')
        sts, data = self.getPage(self.MAIN_URL)
        if not sts:
            return
        lst_data = re.findall('<ul class="partions"(.*?)</ul>', data, re.S)
        if not lst_data:
            return
        excluded = [
            u'\u0627\u0644\u0628\u0631\u0627\u0645\u062c',          # programs
            u'\u0627\u0644\u0623\u0644\u0639\u0627\u0628',          # games
            u'\u0627\u0644\u0627\u062c\u0647\u0632\u0629 \u0627\u0644\u0644\u0648\u062d\u064a\u0629',  # tablets
            u'\u0627\u0633\u0644\u0627\u0645\u064a\u0627\u062a \u0648 \u0627\u0646\u0627\u0634\u064a\u062f',  # islamic/nasheed
            u'\u0627\u0644\u0643\u062a\u0628 \u0648 \u0627\u0644\u0627\u0628\u062d\u0627\u062b',  # books
            u'\u0627\u0644\u0635\u0648\u0631 \u0648 \u0627\u0644\u062e\u0644\u0641\u064a\u0627\u062a',  # wallpapers
            u'\u0627\u0644\u0627\u0646\u0645\u064a',                 # anime (handled separately)
        ]
        movies_kw = u'\u0641\u0644\u0627\u0645'          # substring shared by "films" variants
        series_kw = u'\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062a'  # series

        lst_data1 = re.findall('data-title="(.*?)".*?href="(.*?)">(.*?)<', lst_data[0], re.S)
        TAB = []
        for (desc, url, titre) in lst_data1:
            if titre in excluded:
                continue
            if sub_mode == '0' and movies_kw in titre:
                TAB.append({'category': 'list_subsection', 'title': titre, 'url': url})
            elif sub_mode == '1' and series_kw in titre:
                TAB.append({'category': 'list_subsection', 'title': titre, 'url': url})
            elif sub_mode == '2' and series_kw not in titre and movies_kw not in titre:
                TAB.append({'category': 'list_items', 'title': titre, 'url': url})
        self.listsTab(TAB, cItem)

    ###################################################
    # SUBSECTION (was mode 21): sub-categories inside
    # a section, plus an "all" shortcut
    ###################################################
    def listSubsection(self, cItem):
        url0 = cItem['url']
        titre0 = cItem['title']
        TAB = [{'category': 'list_items', 'title': u'\u0627\u0644\u0643\u0644 - ' + titre0, 'url': url0}]

        sts, data = self.getPage(url0)
        if sts:
            lst_data = re.findall(u'\u0644\u0623\u0642\u0633\u0627\u0645 \u0627\u0644\u0641\u0631\u0639\u064a\u0629</span>(.*?)</ul>', data, re.S)
            if lst_data:
                lst_data1 = re.findall('href="(.*?)">(.*?)<', lst_data[0], re.S)
                for (url, titre) in lst_data1:
                    TAB.append({'category': 'list_items', 'title': titre, 'url': url})
        self.listsTab(TAB, cItem)

    ###################################################
    # ITEMS LIST (was mode 30): paginated grid of
    # movies/series with poster + description
    ###################################################
    def listItems(self, cItem):
        page = cItem.get('page', 1)
        url0 = cItem['url']
        url1 = url0 + '/page/' + str(page)
        sts, data = self.getPage(url1)
        if not sts:
            return
        lst_data = re.findall('class="subject_box shape".*?href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<.*?desc">(.*?)<', data, re.S)
        count = 0
        TAB = []
        skip_marker = u'\u062a\u0648\u0636\u064a\u062d \u0647\u0627\u0645 \u0644\u0645\u062a\u0627\u0628\u0639\u064a'
        for (url1, image, name_eng, desc) in lst_data:
            if skip_marker in name_eng:
                continue
            name_eng = self.cleanHtmlStr(name_eng.strip())
            desc0, name_eng = self.uniform_titre(name_eng)
            if desc.strip() != '':
                desc = 'Info: ' + desc
            desc = desc0 + desc
            TAB.append({'category': 'list_details', 'title': name_eng, 'url': url1.strip(), 'desc': desc, 'icon': image, 'good_for_fav': True, 'EPG': True})
            count += 1
        self.listsTab(TAB, cItem)
        if count > 38:
            params = dict(cItem)
            params.update({'title': 'Page Suivante', 'url': cItem['url'], 'page': page + 1})
            self.addDir(params)

    ###################################################
    # ITEM DETAILS (was mode 31): trailer, episodes,
    # and the various direct-link layouts the old
    # akwam design can present
    ###################################################
    def std_host_name(self, name_):
        if self.up.checkHostSupportbyname(name_):
            base = name_.split('|')[-1] if '|' in name_ else name_
            return name_.replace(base, base.replace('embed.', '').title()) if '|' in name_ else base.replace('embed.', '').title()
        elif self.up.checkHostNotSupportbyname(name_):
            base = name_.split('|')[-1] if '|' in name_ else name_
            return name_.replace(base, base.replace('embed.', '').title()) if '|' in name_ else base.replace('embed.', '').title()
        return name_

    def listDetails(self, cItem):
        hostMap = {'1477487990': 'Vidtodo', '1558278006': 'Uqload', '1423075862': 'Dailymotion', '1458117295': 'Openload.co', '1477487601': 'Estream.to', '1505328404': 'Streamango', '1423080015': 'Flashx.tv', '1430052371': 'Ok.ru', '1477488213': 'Thevid.tv'}
        icon0 = cItem.get('icon', self.DEFAULT_ICON_URL)
        url0 = cItem['url']
        desc = cItem.get('desc', '')
        no_server_msg = u'\u0644\u064a\u0633 \u0647\u0646\u0627\u0643 \u0633\u0631\u0641\u0631\u0627\u062a \u0645\u0634\u0627\u0647\u062f\u0629'
        try:
            sts, data = self.getPage(url0)
            if not sts:
                return
            trailer_data = re.findall('class="sub_trailer">.*?class="youtube-player.*?id="(.*?)"', data, re.S)
            if trailer_data:
                self.addVideo({'category': 'list_details', 'title': 'TRAILER', 'url': 'https://www.youtube.com/watch?v=' + trailer_data[0], 'desc': '', 'icon': icon0})

            new_design_marker1 = u'\u0627\u0644\u0627\u0646\u062a\u0642\u0627\u0644 \u0625\u0644\u064a \u0627\u0644\u062a\u0635\u0645\u064a\u0645 \u0627\u0644\u062c\u062f\u064a\u062f'
            new_design_marker2 = u'\u0639\u0644\u0649 \u0627\u0644\u062a\u0635\u0645\u064a\u0645 \u0627\u0644\u062c\u062f\u064a\u062f'
            if (new_design_marker1 in data) or (new_design_marker2 in data):
                lst_data = re.findall('sub_extra_desc">.*?href="(.*?)"', data, re.S)
                if not lst_data:
                    lst_data = re.findall('class="sub_desc">.*?href="(.*?)"', data, re.S)
                if lst_data:
                    Url = lst_data[0]
                    titre = '[New Site] ' + cItem['title']
                    # This used to hand off to a sibling "new design" host.
                    # Point 'category' below at your actual new-akwam host
                    # module's dispatch category if you wire one in; for
                    # now it just re-enters list_details on the new URL.
                    self.addDir({'category': 'list_details', 'title': titre, 'url': Url, 'desc': cItem.get('desc', ''), 'icon': icon0})
                return

            if 'sub_episode_links">' in data:
                lst_data = re.findall('_episode_links">(.*?)title">(.*?)<.*?(?:<h5>|sub-no-file)(.*?)<div class="sub', data, re.S)
                for (inf, titre1, data1) in lst_data:
                    img_data = re.findall('src="(.*?)"', inf, re.S)
                    img_ = img_data[0] if img_data else icon0

                    self.addMarker({'title': titre1.strip(), 'icon': img_})
                    if u"box epsoide_box'>" in data1:
                        dat_1, dat_2 = data1.split(u"box epsoide_box'>", 1)
                    else:
                        dat_1, dat_2 = data1, ''
                    lst_dat = re.findall('href=[\'"](.*?)[\'"]', dat_1, re.S)
                    if lst_dat:
                        self.addVideo({'category': 'list_details', 'title': 'Akoam', 'url': lst_dat[0], 'desc': desc, 'icon': img_, 'good_for_fav': True, 'url0': url0})
                    lst_dat = re.findall('/files/(.*?)\\..*?href=[\'"](.*?)[\'"]', data1, re.S)
                    for (hst1, urll) in lst_dat:
                        titre = hostMap.get(hst1, u'\u0631\u0627\u0628\u0637 \u0645\u0634\u0627\u0647\u062f\u0629')
                        self.addVideo({'category': 'list_details', 'title': self.std_host_name(titre), 'url': urll, 'desc': desc, 'icon': img_, 'good_for_fav': True, 'url0': url0})
                return

            lst_data = re.findall("'sub_direct_links'>(.*?)clear\">", data, re.S)
            for data1 in lst_data:
                if "sub_direct_links'>" in data1:
                    dat_1, dat_2 = data1.split("sub_direct_links'>")
                else:
                    dat_1, dat_2 = data1, ''
                lst_dat = re.findall('href=[\'"](.*?)[\'"]', dat_1, re.S)
                if lst_dat:
                    self.addMarker({'title': u'\u062a\u062d\u0645\u064a\u0644 \u0648 \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0629 \u0627\u0644\u062e\u0627\u0635 ', 'icon': icon0})
                    self.addVideo({'category': 'list_details', 'title': 'Akoam', 'url': lst_dat[0], 'desc': desc, 'icon': icon0, 'good_for_fav': True, 'url0': url0})

                lst_dat = re.findall('/files/(.*?)\\..*?href=[\'"](.*?)[\'"]', dat_2, re.S)
                if lst_dat:
                    self.addMarker({'title': u' \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0629', 'icon': icon0})
                    for (hst1, urll) in lst_dat:
                        titre = hostMap.get(hst1, u'\u0631\u0627\u0628\u0637 \u0645\u0634\u0627\u0647\u062f\u0629')
                        self.addVideo({'category': 'list_details', 'title': self.std_host_name(titre), 'url': urll, 'desc': desc, 'icon': icon0, 'good_for_fav': True, 'url0': url0})
        except Exception:
            printExc()
            self.addMarker({'title': no_server_msg, 'icon': icon0})

    ###################################################
    # SEARCH
    ###################################################
    def listSearchResult(self, cItem, searchPattern, searchType):
        page = cItem.get('page', 1)
        url_ = self.MAIN_URL + '/search/' + searchPattern + '/page/' + str(page)
        sts, data = self.getPage(url_)
        if not sts:
            return
        lst_data = re.findall('<div class="tags_box">.*?href="(.*?)".*?url\\((.*?)\\).*?<h1>(.*?)<', data, re.S)
        TAB = []
        for (url1, image, name_eng) in lst_data:
            name_eng = self.cleanHtmlStr(name_eng.strip())
            desc0, name_eng = self.uniform_titre(name_eng)
            TAB.append({'category': 'list_details', 'title': name_eng, 'url': url1, 'desc': desc0, 'icon': image, 'good_for_fav': True, 'EPG': True})
        self.listsTab(TAB, cItem)

    ###################################################
    # VIDEO LINKS
    ###################################################
    def get_links(self, cItem):
        urlTab = []
        URL = cItem['url'].replace('download', 'watching')
        printDBG('url=' + URL)
        self.cm.clearCookie(self.COOKIE_FILE, removeNames=['golink'])
        sts, data = self.getPage(URL)
        if sts:
            try:
                cookies_ = self.cm.getCookieItems(self.COOKIE_FILE)
                if 'golink' in cookies_:
                    from Plugins.Extensions.IPTVPlayer.libs.urlparser import Unquote
                    link_from_cookie = json_loads(Unquote(cookies_['golink']))['route'].replace('download', 'watching')
                    paramsUrl = dict(self.defaultParams)
                    paramsUrl['header']['Referer'] = cItem['url']
                    sts, data = self.getPage(link_from_cookie, paramsUrl)
            except Exception:
                printDBG('except01')

            url_dat = re.findall('<iframe[^>]+?src=[\'"]([^"^\']+?)[\'"]', data, re.S | re.IGNORECASE)
            if not url_dat:
                lst_dat = re.findall('file:.{,3}?"(.*?)"', data, re.S)
                if lst_dat:
                    urlTab.append({'name': 'direct_link', 'url': lst_dat[0]})
            else:
                urL_ = url_dat[0]
                if 'mellowads' not in urL_:
                    if urL_.startswith('//'):
                        urL_ = 'http:' + urL_
                    if not urL_.startswith('http'):
                        urL_ = 'http://' + urL_
                    urlTab.append({'name': 'link', 'url': urL_, 'need_resolve': 1})

            if len(urlTab) == 0:
                paramsUrl = dict(self.defaultParams)
                URL = URL.replace('watching', 'download')
                paramsUrl['header']['Referer'] = URL
                paramsUrl['header']['X-Requested-With'] = 'XMLHttpRequest'
                sts, data = self.getPage(URL, paramsUrl, post_data={})
                if sts:
                    url_dat0 = re.findall('direct_link":"(.*?)"', data, re.S | re.IGNORECASE)
                    if url_dat0:
                        urlTab.append({'name': 'direct_link', 'url': url_dat0[0].replace('\\\\', '')})
        return urlTab

    def getLinksForVideo(self, cItem):
        printDBG('AkwamOld.getLinksForVideo [%s]' % cItem)
        return self.get_links(cItem)

    ###################################################
    # DISPATCH
    ###################################################
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('AkwamOld.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", None)
        category = self.currItem.get("category", '')
        printDBG("handleService: >> name[%s], category[%s] " % (name, category))
        self.currList = []

        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'list_section':
            self.listSection(self.currItem)
        elif category == 'list_subsection':
            self.listSubsection(self.currItem)
        elif category == 'list_items':
            self.listItems(self.currItem)
        elif category == 'list_details':
            self.listDetails(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, AkwamOld(), True, [])
