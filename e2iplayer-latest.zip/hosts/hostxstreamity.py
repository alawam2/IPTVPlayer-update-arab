# -*- coding: utf-8 -*-
###################################################
# XStreamity -> e2iplayer Host
# Reads playlists from XStreamity plugin path
# /etc/enigma2/xstreamity/x-playlists.json
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps

from Components.config import config, ConfigText, getConfigListEntry
import os
import re

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

###################################################
# Paths of XStreamity plugin
###################################################
XSTREAMITY_DIR = "/etc/enigma2/xstreamity/"
XSTREAMITY_JSON = os.path.join(XSTREAMITY_DIR, "x-playlists.json")

###################################################
# Optional manual override
###################################################
config.plugins.iptvplayer.xstreamity_manual_host = ConfigText(default="", fixed_size=False)
config.plugins.iptvplayer.xstreamity_manual_user = ConfigText(default="", fixed_size=False)
config.plugins.iptvplayer.xstreamity_manual_pass = ConfigText(default="", fixed_size=False)


def GetConfigList():
    optionList = []
    optionList.append(getConfigListEntry(_("Manual Host (optional)") + ":", config.plugins.iptvplayer.xstreamity_manual_host))
    optionList.append(getConfigListEntry(_("Manual Username (optional)") + ":", config.plugins.iptvplayer.xstreamity_manual_user))
    optionList.append(getConfigListEntry(_("Manual Password (optional)") + ":", config.plugins.iptvplayer.xstreamity_manual_pass))
    return optionList


def gettytul():
    return 'XStreamity (from plugin)'


class XStreamity(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'xstreamity', 'cookie': 'xstreamity.cookie'})
        self.MAIN_URL = ''
        self.DEFAULT_ICON_URL = ''
        self.host = ''
        self.username = ''
        self.password = ''
        self.player_api = ''
        self.output = 'ts'
        self.playlists = []
        self.current_playlist = None

        self.HTTP_HEADER = self.cm.getDefaultHeader(browser='chrome')
        self.defaultParams = {'header': self.HTTP_HEADER}

    # ------------------------------------------------------------------
    # Load from XStreamity
    # ------------------------------------------------------------------
    def _load_playlists(self):
        self.playlists = []
        if not os.path.isfile(XSTREAMITY_JSON):
            printDBG('XStreamity JSON not found: %s' % XSTREAMITY_JSON)
            return False
        try:
            with open(XSTREAMITY_JSON, 'r') as f:
                data = json_loads(f.read())
            if isinstance(data, list):
                self.playlists = data
            printDBG('Loaded %d playlists from XStreamity' % len(self.playlists))
            return len(self.playlists) > 0
        except Exception as e:
            printDBG('Error loading XStreamity JSON: %s' % str(e))
            printExc()
            return False

    def _get_display_name(self, pl):
        info = pl.get('playlist_info', {})
        name = info.get('name', '').strip()
        domain = info.get('domain', '') or info.get('host', '')
        user = info.get('username', '')
        if name:
            return '%s  [%s]' % (name, domain)
        return '%s @ %s' % (user, domain)

    # ------------------------------------------------------------------
    # Setup credentials
    # ------------------------------------------------------------------
    def _setup_from_playlist(self, pl):
        info = pl.get('playlist_info', {})
        self.current_playlist = pl

        # Manual override
        man_host = config.plugins.iptvplayer.xstreamity_manual_host.value.strip()
        man_user = config.plugins.iptvplayer.xstreamity_manual_user.value.strip()
        man_pass = config.plugins.iptvplayer.xstreamity_manual_pass.value.strip()

        if man_host and man_user and man_pass:
            self.host = man_host.rstrip('/')
            if not self.host.startswith('http'):
                self.host = 'http://' + self.host
            self.username = man_user
            self.password = man_pass
            self.output = 'ts'
            self.player_api = '%s/player_api.php?username=%s&password=%s' % (
                self.host, quote(self.username), quote(self.password)
            )
        else:
            self.host = (info.get('host') or '').rstrip('/')
            if not self.host:
                domain = info.get('domain', '')
                protocol = info.get('protocol', 'http://')
                port = info.get('port', '')
                if domain:
                    if port:
                        self.host = '%s%s:%s' % (protocol, domain, port)
                    else:
                        self.host = protocol + domain
            self.username = info.get('username', '')
            self.password = info.get('password', '')
            self.output = info.get('output', 'ts') or 'ts'
            self.player_api = info.get('player_api', '')
            if not self.player_api and self.host and self.username and self.password:
                self.player_api = '%s/player_api.php?username=%s&password=%s' % (
                    self.host, quote(self.username), quote(self.password)
                )

        if not self.host or not self.username or not self.password:
            printDBG('Missing host/user/pass')
            return False

        self.MAIN_URL = self.host
        printDBG('Using host=%s user=%s' % (self.host, self.username))
        return True

    def _ensure_auth(self):
        return bool(self.host and self.username and self.password and self.player_api)

    def _api(self, action, extra=''):
        url = self.player_api + '&action=' + action
        if extra:
            url += extra
        try:
            sts, data = self.cm.getPage(url, self.defaultParams)
            if not sts or not data:
                printDBG('API failed: %s' % action)
                return None
            return json_loads(data)
        except Exception:
            printExc()
            return None

    def _stream_url(self, stream_id, content_type='live'):
        """Build direct stream URL"""
        # live / movie / series
        if content_type == 'live':
            path = 'live'
        elif content_type == 'vod' or content_type == 'movie':
            path = 'movie'
        else:
            path = 'series'
        url = '%s/%s/%s/%s/%s.%s' % (
            self.host, path, self.username, self.password, stream_id, self.output
        )
        return url

    # ------------------------------------------------------------------
    # Menus
    # ------------------------------------------------------------------
    def listMainMenu(self, cItem):
        printDBG('XStreamity.listMainMenu')
        self.playlists = []
        if not self._load_playlists():
            self.addDir({
                'category': 'info',
                'title': _('No playlists found in XStreamity'),
                'desc': _('Path: %s\nAdd playlists in XStreamity plugin first.') % XSTREAMITY_JSON
            })
            if (config.plugins.iptvplayer.xstreamity_manual_host.value and
                    config.plugins.iptvplayer.xstreamity_manual_user.value and
                    config.plugins.iptvplayer.xstreamity_manual_pass.value):
                self.addDir({
                    'category': 'select_playlist',
                    'title': _('Use Manual credentials (from settings)'),
                    'playlist_idx': -1
                })
            return

        for idx, pl in enumerate(self.playlists):
            name = self._get_display_name(pl)
            info = pl.get('playlist_info', {})
            desc = info.get('host', '') or info.get('domain', '')
            self.addDir({
                'category': 'select_playlist',
                'title': name,
                'desc': desc,
                'playlist_idx': idx
            })

    def listAfterSelect(self, cItem):
        idx = cItem.get('playlist_idx', -1)

        if idx == -1:
            fake = {'playlist_info': {}}
            ok = self._setup_from_playlist(fake)
        else:
            if not self.playlists:
                self._load_playlists()
            if idx < 0 or idx >= len(self.playlists):
                self.addDir({'category': 'info', 'title': _('Invalid playlist')})
                return
            ok = self._setup_from_playlist(self.playlists[idx])

        if not ok:
            self.addDir({
                'category': 'info',
                'title': _('Invalid credentials'),
                'desc': _('Host / Username / Password missing')
            })
            return

        MAIN = [
            {'category': 'live_categories', 'title': _('Live TV'), 'playlist_idx': idx},
            {'category': 'vod_categories', 'title': _('VOD / Movies'), 'playlist_idx': idx},
            {'category': 'series_categories', 'title': _('Series'), 'playlist_idx': idx},
            {'category': 'catchup_channels', 'title': _('Catchup / Archive'), 'playlist_idx': idx},
            {'category': 'ipa_menu', 'title': _('IPAudioPro export'), 'playlist_idx': idx},
            {'category': 'search', 'title': _('Search'), 'search_item': True, 'playlist_idx': idx},
            {'category': 'search_history', 'title': _('Search history')},
        ]
        self.listsTab(MAIN, cItem)

    # ------------------------------------------------------------------
    # Live
    # ------------------------------------------------------------------
    def listLiveCategories(self, cItem):
        printDBG('XStreamity.listLiveCategories')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        data = self._api('get_live_categories')
        if not data or not isinstance(data, list):
            return

        self.addDir({
            'category': 'live_streams',
            'title': _('All Channels'),
            'cat_id': 'all',
            'playlist_idx': cItem.get('playlist_idx', 0)
        })

        for cat in data:
            if not isinstance(cat, dict):
                continue
            title = cat.get('category_name') or cat.get('name') or ''
            cid = cat.get('category_id') or cat.get('id') or ''
            if not title:
                continue
            self.addDir({
                'category': 'live_streams',
                'title': title,
                'cat_id': str(cid),
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listLiveStreams(self, cItem):
        printDBG('XStreamity.listLiveStreams')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        cat_id = cItem.get('cat_id', 'all')
        if cat_id == 'all':
            data = self._api('get_live_streams')
        else:
            data = self._api('get_live_streams', '&category_id=' + str(cat_id))

        if not data or not isinstance(data, list):
            return

        for ch in data:
            if not isinstance(ch, dict):
                continue
            name = ch.get('name') or ch.get('title') or ''
            stream_id = ch.get('stream_id') or ch.get('id') or ''
            logo = ch.get('stream_icon') or ch.get('logo') or ''
            if not name or not stream_id:
                continue
            url = self._stream_url(stream_id, 'live')
            self.addVideo({
                'title': name,
                'url': url,
                'icon': logo,
                'stream_id': str(stream_id),
                'content_type': 'live'
            })

    # ------------------------------------------------------------------
    # VOD
    # ------------------------------------------------------------------
    def listVodCategories(self, cItem):
        printDBG('XStreamity.listVodCategories')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        data = self._api('get_vod_categories')
        if not data or not isinstance(data, list):
            return

        for cat in data:
            if not isinstance(cat, dict):
                continue
            title = cat.get('category_name') or cat.get('name') or ''
            cid = cat.get('category_id') or cat.get('id') or ''
            if not title:
                continue
            self.addDir({
                'category': 'vod_streams',
                'title': title,
                'cat_id': str(cid),
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listVodStreams(self, cItem):
        printDBG('XStreamity.listVodStreams')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        cat_id = cItem.get('cat_id', '')
        if cat_id:
            data = self._api('get_vod_streams', '&category_id=' + str(cat_id))
        else:
            data = self._api('get_vod_streams')

        if not data or not isinstance(data, list):
            return

        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get('name') or item.get('title') or ''
            stream_id = item.get('stream_id') or item.get('id') or ''
            logo = item.get('stream_icon') or item.get('cover') or ''
            if not name or not stream_id:
                continue
            # container extension if available
            ext = item.get('container_extension') or self.output
            url = '%s/movie/%s/%s/%s.%s' % (
                self.host, self.username, self.password, stream_id, ext
            )
            self.addVideo({
                'title': name,
                'url': url,
                'icon': logo,
                'stream_id': str(stream_id),
                'content_type': 'vod',
                'desc': item.get('plot') or item.get('description') or ''
            })

    # ------------------------------------------------------------------
    # Series
    # ------------------------------------------------------------------
    def listSeriesCategories(self, cItem):
        printDBG('XStreamity.listSeriesCategories')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        data = self._api('get_series_categories')
        if not data or not isinstance(data, list):
            return

        for cat in data:
            if not isinstance(cat, dict):
                continue
            title = cat.get('category_name') or cat.get('name') or ''
            cid = cat.get('category_id') or cat.get('id') or ''
            if not title:
                continue
            self.addDir({
                'category': 'series_list',
                'title': title,
                'cat_id': str(cid),
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listSeries(self, cItem):
        printDBG('XStreamity.listSeries')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        cat_id = cItem.get('cat_id', '')
        if cat_id:
            data = self._api('get_series', '&category_id=' + str(cat_id))
        else:
            data = self._api('get_series')

        if not data or not isinstance(data, list):
            return

        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get('name') or item.get('title') or ''
            series_id = item.get('series_id') or item.get('id') or ''
            logo = item.get('cover') or item.get('stream_icon') or ''
            if not name or not series_id:
                continue
            self.addDir({
                'category': 'series_info',
                'title': name,
                'series_id': str(series_id),
                'icon': logo,
                'desc': item.get('plot') or '',
                'playlist_idx': cItem.get('playlist_idx', 0)
            })

    def listSeriesInfo(self, cItem):
        printDBG('XStreamity.listSeriesInfo')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        series_id = cItem.get('series_id', '')
        data = self._api('get_series_info', '&series_id=' + str(series_id))
        if not data or not isinstance(data, dict):
            return

        episodes = data.get('episodes') or {}
        # episodes is often dict: season_num -> list of episodes
        if isinstance(episodes, dict):
            for season, eps in sorted(episodes.items(), key=lambda x: int(x[0]) if str(x[0]).isdigit() else 0):
                if not isinstance(eps, list):
                    continue
                for ep in eps:
                    if not isinstance(ep, dict):
                        continue
                    title = ep.get('title') or ep.get('name') or ('S%sE%s' % (season, ep.get('episode_num', '')))
                    ep_id = ep.get('id') or ep.get('episode_id') or ''
                    ext = ep.get('container_extension') or self.output
                    if not ep_id:
                        continue
                    url = '%s/series/%s/%s/%s.%s' % (
                        self.host, self.username, self.password, ep_id, ext
                    )
                    self.addVideo({
                        'title': title,
                        'url': url,
                        'icon': cItem.get('icon', ''),
                        'stream_id': str(ep_id),
                        'content_type': 'series'
                    })
        elif isinstance(episodes, list):
            for ep in episodes:
                if not isinstance(ep, dict):
                    continue
                title = ep.get('title') or ep.get('name') or ''
                ep_id = ep.get('id') or ''
                ext = ep.get('container_extension') or self.output
                if not ep_id:
                    continue
                url = '%s/series/%s/%s/%s.%s' % (
                    self.host, self.username, self.password, ep_id, ext
                )
                self.addVideo({
                    'title': title,
                    'url': url,
                    'icon': cItem.get('icon', ''),
                    'stream_id': str(ep_id),
                    'content_type': 'series'
                })


    # ------------------------------------------------------------------
    # IPAudioPro export (same path/format as Xtream2Audio plugin)
    # ------------------------------------------------------------------
    def _ipa_paths(self):
        # order: official Xtream2Audio path first
        return (
            "/etc/enigma2/IPAudioPro.json",
            "/etc/IPAudioPro.json",
            "/hdd/IPAudioPro.json",
            "/tmp/IPAudioPro.json",
        )

    def _ipa_find_file(self):
        for p in self._ipa_paths():
            if os.path.isfile(p):
                return p
        return self._ipa_paths()[0]

    def _ipa_load_all(self):
        data = {"Playlist": {"streams": []}}
        path = None
        for p in self._ipa_paths():
            if os.path.isfile(p):
                path = p
                break
        if not path:
            return data
        try:
            with open(path, "r") as f:
                content = f.read().strip()
            if not content:
                return data
            raw = json_loads(content)
            if isinstance(raw, dict):
                data = raw
            if "Playlist" not in data or not isinstance(data.get("Playlist"), dict):
                data["Playlist"] = {"streams": []}
            if "streams" not in data["Playlist"] or not isinstance(data["Playlist"]["streams"], list):
                data["Playlist"]["streams"] = []
        except Exception:
            printExc()
        return data

    def _ipa_write(self, data):
        text = json_dumps(data, indent=4)
        last_err = ""
        for path in self._ipa_paths():
            try:
                d = os.path.dirname(path)
                if d and not os.path.isdir(d):
                    os.makedirs(d)
                with open(path, "w") as f:
                    f.write(text)
                printDBG("IPAudioPro wrote %s" % path)
                return path
            except Exception as e:
                last_err = str(e)
                printDBG("IPAudioPro write fail %s: %s" % (path, last_err))
        return None

    def _ipa_add_streams(self, streams, group=None):
        """
        streams: list of dicts {name, display_name, url}
        If group is None -> append into Playlist.streams (Xtream2Audio style)
        If group is set  -> replace/create that top-level group only
        """
        data = self._ipa_load_all()
        if group:
            data[group] = {"streams": list(streams)}
            target = data[group]["streams"]
        else:
            if "Playlist" not in data or not isinstance(data["Playlist"], dict):
                data["Playlist"] = {"streams": []}
            if not isinstance(data["Playlist"].get("streams"), list):
                data["Playlist"]["streams"] = []
            target = data["Playlist"]["streams"]
            existing = set()
            for s in target:
                if isinstance(s, dict) and s.get("url"):
                    existing.add(s["url"])
            for s in streams:
                u = s.get("url")
                if u and u not in existing:
                    target.append(s)
                    existing.add(u)
        path = self._ipa_write(data)
        return path, len(target)

    def listIpaMenu(self, cItem):
        idx = cItem.get("playlist_idx", 0)
        self.addDir({
            "category": "ipa_export_all",
            "title": _("Export ALL Live → IPAudioPro (Playlist)"),
            "playlist_idx": idx,
            "desc": _("Appends into Playlist.streams like Xtream2Audio"),
        })
        self.addDir({
            "category": "ipa_export_all_group",
            "title": _("Export ALL Live as new group"),
            "playlist_idx": idx,
            "desc": _("Creates group XStreamity <host>"),
        })
        self.addDir({
            "category": "ipa_export_cats",
            "title": _("Export by category → IPAudioPro"),
            "playlist_idx": idx,
        })
        path = self._ipa_find_file()
        data = self._ipa_load_all()
        groups = list(data.keys())
        n = 0
        try:
            n = len(data.get("Playlist", {}).get("streams", []))
        except Exception:
            pass
        self.addDir({
            "category": "info",
            "title": _("File: %s") % path,
            "desc": _("Groups: %s | Playlist streams: %d") % (", ".join(groups), n),
        })

    def listIpaCats(self, cItem):
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return
        data = self._api("get_live_categories")
        if not data or not isinstance(data, list):
            self.addDir({"category": "info", "title": _("No categories")})
            return
        for cat in data:
            if not isinstance(cat, dict):
                continue
            title = cat.get("category_name") or cat.get("name") or ""
            cid = cat.get("category_id") or cat.get("id") or ""
            if not title:
                continue
            self.addDir({
                "category": "ipa_export_cat",
                "title": title,
                "cat_id": str(cid),
                "playlist_idx": cItem.get("playlist_idx", 0),
            })

    def doIpaExport(self, cItem, cat_id=None, as_group=False):
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                self.addDir({"category": "info", "title": _("Auth failed")})
                return
        if cat_id:
            data = self._api("get_live_streams", "&category_id=" + str(cat_id))
        else:
            data = self._api("get_live_streams")
        if not data or not isinstance(data, list):
            self.addDir({"category": "info", "title": _("No channels from API")})
            return

        fmt = (self.output or "ts").lstrip(".")
        streams = []
        for ch in data:
            if not isinstance(ch, dict):
                continue
            name = ch.get("name") or ch.get("title") or ""
            stream_id = ch.get("stream_id") or ch.get("id") or ""
            if not name or not stream_id:
                continue
            # same URL style as Xtream2Audio
            url = "%s/live/%s/%s/%s.%s" % (self.host, self.username, self.password, stream_id, fmt)
            streams.append({
                "name": name,
                "display_name": name,
                "url": url,
            })

        if not streams:
            self.addDir({"category": "info", "title": _("0 streams to export")})
            return

        group = None
        if as_group:
            host = self.host or "export"
            try:
                from urllib.parse import urlparse
            except ImportError:
                from urlparse import urlparse
            try:
                h = urlparse(host).hostname or host
            except Exception:
                h = host.replace("http://", "").replace("https://", "").split("/")[0]
            if cat_id:
                group = "XStreamity %s - %s" % (h, cItem.get("title") or cat_id)
            else:
                group = "XStreamity %s" % h
        elif cat_id:
            # category export as named group
            group = "XStreamity %s" % (cItem.get("title") or cat_id)

        path, total = self._ipa_add_streams(streams, group=group)
        if path:
            self.addDir({
                "category": "info",
                "title": _("OK: %d streams (total in target %d)") % (len(streams), total),
                "desc": path + ((" [" + group + "]") if group else " [Playlist]"),
            })
        else:
            self.addDir({
                "category": "info",
                "title": _("FAILED to write IPAudioPro file"),
                "desc": ", ".join(self._ipa_paths()),
            })

    # ------------------------------------------------------------------
    # Catchup / Archive
    # ------------------------------------------------------------------
    def listCatchupChannels(self, cItem):
        printDBG('XStreamity.listCatchupChannels')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        data = self._api('get_live_streams')
        if not data or not isinstance(data, list):
            return

        for ch in data:
            if not isinstance(ch, dict):
                continue
            # only channels with archive enabled
            tv_archive = str(ch.get('tv_archive', ch.get('archive', '0'))).strip().lower()
            duration = str(ch.get('tv_archive_duration', '0')).strip()
            if tv_archive not in ('1', 'true', 'yes'):
                continue
            if not duration.isdigit() or int(duration) <= 0:
                continue

            name = ch.get('name') or ch.get('title') or ''
            stream_id = ch.get('stream_id') or ch.get('id') or ''
            logo = ch.get('stream_icon') or ''
            if not name or not stream_id:
                continue

            self.addDir({
                'category': 'catchup_epg',
                'title': name,
                'stream_id': str(stream_id),
                'archive_duration': duration,
                'icon': logo,
                'playlist_idx': cItem.get('playlist_idx', 0),
                'desc': _('Archive: %s hours') % duration
            })

    def listCatchupEPG(self, cItem):
        printDBG('XStreamity.listCatchupEPG')
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        stream_id = cItem.get('stream_id', '')
        if not stream_id:
            return

        # get_simple_data_table returns recent programmes with archive marks
        data = self._api('get_simple_data_table', '&stream_id=' + str(stream_id))
        if not data:
            return

        # response can be list or dict with epg_listings
        programmes = []
        if isinstance(data, list):
            programmes = data
        elif isinstance(data, dict):
            programmes = data.get('epg_listings') or data.get('data') or []

        if not isinstance(programmes, list):
            return

        for prog in programmes:
            if not isinstance(prog, dict):
                continue
            # only archived programmes
            has_archive = str(prog.get('has_archive', prog.get('mark_archive', '0'))).lower()
            if has_archive not in ('1', 'true', 'yes'):
                # some panels don't set the flag - still show if start is in the past
                pass

            title = prog.get('title') or prog.get('name') or _('Unknown')
            # times can be unix or formatted
            start = prog.get('start') or prog.get('start_timestamp') or prog.get('time') or ''
            end = prog.get('end') or prog.get('end_timestamp') or ''
            description = prog.get('description') or prog.get('plot') or ''

            # duration in minutes
            duration_min = '0'
            try:
                if start and end:
                    # try unix timestamps
                    s = int(str(start)[:10]) if str(start).isdigit() else 0
                    e = int(str(end)[:10]) if str(end).isdigit() else 0
                    if s and e and e > s:
                        duration_min = str(int((e - s) / 60))
            except Exception:
                duration_min = str(prog.get('duration', '60'))

            # date format for timeshift URL: YYYY-MM-DD:HH-MM
            date_str = ''
            try:
                if str(start).isdigit():
                    import time as _time
                    date_str = _time.strftime('%Y-%m-%d:%H-%M', _time.localtime(int(str(start)[:10])))
                else:
                    # already formatted?
                    date_str = str(start).replace(' ', ':')[:16]
            except Exception:
                date_str = str(start)

            if not date_str:
                continue

            # timeshift URL
            playurl = '%s/timeshift/%s/%s/%s/%s/%s.%s' % (
                self.host, self.username, self.password,
                duration_min, date_str, stream_id, self.output
            )

            display = title
            if date_str:
                display = '[%s] %s' % (date_str, title)

            self.addVideo({
                'title': display,
                'url': playurl,
                'icon': cItem.get('icon', ''),
                'content_type': 'catchup',
                'desc': description,
                'stream_id': str(stream_id)
            })

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG('XStreamity.listSearchResult [%s]' % searchPattern)
        if not self._ensure_auth():
            self._reauth(cItem)
            if not self._ensure_auth():
                return

        # simple live search by filtering all live streams
        data = self._api('get_live_streams')
        if not data or not isinstance(data, list):
            return
        pattern = searchPattern.lower()
        for ch in data:
            if not isinstance(ch, dict):
                continue
            name = ch.get('name') or ''
            if pattern not in name.lower():
                continue
            stream_id = ch.get('stream_id') or ch.get('id') or ''
            if not stream_id:
                continue
            url = self._stream_url(stream_id, 'live')
            self.addVideo({
                'title': name,
                'url': url,
                'icon': ch.get('stream_icon', ''),
                'stream_id': str(stream_id),
                'content_type': 'live'
            })

    # ------------------------------------------------------------------
    # getLinksForVideo
    # ------------------------------------------------------------------
    def getLinksForVideo(self, cItem):
        printDBG('XStreamity.getLinksForVideo [%s]' % cItem)
        linksTab = []
        url = cItem.get('url', '')
        if not url:
            return linksTab

        # already a direct stream URL
        headers = {'User-Agent': self.HTTP_HEADER.get('User-Agent', '')}
        stream = strwithmeta(url, headers)
        linksTab.append({'name': 'XStreamity Stream', 'url': stream, 'need_resolve': 0})
        return linksTab

    def _reauth(self, cItem):
        idx = cItem.get('playlist_idx', 0)
        if not self.playlists:
            self._load_playlists()
        if self.playlists and 0 <= idx < len(self.playlists):
            self._setup_from_playlist(self.playlists[idx])
        elif idx == -1:
            self._setup_from_playlist({'playlist_info': {}})

    # ------------------------------------------------------------------
    # handleService
    # ------------------------------------------------------------------
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('XStreamity.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get('name', '')
        category = self.currItem.get('category', '')
        self.currList = []

        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'select_playlist':
            self.listAfterSelect(self.currItem)
        elif category == 'live_categories':
            self.listLiveCategories(self.currItem)
        elif category == 'live_streams':
            self.listLiveStreams(self.currItem)
        elif category == 'vod_categories':
            self.listVodCategories(self.currItem)
        elif category == 'vod_streams':
            self.listVodStreams(self.currItem)
        elif category == 'series_categories':
            self.listSeriesCategories(self.currItem)
        elif category == 'series_list':
            self.listSeries(self.currItem)
        elif category == 'series_info':
            self.listSeriesInfo(self.currItem)
        elif category == 'catchup_channels':
            self.listCatchupChannels(self.currItem)
        elif category == 'catchup_epg':
            self.listCatchupEPG(self.currItem)
        elif category == 'ipa_menu':
            self.listIpaMenu(self.currItem)
        elif category == 'ipa_export_cats':
            self.listIpaCats(self.currItem)
        elif category == 'ipa_export_all':
            self.doIpaExport(self.currItem, cat_id=None, as_group=False)
        elif category == 'ipa_export_all_group':
            self.doIpaExport(self.currItem, cat_id=None, as_group=True)
        elif category == 'ipa_export_cat':
            self.doIpaExport(self.currItem, cat_id=self.currItem.get('cat_id'), as_group=True)
        elif category in ['search', 'search_next_page']:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == 'search_history':
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _('Type: '))
        elif category == 'info':
            pass
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, XStreamity(), True, [])
