# -*- coding: utf-8 -*-
# hostegydead.py - E2iPlayer Host for EgyDead
# Fully compatible with Python 3.14 (OpenATV 8.0.2 / Vu+ Solo4K) and Python 2.7
# Fixed Character Encoding (100% 7-bit ASCII safe - Zero SyntaxErrors on any image)
# MegaMax Inertia Resolver & Direct Stream Decoders (StreamWish, Uqload, VidHide, etc.)
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, E2ColoR
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
###################################################
from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import urljoin
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
###################################################
# FOREIGN import
###################################################
import re
import time
import base64
###################################################

def GetConfigList():
    return []

def gettytul():
    return 'https://tv10.egydead.live'

class EgyDead(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'egydead', 'cookie': 'egydead.cookie'})
        self.MAIN_URL = gettytul()
        self.SEARCH_URL = self.MAIN_URL + '?s='
        self.DEFAULT_ICON_URL = "https://c4u1r.sbs/wp-content/uploads/2026/03/EgyDead-Logo.png"
        self.HEADER = self.cm.getDefaultHeader(browser='chrome')
        self.defaultParams = {
            'header': self.HEADER,
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': True,
            'cookiefile': self.COOKIE_FILE
        }
        # Unified words list for cleaning titles (encoded in safe ASCII unicode escapes)
        self.CLEAN_WORDS = [
            u"\u0645\u0634\u0627\u0647\u062f\u0629 \u0641\u064a\u0644\u0645",
            u"\u0645\u0634\u0627\u0647\u062f\u0629",
            u"\u0641\u064a\u0644\u0645",
            u"\u0645\u0633\u0644\u0633\u0644",
            u"\u0645\u062a\u0631\u062c\u0645\u0629 \u0627\u0648\u0646 \u0644\u0627\u064a\u0646",
            u"\u0645\u062a\u0631\u062c\u0645 \u0627\u0648\u0646 \u0644\u0627\u064a\u0646",
            u"\u0645\u062a\u0631\u062c\u0645\u0629",
            u"\u0645\u062a\u0631\u062c\u0645",
            u"\u0627\u0648\u0646 \u0644\u0627\u064a\u0646",
            u"\u0645\u062f\u0628\u0644\u062c\u0629",
            u"\u0645\u062f\u0628\u0644\u062c",
            u"\u0643\u0631\u062a\u0648\u0646",
            u"\u0627\u0646\u0645\u064a",
            u"\u0628\u0627\u0644\u0645\u0635\u0631\u064a",
            u"\u0633\u0644\u0633\u0644\u0629 \u0627\u0641\u0644\u0627\u0645",
            u"\u0639\u0631\u0636",
            u"\u0628\u0631\u0646\u0627\u0645\u062c",
            u"\u062c\u0645\u064a\u0639 \u0645\u0648\u0627\u0633\u0645"
        ]
        # In-memory cache for MegaMax Inertia version
        self.megamax_version = "a601a2d0d16b8ae7121ceb1fd46c1f5a"

    def getPage(self, baseUrl, addParams=None, post_data=None):
        if any(ord(c) > 127 for c in baseUrl):
            baseUrl = urllib_quote_plus(baseUrl, safe="://?&=#%")
        if addParams is None:
            addParams = dict(self.defaultParams)
        addParams["cloudflare_params"] = {
            "cookie_file": self.COOKIE_FILE,
            "User-Agent": self.HEADER.get("User-Agent")
        }
        if post_data is None:
            addParams["load_cookie"] = False
            addParams["save_cookie"] = True
        max_retries = 3
        for attempt in range(max_retries):
            try:
                sts, data = self.cm.getPageCFProtection(baseUrl, addParams, post_data)
                if sts and data:
                    return sts, data
            except Exception as e:
                printDBG('EgyDead.getPage retry %d failed: %s' % (attempt + 1, str(e)))
                time.sleep(1.2)
        printDBG("[EgyDead] Retrying %s failed after %d attempts." % (baseUrl, max_retries))
        return False, ''

    def listMainMenu(self, cItem):
        printDBG('EgyDead.listMainMenu')
        MAIN_CAT_TAB = [
            {'category': 'movies_categories', 'title': 'Movies'},
            {'category': 'series_categories', 'title': 'Series'},
            {'category': 'anime_categories', 'title': 'Anime'},
            {'category': 'other_categories', 'title': 'Others'},
            {'category': 'watch_by_type', 'title': 'Watch By Type'},
        ] + self.searchItems()
        self.listsTab(MAIN_CAT_TAB, cItem)

        self.MOVIES_CAT_TAB = [
            {'category': 'list_units', 'title': 'English Movies', 'url': self.getFullUrl('/category/english-movies/')},
            {'category': 'list_units', 'title': 'Arabic Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%8A/')},
            {'category': 'list_units', 'title': 'Asian Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%B3%D9%8A%D9%88%D9%8A%D8%A9/')},
            {'category': 'list_units', 'title': 'Turkish Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%AA%D8%B1%D9%83%D9%8A%D8%A9/')},
            {'category': 'list_units', 'title': 'Indian Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A%D8%A9/')},
            {'category': 'list_units', 'title': 'English Dubbed Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D8%AC%D9%86%D8%A8%D9%8A%D8%A9-%D9%85%D8%AF%D8%A8%D9%84%D8%AC%D8%A9/')},
            {'category': 'list_units', 'title': 'Turkish Dubbed Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%AA%D8%B1%D9%83%D9%8A%D8%A9-%D9%85%D8%AF%D8%A8%D9%84%D8%AC%D8%A9/')},
            {'category': 'list_units', 'title': 'Indian Dubbed Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%87%D9%86%D8%AF%D9%8A%D8%A9-%D9%85%D8%AF%D8%A8%D9%84%D8%AC%D8%A9/')},
            {'category': 'list_units', 'title': 'Eslam Elgizawy Subbed Movies', 'url': self.getFullUrl('/category/%D8%AA%D8%B1%D8%AC%D9%85%D8%A7%D8%AA-%D8%A7%D8%B3%D9%84%D8%A7%D9%85-%D8%A7%D9%84%D8%AC%D9%8A%D8%B2%D8%A7%D9%88%D9%8A/')},
            {'category': 'list_units', 'title': 'Documentary Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%88%D8%AB%D8%A7%D8%A6%D9%82%D9%8A%D8%A9/')},
            {'category': 'list_units', 'title': 'Cartoon Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%83%D8%B1%D8%AA%D9%88%D9%86/')},
            {'category': 'list_units', 'title': 'Cartoon Movies Egyptian Voice', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%83%D8%B1%D8%AA%D9%88%D9%86/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D9%83%D8%B1%D8%AA%D9%88%D9%86-%D8%AF%D9%8A%D8%B2%D9%86%D9%8A-%D8%A8%D8%A7%D9%84%D9%84%D9%87%D8%AC%D8%A9-%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D8%A9/')},
            {'category': 'list_seasons', 'title': 'Full Seasons Movies', 'url': self.getFullUrl('/assembly/')}
        ]
        self.SERIES_CAT_TAB = [
            {'category': 'list_units', 'title': 'English Series', 'url': self.getFullUrl('/series-category/english-series/')},
            {'category': 'list_units', 'title': 'Arabic Series', 'url': self.getFullUrl('/series-category/arabic-series/')},
            {'category': 'list_units', 'title': 'Turkish Series', 'url': self.getFullUrl('/series-category/turkish-series/')},
            {'category': 'list_units', 'title': 'Latin Series', 'url': self.getFullUrl('/series-category/latino-series/')},
            {'category': 'list_units', 'title': 'Asian Series', 'url': self.getFullUrl('/series-category/asian-series/')},
            {'category': 'list_units', 'title': 'African Series', 'url': self.getFullUrl('/series-category/african-series/')},
            {'category': 'list_units', 'title': 'Documentary Series', 'url': self.getFullUrl('/series-category/documentary-series/')},
            {'category': 'list_units', 'title': 'English Dubbed Series', 'url': self.getFullUrl('/series-category/english-series-dubbed/')},
            {'category': 'list_units', 'title': 'Turkish Dubbed Series', 'url': self.getFullUrl('/series-category/turkish-series-dubbed/')},
            {'category': 'list_units', 'title': 'Latin Dubbed Series', 'url': self.getFullUrl('/series-category/latino-series-dubbed/')},
            {'category': 'list_units', 'title': 'Asian Dubbed Series', 'url': self.getFullUrl('/series-category/asian-series-dubbed/')},
            {'category': 'list_series', 'title': 'Full Series', 'url': self.getFullUrl('/serie/')},
            {'category': 'list_series', 'title': 'Full Seasons', 'url': self.getFullUrl('/season/')},
            {'category': 'list_seasons', 'title': 'Full Episodes', 'url': self.getFullUrl('/episode/')},
        ]
        self.ANIME_CAT_TAB = [
            {'category': 'list_anime', 'title': u'Anime Movies', 'url': self.getFullUrl('/category/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%A7%D9%86%D9%85%D9%8A/')},
            {'category': 'list_anime', 'title': u'Anime Movies 2', 'url': self.getFullUrl('/series-category/anime-movies/')},
            {'category': 'list_anime', 'title': u'\u0627\u0646\u0645\u064a\u0627\u062a \u0631\u0628\u064a\u0639 2026', 'url': self.getFullUrl('/tag/%D8%A7%D9%86%D9%85%D9%8A%D8%A7%D8%AA-%D8%B1%D8%A8%D9%8A%D8%B9-2026/')},
            {'category': 'list_anime', 'title': u'\u0627\u0646\u0645\u064a\u0627\u062a \u0634\u062a\u0627\u0621 2026', 'url': self.getFullUrl('/tag/%D8%A7%D9%86%D9%85%D9%8A%D8%A7%D8%AA-%D8%B4%D8%AA%D8%A7%D8%A1-2026/')},
            {'category': 'list_anime', 'title': u'\u0627\u0646\u0645\u064a\u0627\u062a \u0635\u064a\u0646\u064a\u0629', 'url': self.getFullUrl('/series-category/chinese-anime/')},
            {'category': 'list_anime', 'title': u'\u0627\u0646\u0645\u064a\u0627\u062a \u0643\u0648\u0631\u064a\u0629', 'url': self.getFullUrl('/series-category/korean-anime/')},
            {'category': 'list_anime', 'title': u'Anime Series', 'url': self.getFullUrl('/series-category/anime-series/')},
            {'category': 'list_anime', 'title': u'Anime Dubbed Series', 'url': self.getFullUrl('/series-category/anime-series-dubbed/')},
            {'category': 'list_anime', 'title': u'Cartoon Series', 'url': self.getFullUrl('/series-category/cartoon-series/')},
            {'category': 'list_anime', 'title': u'Cartoon Dubbed Series', 'url': self.getFullUrl('/series-category/cartoon-series-dubbed/')}
        ]
        self.OTHER_CAT_TAB = [
            {'category': 'list_other', 'title': u'Stand UP Shows', 'url': self.getFullUrl('/category/%D8%B9%D8%B1%D9%88%D8%B6-%D9%88%D8%AD%D9%81%D9%84%D8%A7%D8%AA/')},
            {'category': 'list_other', 'title': u'Sport', 'url': self.getFullUrl('/category/%D8%B1%D9%8A%D8%A7%D8%B6%D8%A9/')},
            {'category': 'list_other', 'title': u'TV Shows', 'url': self.getFullUrl('/series-category/tv-shows/')},
            {'category': 'list_other', 'title': u'\u0643\u0627\u0633 \u0627\u0644\u0639\u0627\u0644\u0645 2022', 'url': self.getFullUrl('/tag/%D9%83%D8%A7%D8%B3-%D8%A7%D9%84%D8%B9%D8%A7%D9%84%D9%85-2022/')}
        ]

    def listMoviesCategories(self, cItem):
        printDBG('EgyDead.listMoviesCategories')
        self.listsTab(self.MOVIES_CAT_TAB, cItem)

    def listSeriesCategories(self, cItem):
        printDBG('EgyDead.listSeriesCategories')
        self.listsTab(self.SERIES_CAT_TAB, cItem)

    def listAnimeCategories(self, cItem):
        printDBG('EgyDead.listAnimeCategories')
        self.listsTab(self.ANIME_CAT_TAB, cItem)

    def listOtherCategories(self, cItem):
        printDBG('EgyDead.listOtherCategories')
        self.listsTab(self.OTHER_CAT_TAB, cItem)

    def _formatTitle(self, title):
        title = self.cleanHtmlStr(title)
        for word in self.CLEAN_WORDS:
            title = title.replace(word, "")
        title = title.strip()
        match = re.search(r'(\d{4})', title)
        if match:
            year = match.group(1)
            parts = title.split(year, 1)
            prefix = parts[0].strip()
            suffix = parts[1].strip()
            formatted = ("%s%s %s%s %s%s%s" % (
                E2ColoR('yellow'), prefix,
                E2ColoR('cyan'), year,
                E2ColoR('yellow'), suffix,
                E2ColoR('white')
            )).replace('  ', ' ').strip()
        else:
            formatted = "%s%s%s" % (E2ColoR('yellow'), title, E2ColoR('white'))
        return formatted

    def _extractMetadata(self, data):
        label_map = {
            u'\u0627\u0644\u0642\u0633\u0645': 'Section',
            u'\u0627\u0644\u0646\u0648\u0639': 'Genre',
            u'\u0627\u0644\u0644\u063a\u0647': 'Language',
            u'\u0627\u0644\u0628\u0644\u062f': 'Country',
            u'\u0627\u0644\u0633\u0646\u0647': 'Year',
            u'\u0645\u062f\u0647 \u0627\u0644\u0639\u0631\u0636': 'Duration',
            u'\u0627\u0644\u062c\u0648\u062f\u0647': 'Quality'
        }
        order = ['Section', 'Genre', 'Language', 'Country', 'Year', 'Duration', 'Quality']
        info_part = self.cm.ph.getDataBeetwenMarkers(data, '<div class="LeftBox">', '</div>', False)[1]
        info_items = re.findall(r'<li>.*?</li>', info_part, re.S)
        info_dict = {}
        for item in info_items:
            raw_label = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item, '<span>', '</span>', False)[1])
            label = raw_label.replace(':', '').strip()
            value = ', '.join(re.findall(r'>([^<]+)</a>', item))
            if not value: continue
            label_en = label_map.get(label, label)
            info_dict[label_en] = value
        info_parts = []
        for key in order:
            if key in info_dict:
                info_parts.append('%s%s%s : %s%s%s' % (
                    E2ColoR('cyan'), key, E2ColoR('white'),
                    E2ColoR('yellow'), info_dict[key], E2ColoR('white')
                ))
        info_text = ' | '.join(info_parts)
        story_part = self.cm.ph.getDataBeetwenMarkers(data, '<div class="extra-content">', '</div>', False)[1]
        story = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(story_part, '<p>', '</p>', False)[1])
        full_desc = '%s\n%sStory : %s%s%s' % (info_text, E2ColoR('lime'), E2ColoR('white'), story, E2ColoR('white'))
        return info_text, story, full_desc

    def _addMediaDir(self, cItem, item_html, next_category, data_source='li'):
        if data_source == 'li':
            url = self.cm.ph.getSearchGroups(item_html, r'href="([^"]+)"')[0]
            icon = self.cm.ph.getSearchGroups(item_html, r'data-lazy-style="[^"]*url\(([^)]+)\)')[0]
            if not icon:
                icon = self.cm.ph.getSearchGroups(item_html, r'(?:data-src|src)="([^"]+)"')[0]
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item_html, r'title="([^"]+)"')[0])
            if not title:
                title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item_html, '<h1', '</h1>', False)[1])
            if not title:
                title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item_html, '<h2', '</h2>', False)[1])
            category = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item_html, '<span class="cat_name">', '</span>', False)[1])
        else:
            url = self.cm.ph.getSearchGroups(item_html, r'href="([^"]+)"')[0]
            icon = self.cm.ph.getSearchGroups(item_html, r'<img[^>]+src="([^"]+)"')[0]
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item_html, r'title="([^"]+)"')[0])
            if not title:
                title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item_html, '<h1', '</h1>', False)[1])
            category = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item_html, '<span class="cat_name">', '</span>', False)[1])
        if not url: return
        if icon:
            try: icon = urllib_quote_plus(icon, safe=':/?&=#%')
            except Exception as e: printDBG('icon encode error: %s' % e)
        title = self._formatTitle(title)
        desc = "%s" % category
        params = dict(cItem)
        params.update({
            'title': title,
            'url': self.getFullUrl(url),
            'icon': self.getFullUrl(icon),
            'desc': desc,
            'category': next_category
        })
        self.addDir(params)

    def _listPosts(self, cItem, next_category, posts_list_index=1, block_marker='<ul class="posts-list">'):
        printDBG('EgyDead._listPosts >>> %s' % cItem)
        sts, data = self.getPage(cItem['url'])
        if not sts or not data:
            printDBG('_listPosts: failed to load page')
            return
        main_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="catHolder">', '<div class="pagination">', False)[1]
        if not main_block:
            main_block = data 
        allblocks = self.cm.ph.getAllItemsBeetwenMarkers(main_block, block_marker, '</ul>')
        if len(allblocks) > posts_list_index:
            allblocks = allblocks[posts_list_index]
            items = self.cm.ph.getAllItemsBeetwenMarkers(allblocks, '<li', '</li>')
        else:
            items = self.cm.ph.getAllItemsBeetwenMarkers(main_block, '<li', '</li>')
        for item in items:
            self._addMediaDir(cItem, item, next_category, data_source='li')
        if len(items) == 0:
            printDBG('_listPosts: No media-card items found')
        
        # Pagination
        pagination_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="pagination">', '</div>', False)[1]
        if pagination_block:
            next_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="next page-numbers"[^>]+href="([^"]+)"')[0]
            prev_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="prev page-numbers"[^>]+href="([^"]+)"')[0]
            category_name = cItem.get('category', 'list_units')
            if prev_url:
                params = dict(cItem)
                params.update({'title': '%s<<< %s' % (E2ColoR('cyan'), _('Previous')), 'url': self.getFullUrl(prev_url), 'category': category_name})
                self.addDir(params)
            if next_url:
                params = dict(cItem)
                params.update({'title': '%s %s>>>' % (_('Next'), E2ColoR('cyan')), 'url': self.getFullUrl(next_url), 'category': category_name})
                self.addDir(params)

    def listUnits(self, cItem):
        self._listPosts(cItem, next_category='explore_items', posts_list_index=1)

    def listSeries(self, cItem):
        self._listPosts(cItem, next_category='explore_seasons', posts_list_index=0)

    def listSearchUnits(self, cItem):
        printDBG('EgyDead.listSearchUnits >>> %s' % cItem)
        sts, data = self.getPage(cItem['url'])
        if not sts or not data: return
        main_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="catHolder">', '</div>', False)[1]
        if not main_block: main_block = data
        items = self.cm.ph.getAllItemsBeetwenMarkers(main_block, '<li', '</li>')
        for item in items:
            self._addMediaDir(cItem, item, next_category='explore_items', data_source='li')
        pagination_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="pagination">', '</div>', False)[1]
        if pagination_block:
            next_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="next page-numbers"[^>]+href="([^"]+)"')[0]
            prev_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="prev page-numbers"[^>]+href="([^"]+)"')[0]
            if prev_url:
                params = dict(cItem)
                params.update({'title': '%s<<< %s' % (E2ColoR('cyan'), _('Previous')), 'url': self.getFullUrl(prev_url), 'category': 'search_next_page'})
                self.addDir(params)
            if next_url:
                params = dict(cItem)
                params.update({'title': '%s %s>>>' % (_('Next'), E2ColoR('cyan')), 'url': self.getFullUrl(next_url), 'category': 'search_next_page'})
                self.addDir(params)

    def listAssembly(self, cItem):
        printDBG('EgyDead.listAssembly >>> %s' % cItem)
        sts, data = self.getPage(cItem['url'])
        if not sts or not data: return
        main_block = self.cm.ph.getDataBeetwenMarkers(data, '<ul class="posts-list">', '</ul>', False)[1]
        if not main_block: main_block = data
        items = self.cm.ph.getAllItemsBeetwenMarkers(main_block, '<li', '</li>')
        for item in items:
            self._addMediaDir(cItem, item, next_category='list_units', data_source='li')
        pagination_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="pagination">', '</div>', False)[1]
        if pagination_block:
            next_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="next page-numbers"[^>]+href="([^"]+)"')[0]
            prev_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="prev page-numbers"[^>]+href="([^"]+)"')[0]
            if not prev_url:
                prev_url = self.cm.ph.getSearchGroups(pagination_block, r'<a[^>]+class="page-numbers"[^>]+href="([^"]+)"[^>]*>\s*1\s*</a>')[0]
            if prev_url:
                params = dict(cItem)
                params.update({'title': '%s<<< %s' % (E2ColoR('cyan'), _('Previous')), 'url': self.getFullUrl(prev_url), 'category': 'list_seasons'})
                self.addDir(params)
            if next_url:
                params = dict(cItem)
                params.update({'title': '%s %s>>>' % (_('Next'), E2ColoR('cyan')), 'url': self.getFullUrl(next_url), 'category': 'list_seasons'})
                self.addDir(params)

    def _resolveMegaMax(self, megamax_url):
        """
        Resolves MegaMax aggregator iframe into multiple playable mirrors:
        StreamWish, Uqload, Mixdrop, DoodStream, VidHide, StreamRuby, VOE, etc.
        """
        printDBG("EgyDead._resolveMegaMax url[%s]" % megamax_url)
        urlsTab = []
        try:
            def fetch_streams_partial(version):
                ajaxParams = dict(self.defaultParams)
                ajaxParams['header'] = {
                    'User-Agent': self.HEADER.get('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
                    'Referer': self.MAIN_URL,
                    'X-Inertia': 'true',
                    'X-Inertia-Version': version,
                    'X-Inertia-Partial-Component': 'files/mirror/video',
                    'X-Inertia-Partial-Data': 'streams',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'text/html, application/xhtml+xml'
                }
                sts, ajax_data = self.getPage(megamax_url, ajaxParams)
                if sts and ajax_data:
                    try:
                        return json_loads(ajax_data)
                    except Exception:
                        pass
                return None

            res = fetch_streams_partial(self.megamax_version)

            if not res or not res.get('props', {}).get('streams', {}).get('data'):
                params = dict(self.defaultParams)
                params['header'] = {
                    'User-Agent': self.HEADER.get('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
                    'Referer': self.MAIN_URL,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
                sts, data = self.getPage(megamax_url, params)
                if sts and data:
                    version = self.cm.ph.getSearchGroups(data, r"""version["']\s*:\s*["']([^"']+)""")[0]
                    if version:
                        self.megamax_version = version
                        res = fetch_streams_partial(self.megamax_version)

            if res:
                data_list = res.get('props', {}).get('streams', {}).get('data', [])
                for item in data_list:
                    label = item.get('label', 'HD')
                    mirrors = item.get('mirrors', [])
                    for mirror in mirrors:
                        driver = mirror.get('driver', 'server')
                        link = mirror.get('link', '')
                        if not link:
                            continue
                        if link.startswith('//'):
                            link = 'https:' + link
                        
                        clean_driver = driver.capitalize()
                        if driver in ['streamhg', 'streamwish']:
                            clean_driver = 'StreamWish (Fast)'
                        elif driver == 'uqload':
                            clean_driver = 'Uqload (Original 1080p)'
                        elif driver == 'mixdrop':
                            clean_driver = 'MixDrop'
                        elif driver in ['vidhidevip', 'earnvids']:
                            clean_driver = 'VidHide VIP'
                        elif driver in ['stmruby', 'streamruby']:
                            clean_driver = 'StreamRuby'
                        elif driver == 'voe':
                            clean_driver = 'VOE'
                        elif driver == 'doodstream':
                            clean_driver = 'DoodStream'

                        srv_title = "[MegaMax] %s - [%s]" % (clean_driver, label)
                        urlsTab.append({
                            'name': srv_title,
                            'url': strwithmeta(link, {'Referer': 'https://megamax.me/', 'User-Agent': self.HEADER.get('User-Agent')}),
                            'need_resolve': 1
                        })
        except Exception as e:
            printExc()
            printDBG("EgyDead._resolveMegaMax error: %s" % str(e))
        return urlsTab

    def _resolveUqload(self, url):
        printDBG("EgyDead._resolveUqload url[%s]" % url)
        urlTab = []
        try:
            params = dict(self.defaultParams)
            params['header'] = {
                'User-Agent': self.HEADER.get('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
                'Referer': 'https://megamax.me/'
            }
            sts, data = self.getPage(url, params)
            if not sts or not data: return urlTab

            match = re.search(r"""sources\s*:\s*\[\s*["'](http[^"']+)["']""", data)
            if not match:
                match = re.search(r"""file\s*:\s*["'](http[^"']+)["']""", data)
            if not match:
                match = re.search(r"""src=["'](http[^"']+)["']""", data)

            if match:
                direct_url = match.group(1)
                if direct_url.startswith('//'): direct_url = 'https:' + direct_url
                printDBG("EgyDead._resolveUqload found direct: %s" % direct_url)
                if '.m3u8' in direct_url:
                    urlTab.extend(getDirectM3U8Playlist(direct_url, checkContent=True))
                else:
                    urlTab.append({'name': 'Uqload Direct MP4', 'url': strwithmeta(direct_url, {'Referer': url})})
        except Exception as e:
            printDBG("EgyDead._resolveUqload error: %s" % str(e))
        return urlTab

    def exploreItems(self, cItem):
        printDBG('EgyDead.exploreItems >>> %s' % cItem)
        url = cItem.get('url', '')
        sts, data1 = self.getPage(url)
        if not sts or not data1: return
        info_text, story, full_desc = self._extractMetadata(data1)
        work_title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(data1, '<div class="singleTitle">', '</div>', False)[1])
        if not work_title:
            work_title = self.cleanHtmlStr(cItem.get('title', ''))

        if '/series/' in url or '/season/' in url:
            printDBG('Season page detected -- listing episodes...')
            cItem = dict(cItem)
            cItem['desc'] = full_desc
            return self.listEpisodes(cItem, data1)

        params = dict(self.defaultParams)
        params.update({'header': {'Content-Type': 'application/x-www-form-urlencoded', 'Referer': url}})
        post_data = {'View': '1'}
        sts, data = self.getPage(url, params, post_data)
        if not sts or not data: return

        if 'salery-list' in data1:
            block = self.cm.ph.getDataBeetwenMarkers(data1, '<div class="salery-list">', '</ul>', False)[1]
            items = self.cm.ph.getAllItemsBeetwenMarkers(block, '<li', '</li>')
            for item in items:
                self._addMediaDir(cItem, item, next_category='explore_items', data_source='li')
            return

        if 'seasons-list' in data1:
            block = self.cm.ph.getDataBeetwenMarkers(data1, '<div class="seasons-list">', '</ul>', False)[1]
            items = self.cm.ph.getAllItemsBeetwenMarkers(block, '<li', '</li>')
            for item in items:
                self._addMediaDir(cItem, item, next_category='explore_items', data_source='li')
            return

        # 1. Watch servers in serversList
        watch_list = self.cm.ph.getDataBeetwenMarkers(data, '<ul class="serversList">', '</ul>', False)[1]
        if watch_list:
            li_items = self.cm.ph.getAllItemsBeetwenMarkers(watch_list, '<li', '</li>')
            for item in li_items:
                video_url = self.cm.ph.getSearchGroups(item, r'data-link="([^"]+)"')[0]
                title = self.cm.ph.getSearchGroups(item, r'<p>([^<]+)</p>')[0].strip()
                if not title: title = self.cm.ph.getSearchGroups(item, r'>([^<]+)</span>')[0].strip()
                title = self.cleanHtmlStr(title)
                if not title: title = 'MegaMax Server'

                if work_title:
                    video_title = "%s%s%s - [%s]" % (E2ColoR('yellow'), work_title, E2ColoR('white'), title)
                else:
                    video_title = title

                params = dict(cItem)
                params.update({'title': video_title, 'url': video_url, 'category': 'video', 'type': 'video', 'desc': full_desc})
                self.addVideo(params)

        # 2. Download servers in donwload-servers-list
        dl_block = self.cm.ph.getDataBeetwenMarkers(data, '<ul class="donwload-servers-list">', '</ul>', False)[1]
        if dl_block:
            dl_items = self.cm.ph.getAllItemsBeetwenMarkers(dl_block, '<li', '</li>')
            for dl_item in dl_items:
                dl_name = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(dl_item, '<span class="ser-name">', '</span>', False)[1])
                dl_res = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(dl_item, '<div class="server-info">', '</div>', False)[1])
                dl_url = self.cm.ph.getSearchGroups(dl_item, r'href="([^"]+)"')[0]
                if dl_url and dl_name:
                    dl_title = "%s%s%s - [DL: %s %s]" % (E2ColoR('cyan'), work_title, E2ColoR('white'), dl_name, dl_res)
                    params = dict(cItem)
                    params.update({'title': dl_title, 'url': dl_url, 'category': 'video', 'type': 'video', 'desc': full_desc})
                    self.addVideo(params)

    def listEpisodes(self, cItem, data1):
        printDBG('EgyDead.listEpisodes >>> %s' % cItem)
        list_episode_part = self.cm.ph.getDataBeetwenMarkers(data1, '<div class="EpsList">', '</div>', False)[1]
        if not list_episode_part: return
        episodes = self.cm.ph.getAllItemsBeetwenMarkers(list_episode_part, '<li', '</li>')
        episodes.reverse()
        for item in episodes:
            ep_url = self.cm.ph.getSearchGroups(item, r'href="([^"]+)"')[0]
            ep_title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'title="([^"]+)"')[0])
            if not ep_title: ep_title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'>([^<]+)</a>')[0])
            params = dict(cItem)
            params.update({'title': ep_title, 'url': ep_url, 'category': 'explore_items'})
            self.addDir(params)

    def exploreSeasons(self, cItem):
        printDBG('EgyDead.exploreSeasons >>> %s' % cItem)
        url = cItem.get('url', '')
        if '/episode/' in url:
            params = dict(cItem)
            params.update({'category': 'explore_items', 'title': cItem.get('title', ''), 'url': url, 'desc': cItem.get('desc', '')})
            self.addDir(params)
            return

        sts, data = self.getPage(url)
        if not sts or not data: return
        info_text, story, full_desc = self._extractMetadata(data)

        def colorTitle(title):
            match = re.search(r'(\d{4})', title)
            if match:
                year = match.group(1)
                parts = title.split(year, 1)
                return ("%s%s %s%s %s%s" % (E2ColoR('yellow'), parts[0].strip(), E2ColoR('cyan'), year, E2ColoR('yellow'), parts[1].strip())).replace('  ', ' ').strip()
            else:
                return "%s%s%s" % (E2ColoR('yellow'), title, E2ColoR('white'))

        list_seasons_part = self.cm.ph.getDataBeetwenMarkers(data, '<div class="seasons-list">', '</div>', False)[1]
        if not list_seasons_part:
            eps_part = self.cm.ph.getDataBeetwenMarkers(data, '<div class="EpsList">', '</div>', False)[1]
            if not eps_part: return
            episodes = self.cm.ph.getAllItemsBeetwenMarkers(eps_part, '<li', '</li>')
            episodes.reverse()
            for item in episodes:
                ep_url = self.cm.ph.getSearchGroups(item, r'href="([^"]+)"')[0]
                ep_title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'title="([^"]+)"')[0])
                if not ep_title: ep_title = self.cleanHtmlStr(item)
                ep_title = "%s> %s" % (E2ColoR('cyan'), colorTitle(ep_title))
                params = dict(cItem)
                params.update({'title': ep_title, 'url': ep_url, 'category': 'explore_items', 'desc': full_desc})
                self.addDir(params)
            return

        seasons = self.cm.ph.getAllItemsBeetwenMarkers(list_seasons_part, '<li', '</li>')
        seasons.reverse()
        for item in seasons:
            season_url = self.cm.ph.getSearchGroups(item, r'href="([^"]+)"')[0]
            season_title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'title="([^"]+)"')[0])
            if not season_title: season_title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'>([^<]+)</a>')[0])
            season_title = "%s* %s" % (E2ColoR('cyan'), colorTitle(season_title))
            params = dict(cItem)
            params.update({'title': season_title, 'url': season_url, 'category': 'explore_items', 'desc': full_desc})
            self.addDir(params)

    def listWatchByType(self, cItem):
        printDBG('EgyDead.listWatchByType')
        url = self.getFullUrl('/type/')
        sts, data = self.getPage(url)
        if not sts or not data: return
        genres_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="genresList">', '</div>', False)[1]
        if not genres_block: return
        items = self.cm.ph.getAllItemsBeetwenMarkers(genres_block, '<li', '</li>')
        for item in items:
            url = self.cm.ph.getSearchGroups(item, r'href="([^"]+)"')[0]
            if not url: continue
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, r'<em>([^<]+)</em>')[0])
            if not title: continue
            params = dict(cItem)
            params.update({'title': title, 'url': self.getFullUrl(url), 'icon': self.DEFAULT_ICON_URL, 'desc': 'Watch by type: %s' % title, 'category': 'list_units'})
            self.addDir(params)

    def getLinksForVideo(self, cItem):
        """
        Interprets video URL. If it's a MegaMax iframe, dynamically resolves
        the available mirror stream URLs (StreamWish, Uqload, Mixdrop, Dood, etc.)
        """
        printDBG('EgyDead.getLinksForVideo [%s]' % cItem)
        url = cItem.get('url', '')
        if not url: return []

        if 'megamax.me' in url:
            mirrors = self._resolveMegaMax(url)
            if mirrors:
                return mirrors

        return [{'name': 'EgyDead - %s' % cItem.get('title', ''), 'url': url, 'need_resolve': 1}]

    def getVideoLinks(self, url):
        """
        Resolves final direct stream URL using E2iPlayer's native urlparser
        with custom fallbacks for Uqload and direct MegaMax.
        """
        printDBG("EgyDead.getVideoLinks [%s]" % url)
        urlTab = []
        if not self.cm.isValidUrl(url):
            return urlTab
            
        if url.startswith('//'):
            url = 'https:' + url

        # Direct MegaMax fallback
        if 'megamax.me' in url:
            mirrors = self._resolveMegaMax(url)
            for m in mirrors:
                try:
                    resolved = self.getVideoLinks(m['url'])
                    if resolved:
                        urlTab.extend(resolved)
                except Exception:
                    pass
            if urlTab:
                return urlTab

        # Try E2iPlayer native urlparser
        try:
            urlTab = self.up.getVideoLinkExt(url)
        except Exception:
            printExc()

        # Custom fallback for Uqload if native resolver returned empty
        if not urlTab and 'uqload' in url:
            urlTab = self._resolveUqload(url)

        return urlTab

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("EgyDead.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        cItem = dict(cItem)
        cItem['url'] = self.SEARCH_URL + urllib_quote_plus(searchPattern)
        self.listSearchUnits(cItem)

    def getArticleContent(self, cItem):
        printDBG("EgyDead.getArticleContent [%s]" % cItem)
        url = cItem.get('url', '')
        if not url: return []
        sts, data = self.getPage(url)
        if not sts or not data: return []
        title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(data, '<div class="singleTitle">', '</div>', False)[1])
        story = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(data, '<div class="singleStory">', '</div>', False)[1])
        extra_story = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(data, '<div class="extra-content">', '</div>', False)[1])
        full_story = story + "\n" + extra_story
        icon = self.cm.ph.getSearchGroups(data, r'<div class="single-thumbnail">.*?<img[^>]+src="([^"]+)"')[0]
        if not icon: icon = cItem.get('icon', '')
        images = [{'title': '', 'url': self.getFullUrl(icon)}] if icon else []
        info_part = self.cm.ph.getDataBeetwenMarkers(data, '<div class="LeftBox">', '</div>', False)[1]
        info_items = re.findall(r'<li>.*?</li>', info_part, re.S)
        otherInfo = {}
        for item in info_items:
            label = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item, '<span>', '</span>', False)[1])
            values = self.cm.ph.getAllItemsBeetwenMarkers(item, '<a', '</a>')
            clean_values = [self.cleanHtmlStr(v) for v in values if self.cleanHtmlStr(v)]
            value = ', '.join(clean_values)
            if u'\u0627\u0644\u0642\u0633\u0645' in label: otherInfo['category'] = value
            elif u'\u0627\u0644\u0646\u0648\u0639' in label: otherInfo['genre'] = value
            elif u'\u0627\u0644\u0644\u063a\u0647' in label: otherInfo['language'] = value
            elif u'\u0627\u0644\u0628\u0644\u062f' in label: otherInfo['country'] = value
            elif u'\u0627\u0644\u0633\u0646\u0647' in label: otherInfo['year'] = value
            elif u'\u0627\u0644\u0642\u0646\u0627\u0647' in label: otherInfo['station'] = value
        views = self.cm.ph.getSearchGroups(data, r'<i class="fa fa-eye"></i><em>([^<]+)</em>')[0]
        date = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(data, '<div class="postDate">', '</div>', False)[1])
        if views: otherInfo['views'] = views
        if date: otherInfo['date'] = date
        return [{
            'title': title if title else self.cleanHtmlStr(cItem.get('title', '')),
            'text': full_story,
            'images': images,
            'other_info': otherInfo
        }]

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('EgyDead.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: >> name[%s], category[%s] " % (name, category))
        self.currList = []
        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'explore_items':
            self.exploreItems(self.currItem)
        elif category == 'movies_categories':
            self.listMoviesCategories(self.currItem)
        elif category == 'series_categories':
            self.listSeriesCategories(self.currItem)
        elif category == 'anime_categories':
            self.listAnimeCategories(self.currItem)
        elif category == 'other_categories':
            self.listOtherCategories(self.currItem)
        elif category == 'list_units':
            self.listUnits(self.currItem)
        elif category == 'list_seasons':
            self.listAssembly(self.currItem)
        elif category == 'list_anime':
            self.listUnits(self.currItem)
        elif category == 'list_other':
            self.listUnits(self.currItem)
        elif category == 'list_series':
            self.listSeries(self.currItem)
        elif category == 'explore_seasons':
            self.exploreSeasons(self.currItem)
        elif category == 'watch_by_type':
            self.listWatchByType(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)

class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, EgyDead(), True, [])

    def withArticleContent(self, cItem):
        if 'video' == cItem.get('type', '') or 'explore_items' == cItem.get('category', ''):
            return True
        return False
