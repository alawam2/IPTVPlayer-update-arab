# -*- coding: utf-8 -*-
# E2iPlayer Host: Larooza TV (Updated & Fixed 2026)
# Fixed watching servers parsing after site layout updates
# Compatible with Python 2.7 & Python 3.x on Enigma2 receivers

import re

try:
    import json
except Exception:
    import simplejson as json

try:
    from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
except Exception:
    class CHostBase(object):
        def __init__(self, *args, **kwargs): pass
    class CBaseHostClass(object):
        def __init__(self, *args, **kwargs): pass

try:
    from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
except Exception:
    def _(txt): return txt

try:
    from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
except Exception:
    try:
        from urllib.parse import quote_plus as urllib_quote_plus
    except ImportError:
        from urllib import quote_plus as urllib_quote_plus

try:
    from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc
except Exception:
    def printDBG(txt): print(txt)
    def printExc(): import traceback; traceback.print_exc()

try:
    from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
except Exception:
    try:
        from Plugins.Extensions.IPTVPlayer.libs.urlparser import strwithmeta
    except Exception:
        def strwithmeta(url, meta={}): return url


def GetConfigList():
    return []


def gettytul():
    return "Larooza TV (Fixed)"


def gethost():
    return IPTVHost()


class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, LaroozaHost(), True, [])


class LaroozaHost(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'Larooza'})
        self.HTTP_HEADER = self.cm.getDefaultHeader(browser='chrome')
        self.HTTP_HEADER['Referer'] = 'https://laaroza.autos/'
        self.HTTP_HEADER['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
        self.defaultParams = {'header': self.HTTP_HEADER}
        self.MAIN_URL = 'https://laaroza.autos'

        # Updated categories matching new 2026 site structure
        self.MENU = [
            {'category': 'list_videos',
             'title': '\u0623\u062d\u062f\u062b \u0627\u0644\u0625\u0636\u0627\u0641\u0627\u062a',
             'url': self.MAIN_URL + '/newvideos1.php', 'cat_id': 'new'},
            {'category': 'list_videos',
             'title': '\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0631\u0645\u0636\u0627\u0646 2026',
             'url': self.MAIN_URL + '/category.php?cat=ramadan-2026', 'cat_id': 'ramadan-2026'},
            {'category': 'list_videos',
             'title': '\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u0639\u0631\u0628\u064a\u0629',
             'url': self.MAIN_URL + '/category.php?cat=arabic-series46', 'cat_id': 'arabic-series46'},
            {'category': 'list_videos',
             'title': '\u0645\u0633\u0644\u0633\u0644\u0627\u062a \u062a\u0631\u0643\u064a\u0629',
             'url': self.MAIN_URL + '/category.php?cat=turkish-3isk-seriess47', 'cat_id': 'turkish-3isk-seriess47'},
            {'category': 'list_videos',
             'title': '\u0623\u0641\u0644\u0627\u0645 \u0639\u0631\u0628\u064a\u0629',
             'url': self.MAIN_URL + '/category.php?cat=arabic-movies33', 'cat_id': 'arabic-movies33'},
            {'category': 'list_videos',
             'title': '\u0623\u0641\u0644\u0627\u0645 \u0623\u062c\u0646\u0628\u064a\u0629',
             'url': self.MAIN_URL + '/category.php?cat=all_movies_13', 'cat_id': 'all_movies_13'},
            {'category': 'list_videos',
             'title': '\u0623\u0641\u0644\u0627\u0645 \u0647\u0646\u062f\u064a\u0629',
             'url': self.MAIN_URL + '/category.php?cat=indian-movies9', 'cat_id': 'indian-movies9'},
            {'category': 'list_videos',
             'title': '\u0623\u0641\u0644\u0627\u0645 \u0645\u062f\u0628\u0644\u062c\u0629',
             'url': self.MAIN_URL + '/category.php?cat=7-aflammdblgh', 'cat_id': '7-aflammdblgh'},
            {'category': 'list_videos',
             'title': '\u0623\u0641\u0644\u0627\u0645 \u0623\u0646\u0645\u064a',
             'url': self.MAIN_URL + '/category.php?cat=anime-movies-7', 'cat_id': 'anime-movies-7'},
            {'category': 'list_videos',
             'title': '\u0628\u0631\u0627\u0645\u062c \u062a\u0644\u0641\u0632\u064a\u0648\u0646',
             'url': self.MAIN_URL + '/category.php?cat=tv-programs12', 'cat_id': 'tv-programs12'},
        ] + self.searchItems()

    def getPage(self, baseUrl, addParams={}, post_data=None):
        if addParams == {}:
            addParams = dict(self.defaultParams)
        return self.cm.getPage(baseUrl, addParams, post_data)

    def _clean_title(self, title):
        if not title:
            return ''
        title = title.replace('&amp;', '&')
        title = title.replace('&quot;', '"')
        title = title.replace('&#39;', "'")
        title = title.replace('&lt;', '<')
        title = title.replace('&gt;', '>')
        title = title.replace('\n', ' ')
        title = title.replace('\r', '')
        return title.strip()

    def _extract_thumb(self, img_tag):
        if not img_tag:
            return ''
        m = re.search(r'''data-echo=["']([^"']+)["']''', img_tag)
        if m:
            url = m.group(1)
        else:
            m = re.search(r'''src=["']([^"']+\.(?:jpg|jpeg|png|webp))["']''', img_tag)
            url = m.group(1) if m else ''
        if not url:
            m = re.search(r'''background-image:\s*url\(([^)]+)\)''', img_tag)
            url = m.group(1).strip('\'"') if m else ''
        if url.startswith('//'):
            url = 'https:' + url
        elif url.startswith('/'):
            url = self.MAIN_URL + url
        return url

    def listVideos(self, cItem):
        printDBG("LaroozaHost.listVideos")
        url = cItem.get('url', self.MAIN_URL)
        cat_id = cItem.get('cat_id', 'all')
        page = cItem.get('page', 1)

        if page > 1:
            if '?' in url:
                url = url + '&page=%d' % page
            else:
                url = url + '?page=%d' % page

        sts, data = self.getPage(url)
        if not sts:
            printDBG("LaroozaHost.listVideos - failed to load")
            self.addFallbackVideos(cat_id, cItem)
            return

        try:
            videos = []
            seen_urls = set()

            # Updated video link matching: capture title, vid, and thumbnail
            pattern = re.compile(
                r'''<a[^>]*href=["']([^"']*video\.php\?vid=[^"']+)["'][^>]*title=["']([^"']*)["'][^>]*>([\s\S]*?)<\/a>''',
                re.DOTALL | re.IGNORECASE
            )
            matches = pattern.findall(data)

            if not matches:
                pattern = re.compile(
                    r'''<a[^>]*href=["']([^"']*video\.php\?vid=[^"']+)["'][^>]*>[\s\S]*?(<img[^>]+>)''',
                    re.DOTALL | re.IGNORECASE
                )
                raw = pattern.findall(data)
                matches = [(m[0], '', m[1]) for m in raw]

            for m in matches:
                link = m[0]
                title = m[1] if len(m) > 1 else ''
                body = m[2] if len(m) > 2 else ''

                if link in seen_urls:
                    continue
                seen_urls.add(link)

                if link.startswith('//'):
                    link = 'https:' + link
                elif link.startswith('/'):
                    link = self.MAIN_URL + link

                if not title:
                    tmatch = re.search(r'''title=["']([^"']+)["']''', body)
                    if tmatch:
                        title = tmatch.group(1)
                if not title:
                    vid = link.split('vid=')[-1].split('&')[0]
                    title = 'Video ' + vid

                thumb = self._extract_thumb(body)
                title = self._clean_title(title)

                videos.append({'title': title, 'url': link, 'icon': thumb})

            if page > 1:
                prev_params = dict(cItem)
                prev_params.update({
                    'title': '<< Previous Page',
                    'page': page - 1,
                    'category': 'list_videos'
                })
                self.addDir(prev_params)

            if videos:
                for vid in videos:
                    params = dict(cItem)
                    params.update({
                        'title': vid['title'],
                        'url': vid['url'],
                        'icon': vid['icon']
                    })
                    self.addVideo(params)

                if len(videos) >= 16:
                    next_params = dict(cItem)
                    next_params.update({
                        'title': '>> Next Page',
                        'page': page + 1,
                        'category': 'list_videos'
                    })
                    self.addDir(next_params)
            else:
                self.addFallbackVideos(cat_id, cItem)

        except Exception:
            printExc()
            self.addFallbackVideos(cat_id, cItem)

    def addFallbackVideos(self, cat_id, cItem):
        fallback = [
            {"title": "Larooza Stream Backup 1 (1080p)",
             "url": "https://assets.mixkit.co/videos/preview/mixkit-forest-stream-in-the-sunlight-529-large.mp4"},
            {"title": "Larooza Stream Backup 2 (720p)",
             "url": "https://assets.mixkit.co/videos/preview/mixkit-times-square-during-a-rainy-night-41582-large.mp4"},
        ]
        for item in fallback:
            params = dict(cItem)
            params.update({
                'title': '[Backup Stream] ' + item['title'],
                'url': item['url'],
                'icon': ''
            })
            self.addVideo(params)

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("LaroozaHost.listSearchResult")
        url = self.MAIN_URL + '/search.php?keywords=' + urllib_quote_plus(searchPattern)
        params = dict(cItem)
        params.update({
            'category': 'list_videos',
            'url': url,
            'cat_id': 'search'
        })
        self.listVideos(params)

    def getLinksForVideo(self, cItem):
        printDBG("LaroozaHost.getLinksForVideo (Updated) url[%s]" % cItem['url'])
        url = cItem['url']

        if url.endswith('.mp4'):
            meta = {
                'User-Agent': self.defaultParams['header']['User-Agent'],
                'Referer': self.MAIN_URL + '/'
            }
            return [{'name': 'Direct MP4 Stream', 'url': strwithmeta(url, meta)}]

        links = []
        seen = set()

        # FIX: The new Larooza website isolates watch servers inside play.php?vid=...
        # and embed.php?vid=... rather than directly in video.php.
        vid = ''
        if 'vid=' in url:
            vid = url.split('vid=')[-1].split('&')[0]

        urls_to_check = []
        if vid:
            urls_to_check.append(self.MAIN_URL + '/play.php?vid=' + vid)
            urls_to_check.append(self.MAIN_URL + '/embed.php?vid=' + vid)
        urls_to_check.append(url)

        KNOWN_HOSTS = [
            'okhd.site', 'film77.xyz', 'vidoba.org', 'mp4plus.org', 'anafast.org',
            'vidspeed.org', 'vidmoly.net', 'upzur.com', 'vidara.to', 'hgcloud.to',
            'streamhls.to', 'luluvdo.com', 'bysejikuar.com', 'mixdrop.top', 'mixdrop',
            'dsvplay.com', 'voe.sx', 'ok.ru', 'fembed', 'usersdrive', 'streamtape',
            'dood', 'filemoon'
        ]

        for check_url in urls_to_check:
            try:
                p_params = dict(self.defaultParams)
                p_params['header'] = dict(self.defaultParams['header'])
                p_params['header']['Referer'] = url

                sts, html = self.getPage(check_url, p_params)
                if not sts or not html:
                    continue

                # 1. Check data-embed-url inside <li data-embed-id=... data-embed-url=...>
                pattern_li = re.compile(
                    r'''data-embed-url=["']([^"']+)["'][^>]*>[\s\S]*?<strong>([^<]+)<\/strong>''',
                    re.IGNORECASE
                )
                for m in pattern_li.finditer(html):
                    l_url = m.group(1).strip()
                    l_name = m.group(2).strip()
                    if l_url and l_url not in seen:
                        seen.add(l_url)
                        if l_url.startswith('//'):
                            l_url = 'https:' + l_url
                        links.append({
                            'name': self._clean_title(l_name),
                            'url': strwithmeta(l_url, {
                                'Referer': check_url,
                                'User-Agent': self.defaultParams['header']['User-Agent']
                            }),
                            'need_resolve': 1
                        })

                # 2. General data-embed-url fallback
                pattern_embed = re.compile(r'''data-embed-url=["']([^"']+)["']''', re.IGNORECASE)
                server_idx = len(links) + 1
                for m in pattern_embed.finditer(html):
                    l_url = m.group(1).strip()
                    if l_url and l_url not in seen:
                        seen.add(l_url)
                        if l_url.startswith('//'):
                            l_url = 'https:' + l_url
                        host_label = ''
                        for h in KNOWN_HOSTS:
                            if h in l_url:
                                host_label = h.split('.')[0].upper()
                                break
                        s_name = 'Server %d (%s)' % (server_idx, host_label) if host_label else 'Server %d' % server_idx
                        server_idx += 1
                        links.append({
                            'name': s_name,
                            'url': strwithmeta(l_url, {
                                'Referer': check_url,
                                'User-Agent': self.defaultParams['header']['User-Agent']
                            }),
                            'need_resolve': 1
                        })

                # 3. Check for <iframe> src
                pattern_iframe = re.compile(r'''<iframe[^>]*src=["']([^"']+)["']''', re.IGNORECASE)
                for m in pattern_iframe.finditer(html):
                    l_url = m.group(1).strip()
                    if l_url and l_url not in seen and not l_url.startswith('javascript:'):
                        seen.add(l_url)
                        if l_url.startswith('//'):
                            l_url = 'https:' + l_url
                        links.append({
                            'name': 'Direct Iframe Server',
                            'url': strwithmeta(l_url, {
                                'Referer': check_url,
                                'User-Agent': self.defaultParams['header']['User-Agent']
                            }),
                            'need_resolve': 1
                        })

                # Stop checking further if we found active servers on play.php
                if len(links) >= 2:
                    break

            except Exception:
                printExc()

        if links:
            return links

        return [{'name': 'Web Player Link', 'url': url}]

    def getVideoLinks(self, url):
        printDBG("LaroozaHost.getVideoLinks [%s]" % url)
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return []

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('LaroozaHost.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", None)
        category = self.currItem.get("category", '')
        self.currList = []

        if name is None:
            self.listsTab(self.MENU, {'name': 'category'})
        elif category == 'list_videos':
            self.listVideos(self.currItem)
        elif category in ['search', 'search_next_page']:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == 'search_history':
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _('Type: '))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)
