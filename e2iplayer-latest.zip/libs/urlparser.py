# -*- coding: utf-8 -*-
from ast import literal_eval
import base64
from binascii import hexlify, unhexlify
import codecs
from hashlib import sha256
from random import choice as random_choice, randint, uniform
import re
import string
import struct
import time
from os import urandom
from Components.config import config
from Screens.MessageBox import MessageBox
from Plugins.Extensions.IPTVPlayer.components.asynccall import MainSessionWrapper
from Plugins.Extensions.IPTVPlayer.components.captcha_helper import CaptchaHelper
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import GetIPTVSleep, SetIPTVPlayerLastHostError, TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdh import DMHelper
from Plugins.Extensions.IPTVPlayer.libs import ph, pyaes
from Plugins.Extensions.IPTVPlayer.libs.aesgcm import python_aesgcm
from Plugins.Extensions.IPTVPlayer.libs.crypto.cipher.aes_cbc import AES_CBC
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs.ecdsa import NIST256p as ECDSA_NIST256p, SigningKey as ECDSA_SigningKey
from Plugins.Extensions.IPTVPlayer.libs.jsunpack import get_packed_data
from Plugins.Extensions.IPTVPlayer.libs.pCommon import common
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2 import UnCaptchaReCaptcha
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import captchaParser, decorateUrl, getDirectM3U8Playlist, getMPDLinksWithMeta, TEAMCASTPL_decryptPlayerParams, unicode_escape, unpackJSPlayerParams, VIDUPME_decryptPlayerParams
from Plugins.Extensions.IPTVPlayer.libs.youtube_dl.utils import clean_html
from Plugins.Extensions.IPTVPlayer.p2p3.manipulateStrings import ensure_binary, ensure_str
from Plugins.Extensions.IPTVPlayer.p2p3.pVer import isPY2
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_unquote, urllib_urlencode
from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import parse_qs, urljoin, urlparse
from Plugins.Extensions.IPTVPlayer.tools.e2ijs import js_execute, js_execute_ext
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import CSelOneLink, GetCookieDir, GetDefaultLang, GetJSScriptFile, GetPluginDir, printDBG, printExc, rm
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta

if not isPY2():
    basestring = str
    xrange = range


def b64urlencode(b, strip=False):
    if not isinstance(b, bytes if "bytes" in locals() or bytes is not str else (str, bytes)):
        b = b.encode("utf-8") if hasattr(b, "encode") else bytes(b)
    r = base64.urlsafe_b64encode(b)
    if not isinstance(r, str):
        r = r.decode("utf-8")
    if strip:
        r = r.rstrip("=")
    return r


def generate_vrf(movie_id, user_id):
    key = sha256(user_id.encode("utf-8")).digest()
    aes = pyaes.AESModeOfOperationCBC(key, iv=b"\x00" * 16)
    p_len = 16 - len(movie_id) % 16
    plaintext = movie_id + chr(p_len) * p_len
    ciphertext = aes.encrypt(plaintext)
    encoded = base64.b64encode(ciphertext).decode()
    url_safe = encoded.replace("+", "-").replace("/", "_").replace("=", "")
    return url_safe


def crsdiv(a, dec_id):
    def b64dec(t):
        return base64.b64decode(t).decode("latin1")

    def dec(a, shift):
        b64 = a[::-1].replace("-", "+").replace("_", "/")
        return "".join([chr(ord(ch) - shift) for ch in b64dec(b64)])

    if dec_id == "sXnL9MQIry":
        b = [ord(ch) for ch in "pWB9V)[*4I`nJpp?ozyB~dbr9yt!_n4u"]
        d = [int(x, 16) for x in re.findall(r".{2}", a)]
        decrypted = [(v ^ b[i % len(b)]) - 3 for i, v in enumerate(d)]
        return b64dec("".join(chr(v) for v in decrypted))
    if dec_id == "IhWrImMIGL":
        d = []
        for ch in a:
            if "a" <= ch <= "m" or "A" <= ch <= "M":
                d.append(chr(ord(ch) + 13))
            elif "n" <= ch <= "z" or "N" <= ch <= "Z":
                d.append(chr(ord(ch) - 13))
            else:
                d.append(ch)
        return b64dec("".join(d))
    if dec_id == "xTyBxQyGTA":
        b = a[::-1]
        c = "".join([b[i] for i in range(0, len(b), 2)])
        return b64dec(c)
    if dec_id == "ux8qjPHC66":
        rev = a[::-1]
        data = "".join([chr(int(rev[i: i + 2], 16)) for i in range(0, len(rev), 2)])
        key = "X9a(O;FMV2-7VO5x;Ao\x05:dN1NoFs?j,"
        res = []
        for i, ch in enumerate(data):
            res.append(chr(ord(ch) ^ ord(key[i % len(key)])))
        return "".join(res)
    if dec_id == "eSfH1IRMyL":
        rev = [ord(ch) - 1 for ch in reversed(a)]
        chunks = []
        i = 0
        while i < len(rev):
            val = int("".join([chr(rev[i]), chr(rev[i + 1])]), 16)
            chunks.append(val)
            i += 2
        return "".join(chr(v) for v in chunks)
    if dec_id == "KJHidj7det":
        c = [ord(ch) for ch in '3SAY~#%Y(V%>5d/Yg"$G[Lh1rK4a;7ok']
        decrypted = [v ^ c[i % len(c)] for i, v in enumerate([ord(ch) for ch in b64dec(a[10:-16])])]
        return "".join(chr(v) for v in decrypted)
    if dec_id == "o2VSUnjnZl":
        mapping = {"x": "a", "y": "b", "z": "c", "a": "d", "b": "e", "c": "f", "d": "g", "e": "h", "f": "i", "g": "j", "h": "k", "i": "l", "j": "m", "k": "n", "l": "o", "m": "p", "n": "q", "o": "r", "p": "s", "q": "t", "r": "u", "s": "v", "t": "w", "u": "x", "v": "y", "w": "z", "X": "A", "Y": "B", "Z": "C", "A": "D", "B": "E", "C": "F", "D": "G", "E": "H", "F": "I", "G": "J", "H": "K", "I": "L", "J": "M", "K": "N", "L": "O", "M": "P", "N": "Q", "O": "R", "P": "S", "Q": "T", "R": "U", "S": "V", "T": "W", "U": "X", "V": "Y", "W": "Z"}
        return "".join(mapping.get(ch, ch) for ch in a)
    if dec_id in ("JoAHUMCLXV", "Oi3v1dAlaM", "TsA2KGDGux"):
        shifts = {"JoAHUMCLXV": 3, "Oi3v1dAlaM": 5, "TsA2KGDGux": 7}
        return dec(a, shifts[dec_id])
    return ""


def rc4(cipher_text, key):
    def compat_ord(c):
        return ord(c) if isinstance(c, str) else c

    res = ensure_binary("")
    cipher_text = base64.b64decode(cipher_text)
    key_len = len(key)
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + ord(key[i % key_len])) % 256
        S[i], S[j] = S[j], S[i]
    i = 0
    j = 0
    for m in range(len(cipher_text)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        k = S[(S[i] + S[j]) % 256]
        res += struct.pack("B", k ^ compat_ord(cipher_text[m]))
    return ensure_str(res)


def random_seed(length=10, data=""):
    return data + "".join(random_choice(string.ascii_letters + string.digits) for x in range(length))


def girc(data, url, co=None):
    cm = common()
    hdrs = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0", "Referer": url}
    rurl = "https://www.google.com/recaptcha/api.js"
    aurl = "https://www.google.com/recaptcha/api2"
    key = re.search(r'(?:src="{0}\?.*?render|data-sitekey)="?([^"]+)'.format(rurl), data)
    if key:
        if co is None:
            co = base64.b64encode((url[:-1] + ":443").encode()).replace(b"=", b"")
        key = key.group(1)
        rurl = "{0}?render={1}".format(rurl, key)
        sts, data = cm.getPage(rurl, hdrs)
        if not sts:
            return ""
        v = re.findall("releases/([^/]+)", data)
        v = v[0]
        rdata = {"ar": 1, "k": key, "co": co, "hl": "en", "v": v, "size": "invisible", "cb": "123456789"}
        sts, data = cm.getPage("{0}/anchor?{1}".format(aurl, urllib_urlencode(rdata)), hdrs)
        if not sts:
            return ""
        rtoken = re.search('recaptcha-token.+?="([^"]+)', data)
        pdata = {"v": v, "reason": "q", "k": key, "c": rtoken.group(1), "sa": "", "co": co}
        hdrs.update({"Referer": aurl})
        sts, data = cm.getPage("{0}/reload?k={1}".format(aurl, key), hdrs, pdata)
        if not sts:
            return ""
        gtoken = re.search('rresp","([^"]+)', data)
        if gtoken:
            return gtoken.group(1)
    return ""


def InternalCipher(data, encrypt=True):
    tmp = sha256("|".join(GetPluginDir().split("/")[-2:])).digest()
    key = tmp[:16]
    iv = tmp[16:]
    cipher = AES_CBC(key=key, keySize=16)
    if encrypt:
        return cipher.encrypt(data, iv)
    return cipher.decrypt(data, iv)


class urlparser:
    def __init__(self):
        self.cm = common()
        self.pp = pageParser()
        self.hostMap = {
            "1azayf9w.xyz": self.pp.parserBYSE,
            "1fichier.com": self.pp.parser1FICHIERCOM,
            "222i8x.lol": self.pp.parserBYSE,
            "26efp.com": self.pp.parserJWPLAYER,
            "4yftwvrdz7.sbs": self.pp.parserJWPLAYER,
            "81u6xl9d.xyz": self.pp.parserBYSE,
            "8mhlloqo.fun": self.pp.parserBYSE,
            "96ar.com": self.pp.parserBYSE,
            # a
            "adblocktape.wiki": self.pp.parserSTREAMTAPE,
            "aiavh.com": self.pp.parserJWPLAYER,
            "aliez.me": self.pp.parserJWPLAYER,
            "all3do.com": self.pp.parserDOOD,
            "anime4low.sbs": self.pp.parserJWPLAYER,
            "anonmp4.help": self.pp.parserANONMP4,
            "antiadtape.com": self.pp.parserSTREAMTAPE,
            "arabveturk.com": self.pp.parserJWPLAYER,
            "archive.org": self.pp.parserARCHIVEORG,
            "ashortl.ink": self.pp.parserVIDMOLYME,
            "asnwish.com": self.pp.parserJWPLAYER,
            "awish.pro": self.pp.parserJWPLAYER,
            # b
            "bbc.co.uk": self.pp.parserBBC,
            "bestwish.lol": self.pp.parserJWPLAYER,
            "bf0skv.org": self.pp.parserBYSE,
            "bgwp.cc": self.pp.parserJWPLAYER,
            "bigshare.io": self.pp.parserJWPLAYER,
            "bigwarp.art": self.pp.parserJWPLAYER,
            "bigwarp.cc": self.pp.parserJWPLAYER,
            "bigwarp.io": self.pp.parserJWPLAYER,
            "bigwarp.pro": self.pp.parserJWPLAYER,
            "bigwings.io": self.pp.parserJWPLAYER,
            "bingezove.com": self.pp.parserJWPLAYER,
            "boosteradx.online": self.pp.parserBYSE,
            "byse.sx": self.pp.parserBYSE,
            "bysebuho.com": self.pp.parserBYSE,
            "bysedikamoum.com": self.pp.parserBYSE,
            "bysefujedu.com": self.pp.parserBYSE,
            "bysejikuar.com": self.pp.parserBYSE,
            "bysekoze.com": self.pp.parserBYSE,
            "byselapuix.com": self.pp.parserBYSE,
            "byseqekaho.com": self.pp.parserBYSE,
            "bysesayeveum.com": self.pp.parserBYSE,
            "bysesukior.com": self.pp.parserBYSE,
            "bysetayico.com": self.pp.parserBYSE,
            "bysevepoin.com": self.pp.parserBYSE,
            "bysewihe.com": self.pp.parserBYSE,
            "bysezejataos.com": self.pp.parserBYSE,
            "bysezoxexe.com": self.pp.parserBYSE,
            # c
            "c1z39.com": self.pp.parserBYSE,
            "cavanhabg.com": self.pp.parserJWPLAYER,
            "cda.pl": self.pp.parserCDA,
            "cdn1.site": self.pp.parserJWPLAYER,
            "cdnwish.com": self.pp.parserJWPLAYER,
            "chuckle-tube.com": self.pp.parserVOESX,
            "cinegrab.com": self.pp.parserBYSE,
            "cloud.mail.ru": self.pp.parserCOUDMAILRU,
            "coflix.upn.one": self.pp.parserSBS,
            "coverapi.store": self.pp.parserCOVERAPI,
            "csst.online": self.pp.parserSST,
            "cybervynx.com": self.pp.parserJWPLAYER,
            # d
            "d0000d.com": self.pp.parserDOOD,
            "d000d.com": self.pp.parserDOOD,
            "d0o0d.com": self.pp.parserDOOD,
            "d-s.io": self.pp.parserDOOD,
            "dailymotion.com": self.pp.parserDAILYMOTION,
            "darkibox.com": self.pp.parserJWPLAYER,
            "dancima.shop": self.pp.parserJWPLAYER,
            "davioad.com": self.pp.parserJWPLAYER,
            "dhcplay.com": self.pp.parserJWPLAYER,
            "dhtpre.com": self.pp.parserJWPLAYER,
            "dingtezuni.com": self.pp.parserJWPLAYER,
            "dintezuvio.com": self.pp.parserJWPLAYER,
            "do0od.com": self.pp.parserDOOD,
            "do7go.com": self.pp.parserDOOD,
            "dood.cx": self.pp.parserDOOD,
            "dood.la": self.pp.parserDOOD,
            "dood.li": self.pp.parserDOOD,
            "dood.pm": self.pp.parserDOOD,
            "dood.re": self.pp.parserDOOD,
            "dood.sh": self.pp.parserDOOD,
            "dood.so": self.pp.parserDOOD,
            "dood.stream": self.pp.parserDOOD,
            "dood.to": self.pp.parserDOOD,
            "dood.watch": self.pp.parserDOOD,
            "dood.wf": self.pp.parserDOOD,
            "dood.work": self.pp.parserDOOD,
            "dood.ws": self.pp.parserDOOD,
            "dood.yt": self.pp.parserDOOD,
            "doods.pro": self.pp.parserDOOD,
            "doods.to": self.pp.parserVEEV,
            "doodcdn.io": self.pp.parserDOOD,
            "doodstream.co": self.pp.parserDOOD,
            "doodstream.com": self.pp.parserDOOD,
            "dooodster.com": self.pp.parserDOOD,
            "dooood.com": self.pp.parserDOOD,
            "doply.net": self.pp.parserDOOD,
            "dpstream.fyi": self.pp.parserJWPLAYER,
            "dr0pstream.com": self.pp.parserJWPLAYER,
            "drakkar.st": self.pp.parserDRAKKAR,
            "dropload.co": self.pp.parserJWPLAYER,
            "dropload.io": self.pp.parserJWPLAYER,
            "dropload.pro": self.pp.parserJWPLAYER,
            "dropload.tv": self.pp.parserJWPLAYER,
            "ds2play.com": self.pp.parserDOOD,
            "ds2video.com": self.pp.parserDOOD,
            "dsvplay.com": self.pp.parserDOOD,
            "dumbalag.com": self.pp.parserJWPLAYER,
            # e
            "eb8gfmjn71.sbs": self.pp.parserJWPLAYER,
            "ebd.cda.pl": self.pp.parserCDA,
            "edbrdl7pab.sbs": self.pp.parserJWPLAYER,
            "egtpgrvh.sbs": self.pp.parserJWPLAYER,
            "embedplaybyse.top": self.pp.parserBYSE,
            "embedwish.com": self.pp.parserJWPLAYER,
            "emturbovid.com": self.pp.parserJWPLAYER,
            "en.embedz.net": self.pp.parserJWPLAYER,
            # f
            "f16px.com": self.pp.parserBYSE,
            "f51rm.com": self.pp.parserBYSE,
            "fastream.to": self.pp.parserJWPLAYER,
            "fdewsdc.sbs": self.pp.parserJWPLAYER,
            "filecloud.io": self.pp.parserFILECLOUDIO,
            "filefactory.com": self.pp.parserFILEFACTORYCOM,
            "filelions.live": self.pp.parserJWPLAYER,
            "filelions.online": self.pp.parserJWPLAYER,
            "filelions.site": self.pp.parserJWPLAYER,
            "filelions.to": self.pp.parserJWPLAYER,
            "filemoon.art": self.pp.parserBYSE,
            "filemoon.eu": self.pp.parserBYSE,
            "filemoon.in": self.pp.parserBYSE,
            "filemoon.link": self.pp.parserBYSE,
            "filemoon.nl": self.pp.parserBYSE,
            "filemoon.sx": self.pp.parserBYSE,
            "filemoon.to": self.pp.parserBYSE,
            "filemoon.wf": self.pp.parserBYSE,
            "fileone.tv": self.pp.parserFILEONETV,
            "file-upload.org": self.pp.parserJWPLAYER,
            "filma365.strp2p.site": self.pp.parserSBS,
            "firestream.to": self.pp.parserFIRESTREAM,
            "flaswish.com": self.pp.parserJWPLAYER,
            "flyfile.app": self.pp.parserFLYFILE,
            "forafile.com": self.pp.parserJWPLAYER,
            "freedisc.pl": self.pp.parserFREEDISC,
            "fsdcmo.sbs": self.pp.parserJWPLAYER,
            "fsst.online": self.pp.parserSST,
            "furher.in": self.pp.parserBYSE,
            # g
            "ghbrisk.com": self.pp.parserJWPLAYER,
            "goodstream.one": self.pp.parserJWPLAYER,
            "goodstream.uno": self.pp.parserJWPLAYER,
            "goofy-banana.com": self.pp.parserVOESX,
            "google.com": self.pp.parserGOOGLE,
            "govid.site": self.pp.parserJWPLAYER,
            "gscdn.cam": self.pp.parserJWPLAYER,
            "gsfqzmqu.sbs": self.pp.parserJWPLAYER,
            "gupload.xyz": self.pp.parserGUPLOAD,
            # h
            "haxloppd.com": self.pp.parserJWPLAYER,
            "hd1.hdup20.com": self.pp.parserJWPLAYER,
            "hdbestvd.online": self.pp.parserJWPLAYER,
            "hexload.com": self.pp.parserHEXLOAD,
            "hexupload.net": self.pp.parserHEXLOAD,
            "hglink.to": self.pp.parserJWPLAYER,
            "hgplaycdn.com": self.pp.parserJWPLAYER,
            "hlsflast.com": self.pp.parserJWPLAYER,
            "hlsplayer.org": self.pp.parserJWPLAYER,
            "hlswish.com": self.pp.parserJWPLAYER,
            # i
            "iplayerhls.com": self.pp.parserJWPLAYER,
            # j
            "javsw.me": self.pp.parserJWPLAYER,
            "jodwish.com": self.pp.parserJWPLAYER,
            "justupload.io": self.pp.parserJWPLAYER,
            # k
            "kerapoxy.cc": self.pp.parserBYSE,
            "kinoger.be": self.pp.parserJWPLAYER,
            "kinoger.embed4me.vip": self.pp.parserSBS,
            "kinoger.seekplays.pro": self.pp.parserSBS,
            "kinoger.p2pplay.pro": self.pp.parserSBS,
            "kinoger.pw": self.pp.parserSTREAMUP,
            "kinoger.re": self.pp.parserSBS,
            "kinoger.ru": self.pp.parserVOESX,
            "kravaxxa.com": self.pp.parserJWPLAYER,
            # l
            "l1afav.net": self.pp.parserBYSE,
            "lulu.st": self.pp.parserJWPLAYER,
            "lulustream.com": self.pp.parserJWPLAYER,
            "luluvid.com": self.pp.parserJWPLAYER,
            "luluvdo.com": self.pp.parserJWPLAYER,
            "luluvdoo.com": self.pp.parserJWPLAYER,
            # m
            "m1xdrop.click": self.pp.parserJWPLAYER,
            "m1xdrop.com": self.pp.parserJWPLAYER,
            "m1xdrop.net": self.pp.parserJWPLAYER,
            "md3b0j6hj.com": self.pp.parserJWPLAYER,
            "mdbekjwqa.pw": self.pp.parserJWPLAYER,
            "mdfx9dc8n.net": self.pp.parserJWPLAYER,
            "mdy48tn97.com": self.pp.parserJWPLAYER,
            "mdzsmutpcvykb.net": self.pp.parserJWPLAYER,
            "mediafire.com": self.pp.parserMEDIAFIRECOM,
            "mediasetplay.mediaset.it": self.pp.parserMEDIASET,
            "minochinos.com": self.pp.parserJWPLAYER,
            "mivalyo.com": self.pp.parserJWPLAYER,
            "mixdrp.click": self.pp.parserJWPLAYER,
            "mixdrp.co": self.pp.parserJWPLAYER,
            "mixdrp.to": self.pp.parserJWPLAYER,
            "mixdroop.co": self.pp.parserJWPLAYER,
            "mixdrop21.net": self.pp.parserJWPLAYER,
            "mixdrop23.net": self.pp.parserJWPLAYER,
            "mixdrop.ag": self.pp.parserJWPLAYER,
            "mixdrop.bz": self.pp.parserJWPLAYER,
            "mixdrop.ch": self.pp.parserJWPLAYER,
            "mixdrop.club": self.pp.parserJWPLAYER,
            "mixdrop.co": self.pp.parserJWPLAYER,
            "mixdrop.my": self.pp.parserJWPLAYER,
            "mixdrop.nu": self.pp.parserJWPLAYER,
            "mixdrop.ps": self.pp.parserJWPLAYER,
            "mixdrop.sb": self.pp.parserJWPLAYER,
            "mixdrop.si": self.pp.parserJWPLAYER,
            "mixdrop.sn": self.pp.parserJWPLAYER,
            "mixdrop.sx": self.pp.parserJWPLAYER,
            "mixdrop.to": self.pp.parserJWPLAYER,
            "mixdrop.top": self.pp.parserJWPLAYER,
            "mixdropjmk.pw": self.pp.parserJWPLAYER,
            "vidoba.org": self.pp.parserJWPLAYER,
            "mp4plus.org": self.pp.parserJWPLAYER,
            "anafast.org": self.pp.parserJWPLAYER,
            "vidspeed.org": self.pp.parserJWPLAYER,
            "abstream.to": self.pp.parserJWPLAYER,
            "miiiixdrop.net": self.pp.parserJWPLAYER,
            "moflix-stream.click": self.pp.parserJWPLAYER,
            "moflix-stream.fans": self.pp.parserJWPLAYER,
            "moflix-stream.link": self.pp.parserBYSE,
            "moflix.rpmplay.xyz": self.pp.parserSBS,
            "moflix.upns.xyz": self.pp.parserSBS,
            "moonmov.pro": self.pp.parserBYSE,
            "movearnpre.com": self.pp.parserJWPLAYER,
            "moviesapi.club": self.pp.parserVIDSRC,
            "moviesapi.to": self.pp.parserVIDSRC,
            "mp4player.site": self.pp.parserSTREAMEMBED,
            "mp4upload.com": self.pp.parserJWPLAYER,
            "mxdrop.sx": self.pp.parserJWPLAYER,
            "mxdrop.to": self.pp.parserJWPLAYER,
            "mysportzfy.com": self.pp.parserJWPLAYER,
            "myvidplay.com": self.pp.parserDOOD,
            # n
            "nova.upn.one": self.pp.parserSBS,
            # o
            "obeywish.com": self.pp.parserJWPLAYER,
            "odnoklassniki.ru": self.pp.parserOKRU,
            "odysee.com": self.pp.parserJWPLAYER,
            "odysseusa.cc": self.pp.parserSTREAMUP,
            "ok.ru": self.pp.parserOKRU,
            # p
            "peachify.top": self.pp.parserPEACHIFY,
            "peytonepre.com": self.pp.parserJWPLAYER,
            "player.upn.one": self.pp.parserSBS,
            "playerwish.com": self.pp.parserJWPLAYER,
            "playmate.to": self.pp.parserPLAYMATE,
            "playmogo.com": self.pp.parserDOOD,
            "polsatsport.pl": self.pp.parserJWPLAYER,
            "poophq.com": self.pp.parserVEEV,
            "pqham.com": self.pp.parserJWPLAYER,
            # r
            "rapid-cloud.co": self.pp.parserVIDCLOUD,
            "rubystm.com": self.pp.parserJWPLAYER,
            "rubyvidhub.com": self.pp.parserJWPLAYER,
            "rty1.film77.xyz": self.pp.parserJWPLAYER,
            "ryderjet.com": self.pp.parserJWPLAYER,
            # s
            "s3taku.pro": self.pp.parserJWPLAYER,
            "savefiles.com": self.pp.parserJWPLAYER,
            "sb1254w9megshle.org": self.pp.parserBYSE,
            "scloud.online": self.pp.parserSTREAMTAPE,
            "sendvid.com": self.pp.parserJWPLAYER,
            "sfastwish.com": self.pp.parserJWPLAYER,
            "sharevideo.pl": self.pp.parserSHAREVIDEO,
            "shavetape.cash": self.pp.parserSTREAMTAPE,
            "shiid4u.upn.one": self.pp.parserSBS,
            "smdfs40r.skin": self.pp.parserBYSE,
            "smoothpre.com": self.pp.parserJWPLAYER,
            "soundcloud.com": self.pp.parserSOUNDCLOUDCOM,
            "sportsonline.si": self.pp.parserJWPLAYER,
            "sportsonline.to": self.pp.parserJWPLAYER,
            "ss.hd-vk.com": self.pp.parserJWPLAYER,
            "stape.fun": self.pp.parserSTREAMTAPE,
            "stmix.io": self.pp.parserSTREAMUP,
            "strcloud.club": self.pp.parserSTREAMTAPE,
            "strcloud.link": self.pp.parserSTREAMTAPE,
            "streamadblocker.xyz": self.pp.parserSTREAMTAPE,
            "streamadblockplus.com": self.pp.parserSTREAMTAPE,
            "streamhihi.com": self.pp.parserJWPLAYER,
            "streamhls.to": self.pp.parserJWPLAYER,
            "streamlyplayer.online": self.pp.parserBYSE,
            "streamlyplayero.online": self.pp.parserBYSE,
            "streamix.so": self.pp.parserSTREAMUP,
            "streamnoads.com": self.pp.parserSTREAMTAPE,
            "streamruby.com": self.pp.parserJWPLAYER,
            "streamta.pe": self.pp.parserSTREAMTAPE,
            "streamta.site": self.pp.parserSTREAMTAPE,
            "streamtape.cc": self.pp.parserSTREAMTAPE,
            "streamtape.com": self.pp.parserSTREAMTAPE,
            "streamtape.net": self.pp.parserSTREAMTAPE,
            "streamtape.site": self.pp.parserSTREAMTAPE,
            "streamtape.to": self.pp.parserSTREAMTAPE,
            "streamtape.xyz": self.pp.parserSTREAMTAPE,
            "streamup.ws": self.pp.parserSTREAMUP,
            "streamvid.su": self.pp.parserJWPLAYER,
            "streamwish.fun": self.pp.parserJWPLAYER,
            "streamwish.to": self.pp.parserJWPLAYER,
            "strmup.cc": self.pp.parserSTREAMUP,
            "strmup.to": self.pp.parserSTREAMUP,
            "strtape.cloud": self.pp.parserSTREAMTAPE,
            "strtpe.link": self.pp.parserSTREAMTAPE,
            "supervideo.cc": self.pp.parserJWPLAYER,
            "supervideo.tv": self.pp.parserJWPLAYER,
            "swdyu.com": self.pp.parserJWPLAYER,
            "swhoi.com": self.pp.parserJWPLAYER,
            "swiftplayers.com": self.pp.parserJWPLAYER,
            "swishsrv.com": self.pp.parserJWPLAYER,
            # t
            "tapeadsenjoyer.com": self.pp.parserSTREAMTAPE,
            "tapeadvertisement.com": self.pp.parserSTREAMTAPE,
            "tapeblocker.com": self.pp.parserSTREAMTAPE,
            "tapewithadblock.org": self.pp.parserSTREAMTAPE,
            "tenstream.net": self.pp.parserJWPLAYER,
            "turboviplay.com": self.pp.parserJWPLAYER,
            "tusfiles.com": self.pp.parserUSERSCLOUDCOM,
            "tusfiles.net": self.pp.parserUSERSCLOUDCOM,
            "tvp.pl": self.pp.parserTVP,
            # u
            "ultrastream.online": self.pp.parserSBS,
            "up4fun.top": self.pp.parserJWPLAYER,
            "up4stream.com": self.pp.parserJWPLAYER,
            "updown.icu": self.pp.parserJWPLAYER,
            "upzone.cc": self.pp.parserUPZONECC,
            "uqload.bz": self.pp.parserJWPLAYER,
            "uqload.com": self.pp.parserJWPLAYER,
            "uqload.cx": self.pp.parserJWPLAYER,
            "uqload.io": self.pp.parserJWPLAYER,
            "uqload.ws": self.pp.parserJWPLAYER,
            "uqloads.xyz": self.pp.parserJWPLAYER,
            "userscloud.com": self.pp.parserUSERSCLOUDCOM,
            # v
            "v.turkvearab.com": self.pp.parserJWPLAYER,
            "veev.to": self.pp.parserVEEV,
            "vide0.net": self.pp.parserDOOD,
            "vidply.com": self.pp.parserDOOD,
            "vidcore.io": self.pp.parserVIDCORE,
            "vidcore.net": self.pp.parserVIDCORE,
            "vidfast.pro": self.pp.parserVIDCORE,
            "vidfast.vc": self.pp.parserVIDCORE,
            "vidlink.pro": self.pp.parserVIDLINK,
            "videa.hu": self.pp.parserVIDEA,
            "videakid.hu": self.pp.parserVIDEA,
            "videasy.net": self.pp.parserVIDEASY,
            "videasy.to": self.pp.parserVIDEASY,
            "vidaraa.cc": self.pp.parserSTREAMUP,
            "vidarax.cc": self.pp.parserSTREAMUP,
            "vidavaca.net": self.pp.parserSTREAMUP,
            "vidara.so": self.pp.parserSTREAMUP,
            "vidara.to": self.pp.parserSTREAMUP,
            "vidavra.cc": self.pp.parserSTREAMUP,
            "vidmatrixa.com": self.pp.parserSTREAMUP,
            "vidora.stream": self.pp.parserJWPLAYER,
            "videzz.net": self.pp.parserJWPLAYER,
            "vidhidehub.com": self.pp.parserJWPLAYER,
            "vidload.co": self.pp.parserVIDLOADCO,
            "vidmoly.biz": self.pp.parserVIDMOLYME,
            "vidmoly.me": self.pp.parserVIDMOLYME,
            "vidmoly.net": self.pp.parserVIDMOLYME,
            "vidmoly.to": self.pp.parserVIDMOLYME,
            "vidneo.cc": self.pp.parserVIDNEO,
            "vidnest.fun": self.pp.parserVIDNEST,
            "vidnest.io": self.pp.parserJWPLAYER,
            "vidoza.co": self.pp.parserJWPLAYER,
            "vidoza.net": self.pp.parserJWPLAYER,
            "vidoza.org": self.pp.parserJWPLAYER,
            "vidrock.net": self.pp.parserVIDROCK,
            "vidsonic.net": self.pp.parserVIDSONIC,
            "vidsrc.bz": self.pp.parserVIDSRC,
            "vidsrc.cc": self.pp.parserMEGAFILES,
            "vidsrc.do": self.pp.parserVIDSRC,
            "vidsrc.fyi": self.pp.parserVIDSRCMOV,
            "vidsrc.gd": self.pp.parserVIDSRC,
            "vidsrc.in": self.pp.parserVIDSRC,
            "vidsrc.io": self.pp.parserVIDSRC,
            "vidsrc.me": self.pp.parserVIDSRC,
            "vidsrc.mn": self.pp.parserVIDSRC,
            "vidsrc.mov": self.pp.parserVIDSRCMOV,
            "vidsrc.net": self.pp.parserVIDSRC,
            "vidsrc.pm": self.pp.parserVIDSRC,
            "vidsrc.tw": self.pp.parserVIDSRC,
            "vidsrc.vc": self.pp.parserVIDSRC,
            "vidsrc.xyz": self.pp.parserVIDSRC,
            "vidsrc-embed.ru": self.pp.parserVIDSRC,
            "vidsrc-embed.su": self.pp.parserVIDSRC,
            "vidsrc-me.ru": self.pp.parserVIDSRC,
            "vidsrc-me.su": self.pp.parserVIDSRC,
            "vidsrcme.ru": self.pp.parserVIDSRC,
            "vidsrcme.su": self.pp.parserVIDSRC,
            "vidup.to": self.pp.parserVIDCORE,
            "vixeo.io": self.pp.parserVIXEO,
            "vixsrc.to": self.pp.parserVIXSRC,
            "vsrc.su": self.pp.parserVIDSRC,
            "vsembed.ru": self.pp.parserVIDSRC,
            "vsembed.su": self.pp.parserVIDSRC,
            "vidzy.org": self.pp.parserJWPLAYER,
            "vinovo.si": self.pp.parserVINOVO,
            "vinovo.to": self.pp.parserVINOVO,
            "vk.com": self.pp.parserVK,
            "vkvideo.ru": self.pp.parserVK,
            "vkvd298.okcdn.ru": self.pp.parserVK,
            "voe.sx": self.pp.parserVOESX,
            "vrra.top": self.pp.parserVRRATOP,
            "vrrstream.ru": self.pp.parserVRRATOP,
            "vsports.pt": self.pp.parserJWPLAYER,
            "vtbe.to": self.pp.parserJWPLAYER,
            "vtube.network": self.pp.parserJWPLAYER,
            "vtube.to": self.pp.parserJWPLAYER,
            "vvide0.com": self.pp.parserDOOD,
            # w
            "wasuytm.store": self.pp.parserSBS,
            "watch.ezplayer.me": self.pp.parserSBS,
            "watch.gxplayer.xyz": self.pp.parserSTREAMEMBED,
            "watchadsontape.com": self.pp.parserSTREAMTAPE,
            "wavehd.com": self.pp.parserJWPLAYER,
            "webcamera.mobi": self.pp.parserWEBCAMERAPL,
            "webcamera.pl": self.pp.parserWEBCAMERAPL,
            "wishembed.pro": self.pp.parserJWPLAYER,
            "wishonly.site": self.pp.parserJWPLAYER,
            "wrzucaj.pl": self.pp.parserSST,
            # x
            "xcoic.com": self.pp.parserBYSE,
            # y
            "yourupload.com": self.pp.parserJWPLAYER,
            "youtu.be": self.pp.parserYOUTUBE,
            "youtube-nocookie.com": self.pp.parserYOUTUBE,
            "youtube.com": self.pp.parserYOUTUBE,
            # z
            "z1ekv717.fun": self.pp.parserBYSE
        }

    @staticmethod
    def getDomain(url, onlyDomain=True):
        parsed_uri = urlparse(url)
        if onlyDomain:
            domain = "{uri.netloc}".format(uri=parsed_uri)
        else:
            domain = "{uri.scheme}://{uri.netloc}/".format(uri=parsed_uri)
        return domain

    @staticmethod
    def decorateUrl(url, metaParams={}):
        return decorateUrl(url, metaParams)

    @staticmethod
    def decorateParamsFromUrl(baseUrl, overwrite=False):
        printDBG("urlparser.decorateParamsFromUrl >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + baseUrl)
        tmp = baseUrl.split("|")
        baseUrl = strwithmeta(tmp[0].strip(), strwithmeta(baseUrl).meta)
        KEYS_TAB = list(DMHelper.HANDLED_HTTP_HEADER_PARAMS)
        KEYS_TAB.extend(["iptv_audio_url", "iptv_proto", "Host", "Accept", "MPEGTS-Live", "PROGRAM-ID"])
        if len(tmp) == 2:
            baseParams = tmp[1].strip()
            try:
                params = parse_qs(baseParams)
                printDBG("PARAMS FROM URL [%s]" % params)
                for key in params.keys():
                    if key not in KEYS_TAB:
                        continue
                    if not overwrite and key in baseUrl.meta:
                        continue
                    try:
                        baseUrl.meta[key] = params[key][0]
                    except Exception:
                        printExc()
            except Exception:
                printExc()
        baseUrl = urlparser.decorateUrl(baseUrl)
        return baseUrl

    def preparHostForSelect(self, v, resolveLink=False):
        urltab = []
        i = 0
        if len(v) > 0:
            for url in list(v.values()) if type(v) is dict else v:
                if self.checkHostSupport(url) == 1:
                    hostName = self.getHostName(url, True)
                    i = i + 1
                    if resolveLink:
                        url = self.getVideoLink(url)
                    if isinstance(url, basestring) and url.startswith("http"):
                        urltab.append({"name": (str(i) + ". " + hostName), "url": url})
        return urltab

    def getItemTitles(self, table):
        out = []
        for i in range(len(table)):
            value = table[i]
            out.append(value[0])
        return out

    def getHostName(self, url, nameOnly=False):
        hostName = strwithmeta(url).meta.get("host_name", "")
        if not hostName:
            match = re.search("https?://(?:www.)?(.+?)/", url)
            if match:
                hostName = match.group(1)
                if nameOnly:
                    n = hostName.split(".")
                    try:
                        hostName = n[-2]
                    except Exception:
                        printExc()
            hostName = hostName.lower()
        printDBG("_________________getHostName: [%s] -> [%s]" % (url, hostName))
        return hostName

    def getParser(self, url, host=None):
        if None is host:
            host = self.getHostName(url)
        parser = self.hostMap.get(host, None)
        if None is parser:
            host2 = host[host.find(".") + 1:]
            printDBG("urlparser.getParser II try host[%s]->host2[%s]" % (host, host2))
            parser = self.hostMap.get(host2, None)
        return parser

    def checkHostSupport(self, url):
        # -1 - not supported
        #  0 - unknown
        #  1 - supported
        host = self.getHostName(url)
        # quick fix
        if host == "facebook.com" and "likebox.php" in url or "like.php" in url or "/groups/" in url:
            return 0
        ret = 0
        parser = self.getParser(url, host)
        if None is not parser:
            return 1
        elif self.isHostsNotSupported(host):
            return -1
        return ret

    def isHostsNotSupported(self, host):
        return host in ["rapidgator.net", "oboom.com"]

    def getVideoLinkExt(self, url):
        urltab = []
        try:
            ret = self.getVideoLink(url, True)
            if isinstance(ret, basestring):
                if len(ret) > 0:
                    host = self.getHostName(url)
                    urltab.append({"name": host, "url": ret})
            elif isinstance(ret, (list, tuple)):
                urltab = ret
            for idx in range(len(urltab)):
                if not self.cm.isValidUrl(url):
                    continue
                url = strwithmeta(urltab[idx]["url"])
                if "User-Agent" not in url.meta:
                    url.meta["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"
                    urltab[idx]["url"] = url
        except Exception:
            printExc()
        return urltab

    def getVideoLink(self, url, acceptsList=False):
        try:
            url = self.decorateParamsFromUrl(url)
            nUrl = ""
            parser = self.getParser(url)
            if None is not parser:
                nUrl = parser(url)
            else:
                host = self.getHostName(url)
                if self.isHostsNotSupported(host):
                    SetIPTVPlayerLastHostError(_('Hosting "%s" not supported.') % host)
                else:
                    SetIPTVPlayerLastHostError(_('Hosting "%s" unknown.') % host)
            if isinstance(nUrl, (list, tuple)):
                if acceptsList:
                    return nUrl
                if len(nUrl) > 0:
                    return nUrl[0]["url"]

            return nUrl
        except Exception:
            printExc()
        return False


class pageParser(CaptchaHelper):
    HTTP_HEADER = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Content-type": "application/x-www-form-urlencoded"}
    FICHIER_DOWNLOAD_NUM = 0

    def __init__(self):
        self.cm = common()
        self.captcha = captchaParser()
        self.ytParser = None
        self.bbcIE = None
        self.sportStream365ServIP = None
        self.COOKIE_PATH = GetCookieDir("")
        self.jscode = {}
        self.jscode["jwplayer"] = "window=this; function stub() {}; function jwplayer() {return {setup:function(){print(JSON.stringify(arguments[0]))}, onTime:stub, onPlay:stub, onComplete:stub, onReady:stub, addButton:stub}}; window.jwplayer=jwplayer;"

    def getPageCF(self, baseUrl, addParams={}, post_data=None):
        addParams["cloudflare_params"] = {"cookie_file": addParams["cookiefile"], "User-Agent": addParams["header"]["User-Agent"]}
        sts, data = self.cm.getPageCFProtection(baseUrl, addParams, post_data)
        return sts, data

    def getYTParser(self):
        if self.ytParser is None:
            try:
                from Plugins.Extensions.IPTVPlayer.libs.youtubeparser import YouTubeParser

                self.ytParser = YouTubeParser()
            except Exception:
                printExc()
                self.ytParser = None
        return self.ytParser

    def getBBCIE(self):
        if self.bbcIE is None:
            try:
                from Plugins.Extensions.IPTVPlayer.libs.youtube_dl.extractor.bbc import BBCCoUkIE

                self.bbcIE = BBCCoUkIE()
            except Exception:
                self.bbcIE = None
                printExc()
        return self.bbcIE

    def parserVRRATOP(self, baseUrl):
        printDBG("parserVRRATOP baseUrl[%s]" % baseUrl)
        urltab = []
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        handshake = self.cm.ph.getSearchGroups(data, r"""var HANDSHAKE = "([^"]+)";""")[0]
        if not handshake:
            handshake = self.cm.ph.getSearchGroups(data, r"""HANDSHAKE\s*=\s*["']([^"^']+?)["']""")[0]
        if not handshake:
            printDBG("parserVRRATOP: Handshake token not found")
            return []
        api_url = "https://vrra.top/api/manifest"
        HTTP_HEADER.update({"Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest", "Referer": baseUrl})
        json_data = json_dumps({"h": handshake})
        sts, resp = self.cm.getPage(api_url, {"header": HTTP_HEADER, "raw_post_data": True}, json_data)
        if not sts:
            printDBG("parserVRRATOP: API request failed")
            return []
        try:
            resp_json = json_loads(resp)
            video_url = resp_json.get("url", "")
        except TypeError:
            printDBG("parserVRRATOP: Failed to parse JSON response")
            return []
        if video_url and self.cm.isValidUrl(video_url):
            host = "https://vrra.top/"
            url = urlparser.decorateUrl(video_url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "iptv_proto": "m3u8"})
            if ".m3u8" in video_url:
                urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
            else:
                urltab.append({"name": "vrra.top", "url": url})
        return urltab

    def parserFREEDISC(self, baseUrl):  # OK according to PL user?
        urltab = []
        COOKIE_FILE = GetCookieDir("FreeDiscPL.cookie")
        HTTP_HEADER = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0 ", "Accept": "text/html", "Accept-Encoding": "gzip, deflate"}
        params = {"header": HTTP_HEADER, "cookiefile": COOKIE_FILE, "use_cookie": True, "save_cookie": True, "load_cookie": True}
        videoId = self.cm.ph.getSearchGroups(baseUrl, r"""\,f\-([0-9]+?)[^0-9]""")[0]
        if videoId == "":
            videoId = self.cm.ph.getSearchGroups(baseUrl, """/video/([0-9]+?)[^0-9]""")[0]
        rest = baseUrl.split("/")[-1].split(",")[-1]
        idx = rest.rfind("-")
        if idx != -1:
            rest = rest[:idx] + ".mp4"
            videoUrl = "https://stream.freedisc.pl/video/%s/%s" % (videoId, rest)
            try:
                params2 = dict(params)
                params2["max_data_size"] = 0
                params2["header"] = dict(HTTP_HEADER)
                params2["header"].update({"Referer": "https://freedisc.pl/static/player/v612/jwplayer.flash.swf"})
                sts, data = self.cm.getPage(videoUrl, params2)
                if self.cm.meta["status_code"] == 200:
                    cookieHeader = self.cm.getCookieHeader(COOKIE_FILE, [], False)
                    urltab.append({"name": "[prepared] freedisc.pl", "url": urlparser.decorateUrl(self.cm.meta["url"], {"Cookie": cookieHeader, "Referer": params2["header"]["Referer"], "User-Agent": params2["header"]["User-Agent"]})})
            except Exception:
                printExc()
        params.update({"load_cookie": False, "cookiefile": GetCookieDir("FreeDiscPL_2.cookie")})
        tmpUrls = []
        if "/embed/" not in baseUrl:
            sts, data = self.cm.getPage(baseUrl, params)
            if not sts:
                return urltab
            try:
                tmp = self.cm.ph.getDataBeetwenMarkers(data, '<script type="application/ld+json">', "</script>", False)[1]
                tmp = json_loads(tmp)
                tmp = tmp["embedUrl"].split("?file=")
                if tmp[1].startswith("https"):
                    urltab.append({"name": "freedisc.pl", "url": urlparser.decorateUrl(tmp[1], {"Referer": tmp[0], "User-Agent": HTTP_HEADER["User-Agent"]})})
                    tmpUrls.append(tmp[1])
            except Exception:
                printExc()
            videoUrl = self.cm.ph.getSearchGroups(data, """<iframe[^>]+?src=["'](http[^"^']+?/embed/[^"^']+?)["']""", 1, True)[0]
        else:
            videoUrl = baseUrl
        if videoUrl != "":
            params["load_cookie"] = True
            params["header"]["Referer"] = baseUrl
            sts, data = self.cm.getPage(videoUrl, params)
            if sts:
                videoUrl = self.cm.ph.getSearchGroups(data, """data-video-url=["'](http[^"^']+?)["']""", 1, True)[0]
                if videoUrl == "":
                    videoUrl = self.cm.ph.getSearchGroups(data, r"""player.swf\?file=(http[^"^']+?)["']""", 1, True)[0]
                if videoUrl.startswith("https") and videoUrl not in tmpUrls:
                    urltab.append({"name": "freedisc.pl", "url": urlparser.decorateUrl(videoUrl, {"Referer": "https://freedisc.pl/static/player/v612/jwplayer.flash.swf", "User-Agent": HTTP_HEADER["User-Agent"]})})
        return urltab

    def parserCDA(self, inUrl):  # Need test
        printDBG("parserCDA inUrl[%r]" % inUrl)
        COOKIE_FILE = GetCookieDir("cdapl.cookie")
        self.cm.clearCookie(COOKIE_FILE, removeNames=["vToken"])
        HTTP_HEADER = {"User-Agent": "Mozilla/5.0 (PlayStation 4 4.71) AppleWebKit/601.2 (KHTML, like Gecko)"}
        defaultParams = {"header": HTTP_HEADER, "use_cookie": True, "load_cookie": True, "save_cookie": True, "cookiefile": COOKIE_FILE}

        def getPage(url, params={}, post_data=None):
            sts, data = False, None
            sts, data = self.cm.getPage(url, defaultParams, post_data)
            tries = 0
            while tries < 3:
                tries += 1
                if self.cm.meta["status_code"] == 429:
                    GetIPTVSleep().Sleep(61)
                    sts, data = self.cm.getPage(url, defaultParams, post_data)
            return sts, data

        def _decorateUrl(inUrl, referer):
            cookies = []
            cj = self.cm.getCookie(COOKIE_FILE)
            for cookie in cj:
                if (cookie.name == "vToken" and cookie.path in inUrl) or cookie.name == "PHPSESSID":
                    cookies.append("%s=%s;" % (cookie.name, cookie.value))
                    printDBG(">> \t%s \t%s \t%s \t%s" % (cookie.domain, cookie.path, cookie.name, cookie.value))
            # prepare extended link
            retUrl = strwithmeta(inUrl)
            retUrl.meta["User-Agent"] = HTTP_HEADER["User-Agent"]
            retUrl.meta["Referer"] = referer
            retUrl.meta["Cookie"] = " ".join(cookies)
            retUrl.meta["iptv_proto"] = "http"
            retUrl.meta["iptv_urlwithlimit"] = False
            retUrl.meta["iptv_livestream"] = False
            return retUrl

        vidMarker = "/video/"
        videoUrls = []
        uniqUrls = []
        tmpUrls = []
        if vidMarker not in inUrl:
            sts, data = getPage(inUrl, defaultParams)
            if sts:
                sts, match = self.cm.ph.getDataBeetwenMarkers(data, "Link do tego video:", "</a>", False)
                if sts:
                    match = self.cm.ph.getSearchGroups(match, 'href="([^"]+?)"')[0]
                else:
                    match = self.cm.ph.getSearchGroups(data, "link[ ]*?:[ ]*?'([^']+?/video/[^']+?)'")[0]
                if match.startswith("http"):
                    inUrl = match
        if vidMarker in inUrl:
            vid = self.cm.ph.getSearchGroups(inUrl + "/", "/video/([^/]+?)/")[0]
            inUrl = "https://ebd.cda.pl/620x368/" + vid
        sts, data = getPage(inUrl, defaultParams)
        if sts:
            qualities = ""
            tmp = self.cm.ph.getDataBeetwenMarkers(data, "player_data='", "'", False)[1].strip()
            if tmp == "":
                tmp = self.cm.ph.getDataBeetwenMarkers(data, 'player_data="', '"', False)[1].strip()
            try:
                tmp = clean_html(tmp).replace("&quot;", '"')
                if tmp != "":
                    data = json_loads(tmp)
                    qualities = data["video"]["qualities"]
            except Exception:
                printExc()
            printDBG("parserCDA qualities[%r]" % qualities)
            for item in qualities:
                tmpUrls.append({"name": "cda.pl " + item, "url": inUrl + "/vfilm?wersja=" + item + "&a=1&t=0"})
        if len(tmpUrls) == 0:
            tmpUrls.append({"name": "cda.pl", "url": inUrl})

        def __appendVideoUrl(params):
            if params["url"] not in uniqUrls:
                videoUrls.append(params)
                uniqUrls.append(params["url"])

        def __ca(dat):
            def rot47(s):
                x = []
                for i in range(len(s)):
                    j = ord(s[i])
                    if j >= 33 and j <= 126:
                        x.append(chr(33 + ((j + 14) % 94)))
                    else:
                        x.append(s[i])
                return "".join(x)

            def __replace(c):
                code = ord(c.group(1))
                if code <= ord("Z"):
                    tmp = 90
                else:
                    tmp = 122
                c = code + 13
                if tmp < c:
                    c -= 26
                return chr(c)

            if not self.cm.isValidUrl(dat):
                try:
                    if "uggcf" in dat:
                        dat = re.sub("([a-zA-Z])", __replace, dat)
                    else:
                        dat = rot47(urllib_unquote(dat))
                        dat = dat.replace(".cda.mp4", "").replace(".2cda.pl", ".cda.pl").replace(".3cda.pl", ".cda.pl")
                        dat = "https://" + str(dat) + ".mp4"
                    if not dat.endswith(".mp4"):
                        dat += ".mp4"
                    dat = dat.replace("0)sss", "").replace('0"d.', ".")
                except Exception:
                    dat = ""
                    printExc()
            return str(dat)

        def __jsplayer(dat):
            if self.jscode.get("data", "") == "":
                sts, self.jscode["data"] = getPage("https://ebd.cda.pl/js/player.js", defaultParams)
                if not sts:
                    return ""
            jsdata = self.jscode.get("data", "")
            jscode = self.cm.ph.getSearchGroups(jsdata, r"""var\s([a-zA-Z]+?,[a-zA-Z]+?,[a-zA-Z]+?,[a-zA-Z]+?,[a-zA-Z]+?,.*?);""")[0]
            tmp = jscode.split(",")
            jscode = ensure_str(base64.b64decode("""ZnVuY3Rpb24gbGEoYSl7fTs="""))
            jscode += self.cm.ph.getSearchGroups(jsdata, r"""(var\s[a-zA-Z]+?,[a-zA-Z]+?,[a-zA-Z]+?,[a-zA-Z]+?,[a-zA-Z]+?,.*?;)""")[0]
            for item in tmp:
                jscode += self.cm.ph.getSearchGroups(jsdata, r"(%s=function\(.*?};)" % item)[0]
            jscode += "file = '%s';" % dat
            tmp = self.cm.ph.getSearchGroups(jsdata, r"""\(this\.options,"video"\)&&\((.*?)=this\.options\.video\);""")[0] + "."
            jscode += self.cm.ph.getDataBeetwenMarkers(jsdata, "%sfile" % tmp, ";", True)[1].replace(tmp, "")
            jscode += "print(file);"
            ret = js_execute(jscode)
            if ret["sts"] and ret["code"] == 0:
                return ret["data"].strip("\n")
            return ""

        for urlItem in tmpUrls:
            if urlItem["url"].startswith("/"):
                inUrl = "https://www.cda.pl/" + urlItem["url"]
            else:
                inUrl = urlItem["url"]
            sts, pageData = getPage(inUrl, defaultParams)
            if not sts:
                continue
            tmpData = self.cm.ph.getDataBeetwenMarkers(pageData, "eval(", "</script>", False)[1]
            if tmpData != "":
                m1 = "$.get"
                if m1 in tmpData:
                    tmpData = tmpData[: tmpData.find(m1)].strip() + "</script>"
                try:
                    tmpData = unpackJSPlayerParams(tmpData, TEAMCASTPL_decryptPlayerParams, 0, True, True)
                except Exception:
                    pass
            tmpData += pageData
            tmp = self.cm.ph.getDataBeetwenMarkers(tmpData, "player_data='", "'", False)[1].strip()
            if tmp == "":
                tmp = self.cm.ph.getDataBeetwenMarkers(tmpData, 'player_data="', '"', False)[1].strip()
            tmp = clean_html(tmp).replace("&quot;", '"')
            printDBG(">>")
            printDBG(tmp)
            printDBG("<<")
            try:
                if tmp != "":
                    _tmp = json_loads(tmp)
                    tmp = __jsplayer(_tmp["video"]["file"])
                    if "cda.pl" not in tmp and _tmp["video"]["file"]:
                        tmp = __ca(_tmp["video"]["file"])
            except Exception:
                tmp = ""
                printExc()
            if tmp == "":
                data = self.cm.ph.getDataBeetwenReMarkers(tmpData, re.compile(r"""modes['"]?[\s]*:"""), re.compile("]"), False)[1]
                data = re.compile(r"""file:[\s]*['"]([^'^"]+?)['"]""").findall(data)
            else:
                data = [tmp]
            if len(data) > 0 and data[0].startswith("http"):
                __appendVideoUrl({"name": urlItem["name"] + " flv", "url": _decorateUrl(data[0], urlItem["url"])})
            if len(data) > 1 and data[1].startswith("http"):
                __appendVideoUrl({"name": urlItem["name"] + " mp4", "url": _decorateUrl(data[1], urlItem["url"])})
            if len(data) == 0:
                data = self.cm.ph.getDataBeetwenReMarkers(tmpData, re.compile(r"video:[\s]*{"), re.compile("}"), False)[1]
                data = self.cm.ph.getSearchGroups(data, r"'(http[^']+?(?:\.mp4|\.flv)[^']*?)'")[0]
                if data != "":
                    typ = " flv "
                    if ".mp4" in data:
                        typ = " mp4 "
                    __appendVideoUrl({"name": urlItem["name"] + typ, "url": _decorateUrl(data, urlItem["url"])})
        self.jscode["data"] = ""
        return videoUrls[::-1]

    def parserDAILYMOTION(self, baseUrl):  # fix 180226
        printDBG("parserDAILYMOTION %s" % baseUrl)
        COOKIE_FILE = self.COOKIE_PATH + "dailymotion.cookie"
        HTTP_HEADER = self.cm.getDefaultHeader()
        httpParams = {"header": HTTP_HEADER, "use_cookie": True, "save_cookie": True, "load_cookie": True, "cookiefile": COOKIE_FILE, "collect_all_headers": True}
        video_id = re.search(r"(?:video=|/video/)([A-Za-z0-9]+)", baseUrl)
        if not video_id:
            printDBG("parserDAILYMOTION -- Video id not found")
            return []
        urlsTab = []
        sts, data = self.cm.getPage(baseUrl, httpParams)
        metadataUrl = "https://www.dailymotion.com/player/metadata/video/" + video_id.group(1)
        sts, data = self.cm.getPage(metadataUrl, httpParams)
        if sts:
            try:
                metadata = json_loads(data)
                error = metadata.get("error")
                if error:
                    title = error.get("title") or error["raw_message"]
                    printDBG("Error accessing metadata: %s " % title)
                    return []
                for quality, media_list in metadata["qualities"].items():
                    for m in media_list:
                        media_url = m.get("url")
                        media_type = m.get("type")
                        if not media_url or media_type == "application/vnd.lumberjack.manifest":
                            continue
                        media_url = urlparser.decorateUrl(media_url, {"Referer": baseUrl})
                        if media_type == "application/x-mpegURL":
                            tmpTab = getDirectM3U8Playlist(media_url, False, checkContent=True, sortWithMaxBitrate=99999999, cookieParams={"header": HTTP_HEADER, "cookiefile": COOKIE_FILE, "use_cookie": True, "save_cookie": True, "load_cookie": True})
                            cookieHeader = self.cm.getCookieHeader(COOKIE_FILE)
                            for tmp in tmpTab:
                                hlsUrl = self.cm.ph.getSearchGroups(tmp["url"], r"""(https?://[^'^"]+?\.m3u8[^'^"]*?)#?""")[0]
                                redirectUrl = strwithmeta(hlsUrl, {"iptv_proto": "m3u8", "Cookie": cookieHeader, "User-Agent": HTTP_HEADER["User-Agent"]})
                                urlsTab.append({"name": "dailymotion.com: %sp hls" % (tmp.get("heigth", "0")), "url": redirectUrl, "quality": tmp.get("heigth", "0")})
                        else:
                            urlsTab.append({"name": quality, "url": media_url})
            except Exception:
                printExc
        return urlsTab

    def parserVK(self, baseUrl):  # Partly work, Login not work
        printDBG("parserVK url[%s]" % baseUrl)
        COOKIE_FILE = GetCookieDir("vkcom.cookie")
        HTTP_HEADER = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36"}
        params = {"header": HTTP_HEADER, "cookiefile": COOKIE_FILE, "use_cookie": True, "save_cookie": True, "load_cookie": True}

        def _doLogin(login, password):
            rm(COOKIE_FILE)
            loginUrl = "https://vk.com/login"
            sts, data = self.cm.getPage(loginUrl, params)
            if not sts:
                return False
            data = self.cm.ph.getDataBeetwenMarkers(data, '<form method="post"', "</form>", False, False)[1]
            action = self.cm.ph.getSearchGroups(data, """action=['"]([^'^"]+?)['"]""")[0]
            post_data = dict(re.findall(r'<input[^>]*name="([^"]*)"[^>]*value="([^"]*)"[^>]*>', data))
            post_data.update({"email": login, "pass": password})
            if not self.cm.isValidUrl(action):
                return False
            params["header"]["Referr"] = loginUrl
            sts, data = self.cm.getPage(action, params, post_data)
            if not sts:
                return False
            sts, data = self.cm.getPage("https://vk.com/", params)
            if not sts:
                return False
            if "logout_link" not in data:
                return False
            return True

        if baseUrl.startswith("http://"):  # NOSONAR
            baseUrl = "https" + baseUrl[4:]
        sts, data = self.cm.getPage(baseUrl, params)
        if not sts:
            return False
        login = config.plugins.iptvplayer.vkcom_login.value
        password = config.plugins.iptvplayer.vkcom_password.value
        try:
            vkcom_login = self.vkcom_login
            vkcom_pass = self.vkcom_pass
        except Exception:
            rm(COOKIE_FILE)
            vkcom_login = ""
            vkcom_pass = ""
            self.vkcom_login = ""
            self.vkcom_pass = ""
            printExc()
        if '<div id="video_ext_msg">' in data or vkcom_login != login or vkcom_pass != password:
            rm(COOKIE_FILE)
            self.vkcom_login = login
            self.vkcom_pass = password
            if login.strip() == "" or password.strip() == "":
                sessionEx = MainSessionWrapper()
                sessionEx.waitForFinishOpen(MessageBox, _("To watch videos from https://vk.com/ you need to login.\nPlease fill your login and password in the IPTVPlayer configuration."), type=MessageBox.TYPE_INFO, timeout=10)
                return False
            elif not _doLogin(login, password):
                sessionEx = MainSessionWrapper()
                sessionEx.waitForFinishOpen(MessageBox, _('Login user "%s" to https://vk.com/ failed!\nPlease check your login data in the IPTVPlayer configuration.' % login), type=MessageBox.TYPE_INFO, timeout=10)
                return False
            else:
                sts, data = self.cm.getPage(baseUrl, params)
                if not sts:
                    return False
        movieUrls = []
        item = self.cm.ph.getSearchGroups(data, r"""['"]?cache([0-9]+?)['"]?[=:]['"]?(http[^"]+?\.mp4[^;^"^']*)[;"']""", 2)
        if item[1] != "":
            cacheItem = {"name": "vk.com: " + item[0] + "p (cache)", "url": item[1].replace("\\/", "/").encode("UTF-8")}
        else:
            cacheItem = None
        tmpTab = re.findall(r"""['"]?url([0-9]+?)['"]?[=:]['"]?(http[^"]+?\.mp4[^;^"^']*)[;"']""", data)
        # prepare urls list without duplicates
        for item in tmpTab:
            item = list(item)
            if item[1].endswith("&amp"):
                item[1] = item[1][:-4]
            item[1] = item[1].replace("\\/", "/")
            found = False
            for urlItem in movieUrls:
                if item[1] == urlItem["url"]:
                    found = True
                    break
            if not found:
                movieUrls.append({"name": "vk.com: " + item[0] + "p", "url": item[1].encode("UTF-8")})
        # move default format to first position in urls list
        # default format should be a configurable
        DEFAULT_FORMAT = "vk.com: 720p"
        defaultItem = None
        for idx in range(len(movieUrls)):
            if movieUrls[idx]["name"] == DEFAULT_FORMAT:
                defaultItem = movieUrls[idx]
                del movieUrls[idx]
                break
        movieUrls = movieUrls[::-1]
        if None is not defaultItem:
            movieUrls.insert(0, defaultItem)
        if None is not cacheItem:
            movieUrls.insert(0, cacheItem)
        return movieUrls

    def parserYOUTUBE(self, url):
        def __getLinkQuality(itemLink):
            val = itemLink["format"].split("x", 1)[0].split("p", 1)[0]
            try:
                val = int(val) if "x" in itemLink["format"] else int(val) - 1
                return val
            except Exception:
                return 0

        if None is not self.getYTParser():
            try:
                formats = config.plugins.iptvplayer.ytformat.value
                height = config.plugins.iptvplayer.ytDefaultformat.value
                dash = self.getYTParser().isDashAllowed()
                vp9 = self.getYTParser().isVP9Allowed()
                age = self.getYTParser().isAgeGateAllowed()
            except Exception:
                printDBG("parserYOUTUBE default ytformat or ytDefaultformat not available here")
                formats = "mp4"
                height = "360"
                dash = False
                vp9 = False
                age = False
            tmpTab, dashTab = self.getYTParser().getDirectLinks(url, formats, dash, dashSepareteList=True, allowVP9=vp9, allowAgeGate=age)
            videoUrls = []
            for item in tmpTab:
                url = strwithmeta(item["url"], {"youtube_id": item.get("id", "")})
                videoUrls.append({"name": "YouTube | {0}: {1}".format(item["ext"], item["format"]), "url": url, "format": item.get("format", "")})
            for item in dashTab:
                url = strwithmeta(item["url"], {"youtube_id": item.get("id", "")})
                if item.get("ext", "") == "mpd":
                    videoUrls.append({"name": "YouTube | dash: " + item["name"], "url": url, "format": item.get("format", "")})
                else:
                    videoUrls.append({"name": "YouTube | custom dash: " + item["format"], "url": url, "format": item.get("format", "")})
            videoUrls = CSelOneLink(videoUrls, __getLinkQuality, int(height)).getSortedLinks()
            return videoUrls
        return False

    def parserFILEONETV(self, baseUrl):  # check 030126
        printDBG("parserFILEONETV baseUrl[%s]" % baseUrl)
        url = baseUrl.replace("show/player", "v")
        sts, data = self.cm.getPage(url)
        if not sts:
            return False
        tmp = self.cm.ph.getDataBeetwenMarkers(data, "setup({", "});", True)[1]
        videoUrl = self.cm.ph.getSearchGroups(tmp, """file[^"^']+?["'](https?://[^"^']+?)['"]""")[0]
        if videoUrl == "":
            videoUrl = self.cm.ph.getSearchGroups(data, r"""<source[^>]+?src=([^'^"]+?)\s[^>]*?video/mp4""")[0]
        if videoUrl.startswith("//"):
            videoUrl = "https:" + videoUrl
        if self.cm.isValidUrl(videoUrl):
            return videoUrl
        return False

    def parserUSERSCLOUDCOM(self, baseUrl):  # Need test
        printDBG("parserUSERSCLOUDCOM baseUrl[%s]\n" % baseUrl)
        HTTP_HEADER = {"User-Agent": "Mozilla/5.0 (Linux; U; Android 4.1.1; en-us; androVM for VirtualBox ('Tablet' version with phone caps) Build/JRO03S) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30"}
        COOKIE_FILE = GetCookieDir("userscloudcom.cookie")
        rm(COOKIE_FILE)
        params = {"header": HTTP_HEADER, "cookiefile": COOKIE_FILE, "use_cookie": True, "save_cookie": True, "load_cookie": True}
        sts, data = self.cm.getPage(baseUrl, params)
        cUrl = self.cm.meta["url"]
        errorTab = ["File Not Found", "File was deleted"]
        for errorItem in errorTab:
            if errorItem in data:
                SetIPTVPlayerLastHostError(_(errorItem))
                break
        tmp = self.cm.ph.getDataBeetwenMarkers(data, '<div id="player_code"', "</div>", True)[1]
        tmp = self.cm.ph.getDataBeetwenMarkers(tmp, ">eval(", "</script>")[1]
        # unpack and decode params from JS player script code
        tmp = unpackJSPlayerParams(tmp, VIDUPME_decryptPlayerParams)
        if tmp is not None:
            data = tmp + data
        videoUrl = self.cm.ph.getSearchGroups(data, r"""['"]?file['"]?[ ]*:[ ]*['"]([^"^']+)['"],""")[0]
        if self.cm.isValidUrl(videoUrl):
            return videoUrl
        videoUrl = self.cm.ph.getSearchGroups(data, """<source[^>]+?src=['"]([^'^"]+?)['"][^>]+?["']video""")[0]
        if self.cm.isValidUrl(videoUrl):
            return videoUrl
        sts, data = self.cm.ph.getDataBeetwenMarkers(data, 'method="POST"', "</Form>", False, False)
        if not sts:
            return False
        post_data = dict(re.findall(r'<input[^>]*name="([^"]*)"[^>]*value="([^"]*)"[^>]*>', data))
        params["header"]["Referer"] = cUrl
        params["max_data_size"] = 0
        sts, data = self.cm.getPage(cUrl, params, post_data)
        if sts and "text" not in self.cm.meta["content-type"]:
            return self.cm.meta["url"]

    def parserUPZONECC(self, baseUrl):  # Need test
        printDBG("parserUPZONECC baseUrl[%r]" % baseUrl)
        baseUrl = strwithmeta(baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        referer = baseUrl.meta.get("Referer")
        if referer:
            HTTP_HEADER["Referer"] = referer
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return False
        cUrl = self.cm.meta["url"]
        if "/embed" not in cUrl:
            url = self.cm.getFullUrl("/embed/" + cUrl.rsplit("/", 1)[(-1)], cUrl)
            sts, tmp = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
            if not sts:
                return False
            data += tmp
            cUrl = self.cm.meta["url"]
        data = ph.search(data, """['"]([a-zA-Z0-9=]{128,512})['"]""")[0]
        js_params = [{"path": GetJSScriptFile("upzonecc.byte")}]
        js_params.append({"code": "print(cnc(atob('%s')));" % data})
        ret = js_execute_ext(js_params)
        url = self.cm.getFullUrl(ret["data"].strip(), cUrl)
        return strwithmeta(url, {"Referer": cUrl, "User-Agent": HTTP_HEADER["User-Agent"]})

    def parser1FICHIERCOM(self, baseUrl):  # Need test
        printDBG("parser1FICHIERCOM baseUrl[%s]" % baseUrl)
        HTTP_HEADER = {
            "User-Agent": "Mozilla/%s%s" % (pageParser.FICHIER_DOWNLOAD_NUM, pageParser.FICHIER_DOWNLOAD_NUM),
            "Accept": "*/*",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "gzip, deflate",
        }
        pageParser.FICHIER_DOWNLOAD_NUM += 1
        COOKIE_FILE = GetCookieDir("1fichiercom.cookie")
        params = {"header": HTTP_HEADER, "cookiefile": COOKIE_FILE, "use_cookie": True, "load_cookie": True, "save_cookie": True}
        rm(COOKIE_FILE)
        login = config.plugins.iptvplayer.fichiercom_login.value
        password = config.plugins.iptvplayer.fichiercom_password.value
        logedin = False
        if login != "" and password != "":
            url = "https://1fichier.com/login.pl"
            post_data = {"mail": login, "pass": password, "lt": "on", "purge": "on", "valider": "Send"}
            params["header"]["Referer"] = url
            sts, data = self.cm.getPage(url, params, post_data)
            if sts:
                if "My files" in data:
                    logedin = True
                else:
                    error = clean_html(self.cm.ph.getDataBeetwenMarkers(data, '<div class="bloc2"', "</div>")[1])
                    sessionEx = MainSessionWrapper()
                    sessionEx.waitForFinishOpen(MessageBox, _("Login on {0} failed.").format("https://1fichier.com/") + "\n" + error, type=MessageBox.TYPE_INFO, timeout=5)
        sts, data = self.cm.getPage(baseUrl, params)
        if not sts:
            return False
        error = clean_html(self.cm.ph.getDataBeetwenNodes(data, ("<div", ">", "bloc"), ("</div", ">"), False)[1])
        if error != "":
            SetIPTVPlayerLastHostError(error)
        data = self.cm.ph.getDataBeetwenNodes(data, ("<form", ">", "post"), ("</form", ">"), caseSensitive=False)[1]
        printDBG("++++")
        action = self.cm.ph.getSearchGroups(data, """action=['"]([^'^"]+?)['"]""", ignoreCase=True)[0]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(data, "<input", ">", caseSensitive=False)
        all_post_data = {}
        for item in tmp:
            name = self.cm.ph.getSearchGroups(item, """name=['"]([^'^"]+?)['"]""", ignoreCase=True)[0]
            value = self.cm.ph.getSearchGroups(item, """value=['"]([^'^"]+?)['"]""", ignoreCase=True)[0]
            all_post_data[name] = value
        if "use_credits" in data:
            all_post_data["use_credits"] = "on"
            logedin = True
        else:
            logedin = False
        error = clean_html(self.cm.ph.getDataBeetwenMarkers(data, '<span style="color:red">', "</div>")[1])
        if error != "" and not logedin:
            timeout = self.cm.ph.getSearchGroups(error, r"""wait\s+([0-9]+)\s+([a-zA-Z]{3})""", 2, ignoreCase=True)
            printDBG(timeout)
            if timeout[1].lower() == "min":
                timeout = int(timeout[0]) * 60
            elif timeout[1].lower() == "sec":
                timeout = int(timeout[0])
            else:
                timeout = 0
            printDBG(timeout)
            if timeout > 0:
                sessionEx = MainSessionWrapper()
                sessionEx.waitForFinishOpen(MessageBox, error, type=MessageBox.TYPE_INFO, timeout=timeout)
            else:
                SetIPTVPlayerLastHostError(error)
        else:
            SetIPTVPlayerLastHostError(error)
        post_data = {"dl_no_ssl": "on", "adzone": all_post_data["adzone"]}
        action = urljoin(baseUrl, action)
        if logedin:
            params["max_data_size"] = 0
            params["header"]["Referer"] = baseUrl
            sts = self.cm.getPage(action, params, post_data)[0]
            if not sts:
                return False
            if "text" not in self.cm.meta.get("content-type", ""):
                videoUrl = self.cm.meta["url"]
            else:
                SetIPTVPlayerLastHostError(error)
                videoUrl = ""
        else:
            params["header"]["Referer"] = baseUrl
            sts, data = self.cm.getPage(action, params, post_data)
            if not sts:
                return False
            videoUrl = self.cm.ph.getSearchGroups(data, """<a[^>]+?href=['"](https?://[^'^"]+?)['"][^>]+?ok btn-general""")[0]
        error = clean_html(self.cm.ph.getDataBeetwenNodes(data, ("<div", ">", "bloc"), ("</div", ">"), False)[1])
        if error != "":
            SetIPTVPlayerLastHostError(error)
        printDBG(">>> videoUrl[%s]" % videoUrl)
        if self.cm.isValidUrl(videoUrl):
            return videoUrl
        return False

    def parserFILECLOUDIO(self, baseUrl):  # Need test
        printDBG("parserFILECLOUDIO baseUrl[%s]" % baseUrl)
        baseUrl = strwithmeta(baseUrl)
        referer = baseUrl.meta.get("Referer", baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        if referer != "":
            HTTP_HEADER["Referer"] = referer
        paramsUrl = {"header": HTTP_HEADER, "with_metadata": True}
        sts, data = self.cm.getPage(baseUrl, paramsUrl)
        if not sts:
            return False
        cUrl = data.meta["url"]
        sitekey = self.cm.ph.getSearchGroups(data, r"""['"]?sitekey['"]?\s*?:\s*?['"]([^"^']+?)['"]""")[0]
        if sitekey != "":
            obj = UnCaptchaReCaptcha(lang=GetDefaultLang())
            obj.HTTP_HEADER.update({"Referer": cUrl, "User-Agent": HTTP_HEADER["User-Agent"]})
            token = obj.processCaptcha(sitekey)
            if token == "":
                return False
        else:
            token = ""
        requestUrl = self.cm.ph.getSearchGroups(data, r"""requestUrl\s*?=\s*?['"]([^'^"]+?)['"]""", ignoreCase=True)[0]
        requestUrl = self.cm.getFullUrl(requestUrl, self.cm.getBaseUrl(cUrl))
        data = self.cm.ph.getDataBeetwenMarkers(data, "$.ajax(", ")", caseSensitive=False)[1]
        data = self.cm.ph.getSearchGroups(data, r"""data['"]?:\s*?(\{[^\}]+?\})""", ignoreCase=True)[0]
        data = data.replace("response", '"%s"' % token).replace("'", '"')
        post_data = json_loads(data)
        paramsUrl["header"].update({"Referer": cUrl, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest"})
        sts, data = self.cm.getPage(requestUrl, paramsUrl, post_data)
        if not sts:
            return False
        data = json_loads(data)
        if self.cm.isValidUrl(data["downloadUrl"]):
            return strwithmeta(data["downloadUrl"], {"Referer": cUrl, "User-Agent": HTTP_HEADER["User-Agent"]})
        return False

    def parserGOOGLE(self, baseUrl):  # Need test
        printDBG("parserGOOGLE baseUrl[%s]" % baseUrl)
        urltab = []
        _VALID_URL = r"https?://(?:(?:docs|drive)\.google\.com/(?:uc\?.*?id=|file/d/)|video\.google\.com/get_player\?.*?docid=)(?P<id>[a-zA-Z0-9_-]{28,})"
        mobj = re.match(_VALID_URL, baseUrl)
        try:
            video_id = mobj.group("id")
            linkUrl = "https://docs.google.com/file/d/" + video_id
        except Exception:
            linkUrl = baseUrl
        _FORMATS_EXT = {
            "5": "flv",
            "6": "flv",
            "13": "3gp",
            "17": "3gp",
            "18": "mp4",
            "22": "mp4",
            "34": "flv",
            "35": "flv",
            "36": "3gp",
            "37": "mp4",
            "38": "mp4",
            "43": "webm",
            "44": "webm",
            "45": "webm",
            "46": "webm",
            "59": "mp4",
        }
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = linkUrl
        COOKIE_FILE = GetCookieDir("google.cookie")
        defaultParams = {"header": HTTP_HEADER, "use_cookie": True, "load_cookie": False, "save_cookie": True, "cookiefile": COOKIE_FILE}
        sts, data = self.cm.getPage(linkUrl, defaultParams)
        if not sts:
            return False
        cookieHeader = self.cm.getCookieHeader(COOKIE_FILE)
        fmtDict = {}
        fmtList = self.cm.ph.getSearchGroups(data, '"fmt_list"[:,]"([^"]+?)"')[0]
        fmtList = fmtList.split(",")
        for item in fmtList:
            item = self.cm.ph.getSearchGroups(item, "([0-9]+?)/([0-9]+?x[0-9]+?)/", 2)
            if item[0] != "" and item[1] != "":
                fmtDict[item[0]] = item[1]
        data = self.cm.ph.getSearchGroups(data, '"fmt_stream_map"[:,]"([^"]+?)"')[0]
        data = data.split(",")
        for item in data:
            item = item.split("|")
            printDBG(">> type[%s]" % item[0])
            if "mp4" in _FORMATS_EXT.get(item[0], ""):
                try:
                    quality = int(fmtDict.get(item[0], "").split("x", 1)[-1])
                except Exception:
                    quality = 0
                urltab.append({"name": "drive.google.com: %s" % fmtDict.get(item[0], "").split("x", 1)[-1] + "p", "quality": quality, "url": strwithmeta(unicode_escape(item[1]), {"Cookie": cookieHeader, "Referer": "https://youtube.googleapis.com/", "User-Agent": HTTP_HEADER["User-Agent"]})})
        urltab.sort(key=lambda item: item["quality"], reverse=True)
        return urltab

    def parserARCHIVEORG(self, linkUrl):  # Need test
        printDBG("parserARCHIVEORG linkUrl[%s]" % linkUrl)
        urltab = []
        sts, data = self.cm.getPage(linkUrl)
        if sts:
            data = self.cm.ph.getSearchGroups(data, r'"sources":\[([^]]+?)]')[0]
            data = "[%s]" % data
            try:
                data = json_loads(data)
                for item in data:
                    if item["type"] == "mp4":
                        urltab.append({"name": "archive.org: " + item["label"], "url": "https://archive.org" + item["file"]})
            except Exception:
                printExc()
        return urltab

    def parserWEBCAMERAPL(self, baseUrl):  # Need test
        printDBG("parserWEBCAMERAPL baseUrl[%s]" % baseUrl)
        sts, data = self.cm.getPage(baseUrl)
        if not sts:
            return False
        tmp = self.cm.ph.getSearchGroups(data, """stream-player__video['"] data-src=['"]([^"^']+?)['"]""")[0]
        if tmp == "":
            tmp = self.cm.ph.getSearchGroups(data, """STREAM_PLAYER_CONFIG[^}]+?['"]video_src['"]:['"]([^"^']+?)['"]""")[0].replace(r"\/", "/")
        if tmp != "":
            tmp = codecs.decode(tmp, "rot13")
            return getDirectM3U8Playlist(tmp, checkContent=True)
        return False

    def parserTVP(self, baseUrl):
        printDBG("parserTVP baseUrl[%s]" % baseUrl)
        vidTab = []
        try:
            from Plugins.Extensions.IPTVPlayer.hosts.hosttvpvod import TvpVod

            vidTab = TvpVod().getLinksForVideo({"url": baseUrl})
        except Exception:
            printExc()
        return vidTab

    def parserBBC(self, baseUrl):  # Need test
        printDBG("parserBBC baseUrl[%r]" % baseUrl)
        vpid = self.cm.ph.getSearchGroups(baseUrl, "/vpid/([^/]+?)/")[0]
        if vpid == "":
            data = self.getBBCIE()._real_extract(baseUrl)
        else:
            formats, subtitles = self.getBBCIE()._download_media_selector(vpid)
            data = {"formats": formats, "subtitles": subtitles}
        subtitlesTab = []
        for sub in data.get("subtitles", []):
            if self.cm.isValidUrl(sub.get("url", "")):
                subtitlesTab.append({"title": _(sub["lang"]), "url": sub["url"], "lang": sub["lang"], "format": sub["ext"]})
        videoUrls = []
        hlsLinks = []
        mpdLinks = []
        for vidItem in data["formats"]:
            if "url" in vidItem:
                url = self.getBBCIE().getFullUrl(vidItem["url"].replace("&amp;", "&"))
                if vidItem.get("ext", "") == "hls" and len(hlsLinks) == 0:
                    hlsLinks.extend(getDirectM3U8Playlist(url, False, checkContent=True))
                elif vidItem.get("ext", "") == "mpd" and len(mpdLinks) == 0:
                    mpdLinks.extend(getMPDLinksWithMeta(url, False))
        tmpTab = [hlsLinks, mpdLinks]
        if config.plugins.iptvplayer.bbc_prefered_format.value == "dash":
            tmpTab.reverse()
        max_bitrate = int(config.plugins.iptvplayer.bbc_default_quality.value)
        for item in tmpTab:

            def __getLinkQuality(itemLink):
                try:
                    return int(itemLink["height"])
                except Exception:
                    return 0

            item = CSelOneLink(item, __getLinkQuality, max_bitrate).getSortedLinks()
            if config.plugins.iptvplayer.bbc_use_default_quality.value:
                videoUrls.append(item[0])
                break
            videoUrls.extend(item)
        if subtitlesTab:
            for idx in range(len(videoUrls)):
                videoUrls[idx]["url"] = strwithmeta(videoUrls[idx]["url"], {"external_sub_tracks": subtitlesTab})
        return videoUrls

    def parserMEDIAFIRECOM(self, baseUrl):  # Need test
        printDBG("parserMEDIAFIRECOM baseUrl[%s]" % baseUrl)
        HEADER = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Accept": "*/*", "Accept-Encoding": "gzip, deflate"}
        sts, data = self.cm.getPage(baseUrl, {"header": HEADER})
        if not sts:
            return False
        data = self.cm.ph.getDataBeetwenNodes(data, ("<div", ">", '"download_link"'), ("</div", ">"))[1]
        data = self.cm.ph.getDataBeetwenNodes(data, ("<script", ">"), ("</script", ">"), False)[1]
        jscode = """window=this;document={};document.write=function(){print(arguments[0]);}"""
        ret = js_execute(jscode + "\n" + data)
        if ret["sts"] and ret["code"] == 0:
            videoUrl = self.cm.ph.getSearchGroups(ret["data"], """href=['"]([^"^']+?)['"]""")[0]
            if self.cm.isValidUrl(videoUrl):
                return videoUrl
        return False

    def parserVIDLOADCO(self, baseUrl):  # Need test
        printDBG("parserVIDLOADCO baseUrl[%r]" % baseUrl)
        baseUrl = strwithmeta(baseUrl)
        cUrl = baseUrl
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl.meta.get("Referer", baseUrl)
        urlParams = {"header": HTTP_HEADER}
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return False
        cUrl = self.cm.meta["url"]
        domain = self.cm.getBaseUrl(cUrl, True)
        urltab = []
        data = self.cm.ph.getAllItemsBeetwenMarkers(data, "sources", "]", False)
        for sourceData in data:
            sourceData = self.cm.ph.getAllItemsBeetwenMarkers(sourceData, "{", "}")
            for item in sourceData:
                marker = item.lower()
                if "video/mp4" not in marker and "video/x-flv" not in marker and "x-mpeg" not in marker:
                    continue
                item = item.replace("\\/", "/")
                url = self.cm.getFullUrl(self.cm.ph.getSearchGroups(item, r"""(?:src|file)['"]?\s*[=:]\s*['"]([^"^']+?)['"]""")[0], self.cm.getBaseUrl(cUrl))
                types = self.cm.ph.getSearchGroups(item, r"""type['"]?\s*[=:]\s*['"]([^"^']+?)['"]""")[0]
                label = self.cm.ph.getSearchGroups(item, r"""type['"]?\s*[=:]\s*['"]([^"^']+?)['"]""")[0]
                printDBG(url)
                if url == "":
                    continue
                url = strwithmeta(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": cUrl})
                if "x-mpeg" in marker:
                    urltab.extend(getDirectM3U8Playlist(url, checkContent=True))
                else:
                    urltab.append({"name": "[%s] %s %s" % (types, domain, label), "url": url})
        return urltab

    def parserSOUNDCLOUDCOM(self, baseUrl):  # Need test
        printDBG("parserSOUNDCLOUDCOM baseUrl[%r]" % baseUrl)
        baseUrl = strwithmeta(baseUrl)
        cUrl = baseUrl
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl.meta.get("Referer", baseUrl)
        urlParams = {"with_metadata": True, "header": HTTP_HEADER}
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return False
        cUrl = data.meta["url"]
        tarckId = self.cm.ph.getSearchGroups(data, r"""tracks\:([0-9]+)""")[0]
        url = self.cm.ph.getSearchGroups(data, r"""['"](https?://[^'^"]+?/widget\-[^'^"]+?\.js)""")[0]
        sts, data = self.cm.getPage(url, urlParams)
        if not sts:
            return False
        clinetIds = self.cm.ph.getSearchGroups(data, r'''client_id\:[A-Za-z]+?\?"([^"]+?)"\:"([^"]+?)"''', 2)
        baseUrl = "https://api.soundcloud.com/i1/tracks/%s/streams?client_id=" % tarckId
        jsData = None
        for clientId in clinetIds:
            url = baseUrl + clientId
            sts, data = self.cm.getPage(url, urlParams)
            if not sts:
                continue
            try:
                jsData = json_loads(data)
            except Exception:
                printExc()
        urls = []
        baseName = urlparser.getDomain(cUrl)
        for key in jsData:
            if "preview" in key:
                continue
            url = jsData[key]
            if self.cm.isValidUrl(url):
                urls.append({"name": baseName + " " + key, "url": url})
        return urls

    def parserFILEFACTORYCOM(self, baseUrl):  # Need test
        printDBG("parserFILEFACTORYCOM baseUrl[%r]" % baseUrl)
        baseUrl = strwithmeta(baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl.meta.get("Referer", baseUrl)
        urlParams = {"header": HTTP_HEADER}
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return False
        cUrl = self.cm.meta["url"]
        domain = urlparser.getDomain(cUrl)
        videoUrl = self.cm.getFullUrl(self.cm.ph.getSearchGroups(data, r"""data\-href=['"]([^'^"]+?)['"]""")[0], self.cm.meta["url"])
        if not videoUrl:
            return False
        sleep_time = self.cm.ph.getSearchGroups(data, r"""data\-delay=['"]([0-9]+?)['"]""")[0]
        try:
            GetIPTVSleep().Sleep(int(sleep_time))
        except Exception:
            printExc()
        sts, data = self.cm.getPage(videoUrl, {"max_data_size": 200 * 1024})
        if sts:
            if "text" not in self.cm.meta["content-type"]:
                return [{"name": domain, "url": videoUrl}]
            msg = clean_html(self.cm.ph.getDataBeetwenNodes(data, ("<div", ">", "box-message"), ("</div", ">"), False)[1])
            SetIPTVPlayerLastHostError(msg)
        return False

    def parserMEDIASET(self, baseUrl):  # Need test
        printDBG("parserMEDIASET baseUrl[%r]" % baseUrl)
        guid = ph.search(baseUrl, r"""https?://(?:(?:www|static3)\.)?mediasetplay\.mediaset\.it/(?:(?:video|on-demand)/(?:[^/]+/)+[^/]+_|player/index\.html\?.*?\bprogramGuid=)([0-9A-Z]{16})""")[0]
        if not guid:
            return
        tp_path = "PR1GhC/media/guid/2702976343/" + guid
        uniqueUrls = set()
        retTab = []
        for asset_type in ("SD", "HD"):
            for f in "MPEG4":
                url = "https://link.theplatform.%s/s/%s?mbr=true&formats=%s&assetTypes=%s" % ("eu", tp_path, f, asset_type)
                sts, data = self.cm.getPage(url, post_data={"format": "SMIL"})
                if not sts:
                    continue
                if "GeoLocationBlocked" in data:
                    SetIPTVPlayerLastHostError(ph.getattr(data, "abstract"))
                tmp = ph.findall(data, "<video", ">")
                for item in tmp:
                    url = ph.getattr(item, "src")
                    if not self.cm.isValidUrl(url):
                        continue
                    if url not in uniqueUrls:
                        uniqueUrls.add(url)
                        retTab.append({"name": "%s - %s" % (f, asset_type), "url": url})
        return retTab

    def parserVIDMOLYME(self, baseUrl):  # fix 150126
        printDBG("parserVIDMOLYME baseUrl[%r]" % baseUrl)
        urltab = []
        HTTP_HEADER = self.cm.getDefaultHeader()
        baseUrl = strwithmeta(baseUrl)
        if "embed" not in baseUrl:
            video_id = self.cm.ph.getSearchGroups(baseUrl + "/", "/([A-Za-z0-9]{12})[/.]")[0]
            baseUrl = "{}/embed-{}.html".format(urlparser.getDomain(baseUrl, False), video_id)
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return False
        if "<title>Please wait</title>" in data:
            url_id = self.cm.ph.getSearchGroups(data, r"\?g=([a-fA-F0-9]+)")[0]
            url = "{}?g={}".format(baseUrl, url_id)
            HTTP_HEADER.update({"Referer": baseUrl, "Upgrade-Insecure-Requests": "1"})
            sts, data = self.cm.getPage(url, {"header": HTTP_HEADER})
            if not sts:
                return False
        url = self.cm.ph.getSearchGroups(data, """sources[^'^"]*?['"]([^'^"]+?)['"]""")[0]
        if url:
            host = urlparser.getDomain(baseUrl, False)
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
            urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=999999999))
        return urltab

    def parserVOESX(self, baseUrl):
        def voe_decode(ct):
            txt = "".join(chr((ord(i) - 52) % 26 + 65) if 65 <= ord(i) <= 90 else chr((ord(i) - 84) % 26 + 97) if 97 <= ord(i) <= 122 else i for i in ct)
            lut = [r"#&", r"%?", r"\*~", r"~@", r"\^\^", r"!!", r"@$"]
            for pattern in lut:
                txt = re.sub(pattern, "_", txt)
            txt = "".join(txt.split("_"))

            def fix_b64_padding(s):
                return s + "=" * (-len(s) % 4)

            try:
                step1 = base64.b64decode(fix_b64_padding(txt)).decode()
                step2 = "".join(chr(ord(c) - 3) for c in step1)
                final = base64.b64decode(fix_b64_padding(step2[::-1])).decode()
                return json_loads(final)
            except Exception as e:
                printDBG(e)
                return ""

        printDBG("parserVOESX baseUrl[%r]" % baseUrl)
        sts, data = self.cm.getPage(baseUrl)
        if not sts:
            return False
        if "const currentUrl" in data:
            url = ph.search(data, r"""window.location.href\s*=\s*['"]([^"^']+?)['"]""")[0]
            sts, data = self.cm.getPage(url)
            if not sts:
                return False
        r = re.search(r"""['"]?hls['"]?\s*?:\s*?['"]([^'^"]+?)['"]""", data)
        if r:
            hlsUrl = ensure_str(base64.b64decode(r.group(1)))
            if hlsUrl.startswith("//"):
                hlsUrl = "https:" + hlsUrl
            if self.cm.isValidUrl(hlsUrl):
                params = {"iptv_proto": "m3u8", "Referer": baseUrl, "Origin": urlparser.getDomain(baseUrl, False)}
                hlsUrl = urlparser.decorateUrl(hlsUrl, params)
                return getDirectM3U8Playlist(hlsUrl, checkExt=False, checkContent=True, sortWithMaxBitrate=999999999)
        else:
            r = re.search(r'\w+="([^"]+)";function', data)
            if not r:
                r = re.search(r"""application/json">[^>]"([^"]+)""", data)
            urltab = []
            if r:
                r = voe_decode(ensure_str(r.group(1)))
                if r:
                    subtitles = [{"title": "", "lang": x.get("label"), "url": "https://{0}{1}".format(baseUrl.split("/")[2], x.get("file"))} for x in r.get("captions") if x.get("kind") == "captions"]
                    key_list = ["source", "file", "direct_access_url"]
                    for key in key_list:
                        if key in r:
                            url = r[key]
                            if ".m3u8" in url:
                                url = urlparser.decorateUrl(url, {"iptv_proto": "m3u8", "Referer": baseUrl, "Origin": urlparser.getDomain(baseUrl, False), "external_sub_tracks": subtitles})
                                urltab.extend(getDirectM3U8Playlist(url, checkExt=False, checkContent=True, sortWithMaxBitrate=999999999))
                            else:
                                if subtitles:
                                    url = urlparser.decorateUrl(url, {"external_sub_tracks": subtitles})
                                urltab.append({"name": "MP4", "url": url})
            return urltab

    def parserVEEV(self, baseUrl):  # update 211225
        printDBG("parserVEEV baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER.update({"Referer": baseUrl, "Origin": urlparser.getDomain(baseUrl, False), "Accept-Language": "en-US,en;q=0.5"})
        urlParams = {"header": HTTP_HEADER}

        def veev_decode(etext):
            result = []
            lut = {}
            n = 256
            c = etext[0]
            result.append(c)
            for char in etext[1:]:
                code = ord(char)
                nc = char if code < 256 else lut.get(code, c + c[0])
                result.append(nc)
                lut[n] = c + nc[0]
                n += 1
                c = nc
            return "".join(result)

        def js_int(x):
            return int(x) if x.isdigit() else 0

        def build_array(encoded_string):
            d = []
            c = list(encoded_string)
            count = js_int(c.pop(0))
            while count:
                current_array = []
                for _x in range(count):
                    current_array.insert(0, js_int(c.pop(0)))
                d.append(current_array)
                count = js_int(c.pop(0))
            return d

        def decode_url(etext, tarray):
            ds = etext
            for t in tarray:
                if t == 1:
                    ds = ds[::-1]
                ds = unhexlify(ds).decode("utf8")
                ds = ds.replace("dXRmOA==", "")
            return ds

        urltab = []
        sub_tracks = []
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return []
        url = self.cm.meta.get("url", "")
        if url != "":
            baseUrl = url
        items = re.findall(r"""[\.\s'](?:fc|_vvto\[[^\]]*)(?:['\]]+)?\s*[:=]\s*['"]([^'"]+)""", data)
        if items:
            for f in items[::-1]:
                ch = veev_decode(ensure_binary(f).decode("utf8"))
                if ch != f:
                    params = {"op": "player_api", "cmd": "gi", "file_code": baseUrl.split("/")[-1], "ch": ch, "ie": 1}
                    durl = self.cm.getFullUrl("/dl", baseUrl) + "?" + urllib_urlencode(params)
                    sts, jresp = self.cm.getPage(durl, urlParams)
                    if not sts:
                        return []
                    jresp = json_loads(jresp).get("file")
                    if jresp and jresp.get("file_status") == "OK":
                        sub_tracks = [{"title": sub.get("label"), "url": sub.get("src"), "lang": sub.get("language")} for sub in jresp.get("captions_list", [])]
                        url = decode_url(veev_decode(ensure_binary(jresp.get("dv")[0].get("s")).decode("utf8")), build_array(ch)[0])
                        if url:
                            url = strwithmeta(url, HTTP_HEADER)
                            urltab.append({"name": "MP4", "url": urlparser.decorateUrl(url, {"external_sub_tracks": sub_tracks})})
        return urltab

    def parserDOOD(self, baseUrl):  # update 240925
        urlsTab = []
        sub_tracks = []
        printDBG("parserDOOD baseUrl [%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        urlParams = {"header": HTTP_HEADER}
        urls = ["all3do.com", "d0000d.com", "d000d.com", "d0o0d.com", "d-s.io", "do0od.com", "dooodster.com", "doodstream.com", "doply.net", "dooood.com", "do7go.com", "ds2play.com", "ds2video.com", "dood.cx", "dood.la", "dood.li", "dood.pm", "dood.re", "dood.sh", "dood.so", "dood.stream", "dood.to", "dood.watch", "dood.work", "dood.wf", "dood.ws", "dood.yt", "doods.pro", "doodcdn.io", "vide0.net", "vidply.com", "vvide0.com", "playmogo.com"]
        for url in urls:
            if url in baseUrl:
                baseUrl = baseUrl.replace(url, "dsvplay.com")
        baseUrl = baseUrl.replace("/w/", "/e/")  # watch page -> embed page
        host = "https://%s" % urlparser.getDomain(baseUrl, True)
        if "/d/" in baseUrl:
            sts, data = self.cm.getPage(baseUrl, urlParams)
            if not sts:
                return []
            url = self.cm.ph.getSearchGroups(data, 'iframe src="([^"]+)')[0]
            baseUrl = host + url
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return []
        sub = re.findall(r"""dsplayer\.addRemoteTextTrack\({src:'([^']+)',\s*label:'([^']*)',kind:'captions'""", data)
        if sub:
            sub_tracks = [{"title": "", "url": "https:" + src if src.startswith("//") else src, "lang": label} for src, label in sub if len(label) > 1]
        match = re.search(r"""dsplayer\.hotkeys[^']+'([^']+).+?function\s*makePlay.+?return[^?]+([^"]+)""", data, re.DOTALL)
        if match:
            token = match.group(2)
            sts, data = self.cm.getPage("%s%s" % (host, match.group(1)), urlParams)
            if not sts:
                return []
            url = data.strip() if "cloudflarestorage." in data else random_seed(10, data) + token + str(int(time.time() * 1000))
            url = urlparser.decorateUrl(url, {"external_sub_tracks": sub_tracks, "User-Agent": urlParams["header"]["User-Agent"], "Referer": baseUrl})
            urlsTab.append({"name": "mp4", "url": url})
        return urlsTab

    def parserSTREAMTAPE(self, baseUrl):  # check 150625
        printDBG("parserSTREAMTAPE baseUrl[%s]" % baseUrl)
        urltabs = []
        subTracks = []
        COOKIE_FILE = GetCookieDir("streamtape.cookie")
        httpParams = {"header": {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0", "Accept": "*/*", "Accept-Encoding": "gzip", "Referer": baseUrl.meta.get("Referer", baseUrl)}, "use_cookie": True, "load_cookie": True, "save_cookie": True, "cookiefile": COOKIE_FILE}
        sts, data = self.cm.getPage(baseUrl, httpParams)
        code = self.cm.meta["status_code"]
        if sts and code != 404:
            subTracksData = self.cm.ph.getAllItemsBeetwenMarkers(data, "<track ", ">", False, False)
            for track in subTracksData:
                if 'kind="captions"' not in track:
                    continue
                subUrl = self.cm.ph.getSearchGroups(track, 'src="([^"]+?)"')[0]
                if subUrl.startswith("/"):
                    subUrl = urlparser.getDomain(baseUrl, False) + subUrl
                if subUrl.startswith("http"):
                    subLang = self.cm.ph.getSearchGroups(track, 'srclang="([^"]+?)"')[0]
                    subLabel = self.cm.ph.getSearchGroups(track, 'label="([^"]+?)"')[0]
                    subTracks.append({"title": subLabel + "_" + subLang, "url": subUrl, "lang": subLang, "format": "srt"})
            t = self.cm.ph.getSearchGroups(data, """innerHTML = ([^;]+?);""")[0] + ";"
            printDBG("parserSTREAMTAPE t[%s]" % t)
            t = t.replace(".substring(", "[", 1).replace(").substring(", ":][").replace(");", ":]") + "[1:]"
            t = eval(t)
            if t.startswith("/"):
                t = "https:/" + t
            if self.cm.isValidUrl(t):
                cookieHeader = self.cm.getCookieHeader(COOKIE_FILE, [], False)
                params = {"Cookie": cookieHeader, "Referer": httpParams["header"]["Referer"], "User-Agent": httpParams["header"]["User-Agent"]}
                params["external_sub_tracks"] = subTracks
                t = urlparser.decorateUrl(t, params)
                params = {"name": "link", "url": t}
                urltabs.append(params)
        return urltabs

    def parserSST(self, url):  # update 020926
        printDBG("parserSST baseUrl[%s]" % url)
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(url, {"header": HTTP_HEADER, "with_metadata": True})
        if not sts:
            return []
        host = urlparser.getDomain(getattr(data, "meta", {}).get("url", url), False)  # fsst.online -> incvideo1.online after redirect
        meta = {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]}
        urltab = []
        srcList = re.findall(r'<source[^>]*src="([^"]+)"[^>]*label="([^"]+)"', data)
        if srcList:
            for surl, q in srcList:
                urltab.append({"name": q, "url": urlparser.decorateUrl(surl, dict(meta))})
            return urltab
        m = re.search(r'file\s*:\s*"([^"]+)"', data)
        if not m:
            return []
        fileUrl = m.group(1)
        if "[" in fileUrl:  # Playerjs multi-quality: [360p]url,[720p]url
            for quality, qurl in re.findall(r"\[(\d+p)\](https?://[^\s,\]]+)", fileUrl):
                urltab.append({"name": quality, "url": urlparser.decorateUrl(qurl, dict(meta))})
        elif self.cm.isValidUrl(fileUrl):
            q = self.cm.ph.getSearchGroups(data, r'default_quality\s*:\s*"([^"]+)')[0] or "MP4"
            urltab.append({"name": q, "url": urlparser.decorateUrl(fileUrl, dict(meta))})
        return urltab

    def parserSBS(self, baseUrl):  # update 020126
        printDBG("parserSBS baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        referer = baseUrl.meta.get("Referer")
        HTTP_HEADER["Referer"] = "https://%s/" % baseUrl.split("/")[2]
        urlParams = {"header": HTTP_HEADER}
        if "#" in baseUrl and referer:
            host = referer.split("/")[2]
            url = urlparser.getDomain(baseUrl, False)
            baseUrl = "%sapi/v1/video?id=%s&w=1904&h=969&r=%s" % (url, baseUrl.split("#")[1], host)
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return []
        data = unhexlify(data[:-1])
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(b"\x6b\x69\x65\x6d\x74\x69\x65\x6e\x6d\x75\x61\x39\x31\x31\x63\x61", b"\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x6f\x69\x75\x79\x74\x72"))
        data = decrypter.feed(data)
        data += decrypter.feed()
        data = data.decode("utf-8")
        data = json_loads(data)
        hls = data.get("source")
        subTracks = []
        for lang, src in data.get("subtitle", {}).items():
            if src.startswith("/"):
                src = url[:-1] + src.split("#")[0]
            subTracks.append({"title": "", "url": src, "lang": lang})
        urltab = []
        if hls:
            hls = urlparser.decorateUrl(hls, {"iptv_proto": "m3u8", "User-Agent": HTTP_HEADER["User-Agent"], "Referer": url, "Origin": url[:-1], "external_sub_tracks": subTracks})
            urltab.extend(getDirectM3U8Playlist(hls))
        return urltab

    def parserVINOVO(self, baseUrl):  # fix 15.06.25
        printDBG("parserVINOVO baseUrl[%s]" % baseUrl)
        COOKIE_FILE = self.COOKIE_PATH + "vinovo.cookie"
        HTTP_HEADER = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0"}
        sts, data = self.cm.getPage(baseUrl.replace("/d/", "/e/"), {"header": HTTP_HEADER, "use_cookie": True, "save_cookie": True, "load_cookie": False, "cookiefile": COOKIE_FILE})
        if not sts:
            return []
        token = re.search(r'name="token"\s*content="([^"]+)', data)
        video_data = re.search(r'data-base="([^"]+)', data)
        filecode = re.search(r'file_code"\s*(?:content="([^"]*)"|\s*="([^"]*)")>', data)
        if token and video_data and filecode:
            rurl = urljoin(baseUrl, "/")
            recaptcha = girc(data, rurl)
            HTTP_HEADER.update({"Origin": rurl[:-1], "Referer": baseUrl, "X-Requested-With": "XMLHttpRequest"})
            post_data = {"token": token.group(1), "recaptcha": recaptcha}
            api_url = "https://vinovo.to/api/file/url/{0}".format(filecode.group(1))
            sts, data = self.cm.getPage(api_url, {"header": HTTP_HEADER, "use_cookie": True, "save_cookie": False, "load_cookie": True, "cookiefile": COOKIE_FILE}, post_data)
            if not sts:
                return []
            resp_json = json_loads(data)
            if resp_json.get("status") == "ok":
                HTTP_HEADER.pop("X-Requested-With")
                vid_src = "{0}/stream/{1}".format(video_data.group(1), resp_json.get("token"))
                return [{"name": "MP4", "url": urlparser.decorateUrl(vid_src, HTTP_HEADER)}]
        return []

    def parserSTREAMEMBED(self, baseUrl):  # fix 191025
        urltab = []
        printDBG("parserSTREAMEMBED baseUrl[%s]" % baseUrl)
        headers = self.cm.getDefaultHeader()
        host = urlparser.getDomain(baseUrl, False)
        COOKIE_FILE = self.COOKIE_PATH + "streamembed.cookie"
        sts, data = self.cm.getPage(baseUrl, {"header": headers, "use_cookie": True, "save_cookie": True, "load_cookie": False, "cookiefile": COOKIE_FILE})
        if not sts:
            return []
        data = re.search(r"var\s*video\s*=\s*(.*?);\s", data)
        if data:
            data = json_loads(data.group(1))
            url = "{}m3u8/{}/{}/master.txt?s=1&id={}&cache=1".format(host, data.get("uid"), data.get("md5"), data.get("id"))
            headers["Referer"] = host
            headers["Origin"] = host[:-1]
            headers["Accept"] = "*/*"
            urltab = getDirectM3U8Playlist(url, checkExt=False, checkContent=True, cookieParams={"header": headers, "cookiefile": COOKIE_FILE, "use_cookie": True, "save_cookie": True})
        return urltab

    def parserHEXLOAD(self, baseUrl):  # add 160625
        printDBG("parserHEXLOAD baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        urltab = []
        postdata = {"op": "download3", "id": urlparse(baseUrl).path.strip("/"), "ajax": "1", "method_free": "1", "dataType": "json"}
        sts, data = self.cm.getPage("https://hexload.com/download", HTTP_HEADER, postdata)
        if not sts:
            return []
        data = json_loads(data)
        url = data.get("result", {}).get("url")
        if url:
            urltab.append({"name": "mp4", "url": url})
        return urltab

    def parserVIDEA(self, baseUrl):  # add 180625
        printDBG("parserVIDEA baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        STATIC_SECRET = "xHb0ZvME5q8CBcoQi6AngerDu3FGO9fkUlwPmLVY_RTzj2hJIS4NasXWKy1td7p"
        pageParams = {"header": HTTP_HEADER, "collect_all_headers": True}

        def grabSlCookie(prev):
            m = re.search(r"\bsl=([^;\s]+)", self.cm.meta.get("set-cookie", ""))
            if m and m.group(1) != "deleted":
                return "sl=" + m.group(1)
            return prev

        videaXml = ""
        slCookie = ""
        for _retry in range(3):
            sts, data = self.cm.getPage(baseUrl, dict(pageParams))
            if not sts:
                return []
            slCookie = grabSlCookie(slCookie)
            url = baseUrl if "/player" in baseUrl else urljoin(baseUrl, re.search(r'<iframe.*?src="(/player\?[^"]+)"', data).group(1))
            sts, nonce = self.cm.getPage(url, dict(pageParams))
            if not sts:
                return []
            slCookie = grabSlCookie(slCookie)
            nonce = re.search(r'_xt\s*=\s*"([^"]+)"', nonce).group(1)
            l, s = nonce[:32], nonce[32:]
            result = "".join(s[i - (STATIC_SECRET.index(l[i]) - 31)] for i in range(32))
            query = parse_qs(urlparse(url).query)
            _s = random_seed(8)
            _t = result[:16]
            _param = "f=%s" % query["f"][0] if "f" in query else "v=%s" % query["v"][0]
            hurl = "https://%s/player/xml?platform=desktop&%s&_s=%s&_t=%s" % (urlparser.getDomain(baseUrl), _param, _s, _t)
            sts, videaXml = self.cm.getPage(hurl, dict(pageParams))
            if not sts:
                return []
            slCookie = grabSlCookie(slCookie)
            if not videaXml.startswith("<?xml"):
                key = result[16:] + _s + self.cm.meta.get("x-videa-xs", "")
                videaXml = rc4(videaXml, key)
            noembed = re.search(r'<error.*?"noembed".*?>\s*(.*?)\s*</error>', videaXml)
            if not noembed:
                break
            newUrl = noembed.group(1).strip().replace("&amp;", "&")
            if newUrl.startswith("//"):
                newUrl = "https:" + newUrl
            elif newUrl.startswith("/"):
                newUrl = urljoin(baseUrl, newUrl)
            if not newUrl.lower().startswith("http"):
                break
            printDBG("parserVIDEA noembed redirect -> [%s]" % newUrl)
            baseUrl = newUrl
        else:
            return []

        subTracks = []
        for block in re.findall(r"<subtitle\b[^>]*>", videaXml):
            src = self.cm.ph.getSearchGroups(block, r'src="([^"]+)"')[0].replace("&amp;", "&")
            lang = self.cm.ph.getSearchGroups(block, r'(?:title|lang|language)="([^"]+)"')[0]
            if not src:
                continue
            src = "https:" + src if src.startswith("//") else src
            subTracks.append({"title": lang, "url": src, "lang": lang or "und"})

        urltab = []
        for block in re.findall(r"<video_source\b[^>]*>[^<]*</video_source>", videaXml):
            label = self.cm.ph.getSearchGroups(block, r'name="([^"]+)"')[0]
            exp = self.cm.ph.getSearchGroups(block, r'exp="([^"]*)"')[0]
            url = self.cm.ph.getDataBeetwenMarkers(block, ">", "</video_source>", False)[1].replace("&amp;", "&")
            if not url:
                continue
            url = "https:" + url if url.startswith("//") else url
            if "md5=" not in url:
                hsh = re.search(r"<hash_value_%s>([^<]+)<" % re.escape(label), videaXml)
                if not hsh:
                    continue
                if not exp:
                    exp = self.cm.ph.getSearchGroups(url, r"expires=([0-9]+)")[0]
                url = "%s?md5=%s&expires=%s" % (url, hsh.group(1), exp)
            urltab.append({"name": label, "url": url})
        urltab.reverse()
        if not urltab:
            mhls = re.search(r"<master_playlist_url>([^<]+)", videaXml)
            if mhls:
                hlsUrl = mhls.group(1).strip().replace("&amp;", "&")
                hlsUrl = "https:" + hlsUrl if hlsUrl.startswith("//") else hlsUrl
                urltab.append({"name": "HLS", "url": strwithmeta(hlsUrl, {"iptv_proto": "m3u8"})})
        if not urltab:
            for block in re.findall(r"<audio_source\b[^>]*>[^<]*</audio_source>", videaXml):
                url = self.cm.ph.getDataBeetwenMarkers(block, ">", "</audio_source>", False)[1].replace("&amp;", "&")
                if not url:
                    continue
                url = "https:" + url if url.startswith("//") else url
                urltab.append({"name": "Audio", "url": url})
        try:
            autoQuality = config.plugins.iptvplayer.videa_quality.value
        except Exception:
            autoQuality = False
        if autoQuality and urltab:
            best_source = None
            best_quality = 0
            for source in urltab:
                match = re.search(r"(\d{3,4})\s*[pP]", source.get("name", ""))
                if match and int(match.group(1)) > best_quality:
                    best_quality = int(match.group(1))
                    best_source = source
            if best_source:
                printDBG("Videa: Auto quality selected [%s] - %sp" % (best_source.get("name", ""), best_quality))
                urltab = [best_source]
        extraMeta = {}
        if slCookie:
            extraMeta["Cookie"] = slCookie
        if subTracks:
            extraMeta["external_sub_tracks"] = subTracks
        if extraMeta:
            for item in urltab:
                item["url"] = strwithmeta(item["url"], extraMeta)
        return urltab

    def parserSTREAMUP(self, baseUrl):  # fix 300426
        printDBG("parserSTREAMUP baseUrl[%s]" % baseUrl)
        urltab = []
        subTracks = []
        host = urlparser.getDomain(baseUrl, False)
        filecode = self.cm.ph.getSearchGroups(baseUrl, r"https:\/\/[a-zA-Z0-9.]+\/(?:e\/|v\/)?([A-Za-z0-9]+)")
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl
        HTTP_HEADER["Origin"] = host[:-1]
        post = json_dumps({"filecode": filecode[0], "device": "web"})
        sts, data = self.cm.getPage(host + "api/stream", {"header": HTTP_HEADER, "raw_post_data": True}, post)
        if not sts:
            return []
        data = json_loads(data)
        url = data.get("streaming_url")
        if isinstance(data.get("subtitles"), list):
            subTracks = [{"title": "", "url": sub.get("file_path"), "lang": sub.get("language")} for sub in data.get("subtitles", []) if sub.get("file_path") and sub.get("language")]
        if url:
            url = url.replace("\r", "").replace("\n", "")
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks})
            if ".m3u8" in url:
                urltab.extend(getDirectM3U8Playlist(url))
            else:
                urltab.append({"name": "MP4", "url": url})
        return urltab

    def parserFIRESTREAM(self, baseUrl):  # add 020926 - firestream.to (filmpalast/kinoger "Firestream HD")
        printDBG("parserFIRESTREAM baseUrl[%s]" % baseUrl)
        urltab = []
        host = urlparser.getDomain(baseUrl, False)
        mid = self.cm.ph.getSearchGroups(baseUrl, r"/(?:e|v)/([0-9A-Za-z_-]+)")[0]
        if mid == "":
            return []
        HTTP_HEADER = self.cm.getDefaultHeader()
        embedUrl = "%se/%s" % (host, mid)
        HTTP_HEADER["Referer"] = embedUrl
        sts, data = self.cm.getPage(embedUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        blob = self.cm.ph.getSearchGroups(data, r'id="token-blob"[^>]*>([^<]+)')[0].strip()
        if blob == "":
            return []
        postHeader = dict(HTTP_HEADER)
        postHeader.update({"Referer": embedUrl, "Origin": host[:-1], "Content-Type": "application/json"})
        sts, data = self.cm.getPage("%sapi/videos/%s/resolve" % (host, mid), {"header": postHeader, "raw_post_data": True}, json_dumps({"blob": blob}))
        if not sts:
            return []
        try:
            data = json_loads(data)
        except Exception:
            printExc()
            return []
        for key, name in (("signedVideoUrl", "HD"), ("signedVideoSdUrl", "SD")):
            url = data.get(key)
            if not url:
                continue
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
            if ".m3u8" in url:
                urltab.extend(getDirectM3U8Playlist(url))
            else:
                urltab.append({"name": name, "url": url})
        return urltab

    def parserPLAYMATE(self, baseUrl):  # add 020926 - playmate.to (filmpalast "Playmate HD")
        printDBG("parserPLAYMATE baseUrl[%s]" % baseUrl)
        urltab = []
        subTracks = []
        host = urlparser.getDomain(baseUrl, False)
        mid = self.cm.ph.getSearchGroups(baseUrl, r"/(?:watch|embed|e|v)/([0-9A-Za-z]+)")[0]
        if mid == "":
            return []
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER.update({"Referer": "%sembed/%s" % (host, mid), "Origin": host[:-1], "Content-Type": "application/json"})
        sts, data = self.cm.getPage("%sapi/s" % host, {"header": HTTP_HEADER, "raw_post_data": True}, json_dumps({"c": mid, "d": "web"}))
        if not sts:
            return []
        try:
            data = json_loads(data)
        except Exception:
            printExc()
            return []
        for sub in (data.get("kx") or []):
            surl = sub.get("sf") or sub.get("file") or ""
            if surl:
                subTracks.append({"title": "", "url": "https:" + surl if surl.startswith("//") else surl, "lang": sub.get("sl") or sub.get("label") or ""})
        url = data.get("sx")
        if not url:
            return []
        meta = {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks}
        if ".m3u8" in url or "/hls/" in url or url.split("?")[0].endswith(".txt"):
            # playmate's HLS master/variant playlists use a .txt extension AND the
            # segments are disguised as .css/.js/.woff (anti-adblock). exteplayer3
            # chokes on that; hlsdl handles it -> needs "[HLS/M3U8] buffering" enabled.
            meta["iptv_proto"] = "m3u8"
            urltab.append({"name": "HLS", "url": urlparser.decorateUrl(url, meta)})
        else:
            urltab.append({"name": "MP4", "url": urlparser.decorateUrl(url, meta)})
        return urltab

    def parserSHAREVIDEO(self, url):  # add 160925
        printDBG("parserSHAREVIDEO baseUrl[%s]" % url)
        HTTP_HEADER = self.cm.getDefaultHeader()
        host = urlparser.getDomain(url, False)
        sts, data = self.cm.getPage("%sapi/v1/videos/%s" % (host, url.split("/")[-1]), HTTP_HEADER)
        if not sts:
            return []
        urltab = []
        url = self.cm.ph.getSearchGroups(data, 'playlistUrl":"([^"]+)')[0]
        if url:
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
            urltab.extend(getDirectM3U8Playlist(url))
        return urltab

    def parserBYSE(self, baseUrl):  # fix 240826 - captcha/proof-of-work challenge support
        UA = "Mozilla/5.0 (Linux; Android 10; TX6s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"

        def fp(x, y, z):  # thx Gujal00
            v_id = hexlify(urandom(x)).decode()
            d_id = hexlify(urandom(x)).decode()
            ctime = int(time.time())
            t_data = {"viewer_id": v_id, "device_id": d_id, "confidence": round(uniform(y, z), 2), "iat": ctime, "exp": ctime + 600}
            t_bdata = b64urlencode(json_dumps(t_data), strip=True)
            t_sig = b64urlencode(sha256(t_bdata.encode()).digest(), strip=True)
            token = "{0}.{1}".format(t_bdata, t_sig)
            t_data.update({"token": token})
            t_data.pop("iat")
            t_data.pop("exp")
            return {"fingerprint": t_data}

        def ft(e):
            t = e.replace("-", "+").replace("_", "/")
            r = 0 if len(t) % 4 == 0 else 4 - len(t) % 4
            n = t + "=" * r
            return base64.b64decode(n)

        def xn(e, v):
            if v:
                v = int(v)
                e = [e[v - 1], e[len(e) - v]]
            t = list(map(ft, e))
            return b"".join(t)

        def fh(v):
            return b64urlencode(sha256(str(v).encode("ascii")).digest(), strip=True)

        def wn(challenge):
            sk = ECDSA_SigningKey.generate(curve=ECDSA_NIST256p, hashfunc=sha256)
            vk = sk.verifying_key.to_string()
            nonce = str(challenge.get("nonce") or "")
            signature = sk.sign(nonce.encode(), hashfunc=sha256)
            pub = {"crv": "P-256", "ext": True, "key_ops": ["verify"], "kty": "EC", "x": b64urlencode(vk[:32], strip=True), "y": b64urlencode(vk[32:], strip=True)}
            r = uniform(0, 1)
            return {
                "viewer_id": "", "device_id": "", "challenge_id": challenge.get("challenge_id", ""), "nonce": nonce,
                "signature": b64urlencode(signature, strip=True), "public_key": pub,
                "client": {
                    "user_agent": UA, "architecture": "arm", "bitness": "32", "platform": "Android", "platform_version": "10.0.0",
                    "model": "TX6s", "ua_full_version": "137.0.7337.0",
                    "brand_full_versions": [{"brand": "Chromium", "version": "137.0.7337.0"}],
                    "pixel_ratio": 1, "screen_width": 1280, "screen_height": 720, "color_depth": 24,
                    "languages": ["en-US"], "timezone": "America/New_York", "hardware_concurrency": 4, "device_memory": 2,
                    "touch_points": 1, "webgl_vendor": "Google Inc. (ARM)", "webgl_renderer": "ANGLE (ARM, Mali-G31 MP2, OpenGL ES 3.2)",
                    "canvas_hash": fh(r), "audio_hash": fh(r + 1), "webgl_params_hash": fh(r + 2), "fonts_hash": fh(r + 3), "codecs_hash": fh(r + 4),
                    "media_devices": "ai1ao1vi4", "pointer_type": "coarse",
                    "extra": {"vendor": "Google Inc.", "appVersion": UA[len("Mozilla/"):]},
                },
                "storage": {}, "attributes": {"entropy": "high"},
            }

        def rotl32(t, e):
            m = 0xFFFFFFFF
            return ((t << e) | (t >> (32 - e))) & m

        def ye(t):
            m = 0xFFFFFFFF
            t[0] = (t[0] + t[1]) & m
            t[3] = rotl32(t[3] ^ t[0], 16)
            t[2] = (t[2] + t[3]) & m
            t[1] = rotl32(t[1] ^ t[2], 12)
            t[0] = (t[0] + t[1]) & m
            t[3] = rotl32(t[3] ^ t[0], 8)
            t[2] = (t[2] + t[3]) & m
            t[1] = rotl32(t[1] ^ t[2], 7)

        def gr(t):
            m = 0xFFFFFFFF
            e = [1779033703, 3144134277, 1013904242, 2773480762]
            be, lt, dr, lr, hr = 512, 511, 2, 2654435761, 2246822519
            for i in t:
                e[0] = (e[0] + i) & m
                e[0] = rotl32(e[0], 7)
                ye(e)
            for _i in range(8):
                ye(e)
            r = [0] * be
            for i in range(be):
                ye(e)
                r[i] = (e[0] ^ e[2]) & m
            for _i in range(dr):
                for s in range(be):
                    a = r[s] & lt
                    c = (r[s] + r[a]) & m
                    c = rotl32(c, 13)
                    c = (c ^ ((r[(s + 1) & lt] * lr) & m)) & m
                    r[s] = c
                    e[0] = (e[0] ^ c) & m
                    ye(e)
            n = [0] * 8
            o = be // 8
            for i in range(8):
                ye(e)
                s = e[0]
                a = i * o
                for c in range(o):
                    d = r[a + c]
                    s = (s + d) & m
                    s = rotl32(s, 5)
                    s = (s ^ ((d * hr) & m)) & m
                n[i] = (s ^ e[2]) & m
            return n

        def wr(t):
            e = 0
            for n in t:
                if n == 0:
                    e += 32
                    continue
                return e + (32 - n.bit_length())
            return e

        def er(t, e, timeout=20.0):
            if e <= 0:
                return "0"
            start = time.time()
            s = 0
            t = t + ":"
            while True:
                for _i in range(1024):
                    d = gr((t + str(s)).encode("ascii"))
                    if wr(d) >= e:
                        return str(s)
                    s += 1
                if time.time() - start > timeout:
                    return None

        def statusCode(data, sts):
            try:
                code = getattr(data, "meta", {}).get("status_code")
                if code:
                    return code
            except Exception:
                pass
            return 200 if sts else 0

        def tryJson(data):
            try:
                return json_loads(data)
            except Exception:
                return None

        baseUrl = baseUrl.replace("/d/", "/e/")
        printDBG("parserBYSE baseUrl[%s]" % baseUrl)
        urltab = []
        for redirectDomain in ["boosteradx.online", "byse.sx", "streamlyplayer.online"]:
            baseUrl = baseUrl.replace(redirectDomain, "streamlyplayero.online")
        ref = urlparser.getDomain(baseUrl, False)
        mid = re.search(r"/(?:e|d|download)/([0-9a-zA-Z]+)", baseUrl).group(1)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["User-Agent"] = UA
        HTTP_HEADER["Referer"] = ref
        HTTP_HEADER["Origin"] = ref[:-1]

        embed = ""
        detailsUrl = "%sapi/videos/%s/details" % (ref, mid)
        sts, data = self.cm.getPage(detailsUrl, {"header": dict(HTTP_HEADER)})
        details = tryJson(data) if sts else None
        if details is None or statusCode(data, sts) == 404:
            embed = "embed/"
            detailsUrl = "%sapi/videos/%s/%sdetails" % (ref, mid, embed)
            sts, data = self.cm.getPage(detailsUrl, {"header": dict(HTTP_HEADER)})
            if not sts:
                return []
            details = tryJson(data)
            if details is None:
                return []

        embedUrl = details.get("embed_frame_url")
        if embedUrl:
            ref = urlparser.getDomain(embedUrl, False)
            HTTP_HEADER["X-Embed-Parent"] = baseUrl
            HTTP_HEADER["Referer"] = ref
            HTTP_HEADER["Origin"] = ref[:-1]

        settingsUrl = "%sapi/videos/%s/%ssettings" % (ref, mid, embed)
        sts, data = self.cm.getPage(settingsUrl, {"header": dict(HTTP_HEADER)})
        settings = tryJson(data) if sts else None
        if settings is None:
            settings = {}

        if settings.get("captcha_required"):
            challengeUrl = "%sapi/videos/access/challenge" % ref
            sts, data = self.cm.getPage(challengeUrl, {"header": dict(HTTP_HEADER), "raw_post_data": True, "timeout": 40}, "")
            challenge = tryJson(data) if sts else None
            if challenge is None:
                return []

            attestUrl = "%sapi/videos/access/attest" % ref
            sts, data = self.cm.getPage(attestUrl, {"header": dict(HTTP_HEADER), "raw_post_data": True, "timeout": 40}, json_dumps(wn(challenge)))
            attest = tryJson(data) if sts else None
            if attest is None:
                return []
            fingerprint = {"token": attest.get("token"), "viewer_id": attest.get("viewer_id"), "device_id": attest.get("device_id"), "confidence": attest.get("confidence")}

            captchaUrl = "%sapi/videos/%s/%scaptcha" % (ref, mid, embed)
            sts, data = self.cm.getPage(captchaUrl, {"header": dict(HTTP_HEADER), "raw_post_data": True, "timeout": 40}, json_dumps({"fingerprint": fingerprint}))
            captcha = tryJson(data) if sts else None
            if captcha is None:
                return []
            solution = er(captcha.get("pow_nonce", ""), captcha.get("pow_difficulty", 0), timeout=45.0)
            if solution is None:
                return []

            verifyUrl = "%sapi/videos/%s/%scaptcha/verify" % (ref, mid, embed)
            verifyPost = {"pow_token": captcha.get("pow_token"), "solution": solution, "fingerprint": fingerprint}
            sts, data = self.cm.getPage(verifyUrl, {"header": dict(HTTP_HEADER), "raw_post_data": True, "timeout": 40}, json_dumps(verifyPost))
            verify = tryJson(data) if sts else None
            if verify is None:
                return []
            HTTP_HEADER["X-Captcha-Token"] = verify.get("token", "")

            playbackUrl = "%sapi/videos/%s/%splayback" % (ref, mid, embed)
            sts, data = self.cm.getPage(playbackUrl, {"header": dict(HTTP_HEADER), "raw_post_data": True, "timeout": 40}, json_dumps({"fingerprint": fingerprint}))
        else:
            playbackUrl = "%sapi/videos/%s/%splayback" % (ref, mid, embed)
            sts, data = self.cm.getPage(playbackUrl, {"header": dict(HTTP_HEADER), "raw_post_data": True}, json_dumps(fp(16, 0.83, 0.94)))
        if not sts:
            return []

        html = tryJson(data)
        if html is None:
            return []
        sources = html.get("sources")
        if not sources:
            pd = html.get("playback")
            if pd:
                iv = ft(pd.get("iv"))
                key = xn(pd.get("key_parts"), pd.get("version"))
                pl = ft(pd.get("payload"))
                cipher = python_aesgcm.new(key)
                ct = cipher.open(iv, pl)
                html = json_loads(ct.decode("latin-1"))
                sources = html.get("sources")
        if sources:
            for x in sources:
                url = urlparser.decorateUrl(x.get("url"), {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": ref, "Origin": ref[:-1]})
                if ".m3u8" in url:
                    urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
                else:
                    urltab.append({"name": x.get("label", ""), "url": url})
        return urltab

    def parserDRAKKAR(self, baseUrl):  # add 250826
        def xd(enc, key):
            r = []
            for i in range(len(enc)):
                if isinstance(enc[i], int):
                    r.append(chr(enc[i] ^ key[i % len(key)]))
                else:
                    r.append(format(int(enc[i], 16) ^ int(key[i % len(key)], 16), "x"))
            return "".join(r)

        def wc(seed, ch):
            return sha256((seed + ch).encode("utf-8")).hexdigest()[:16]

        def stdB64Decode(s):
            s = s + "=" * (-len(s) % 4)
            return base64.b64decode(s)

        def aesCbcDecrypt(cipherBytes, ivHex, key):
            try:
                decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, unhexlify(ivHex)))
                decrypted = decrypter.feed(cipherBytes)
                decrypted += decrypter.feed()
                return decrypted.decode()
            except Exception:
                return None

        printDBG("parserDRAKKAR baseUrl[%s]" % baseUrl)
        urltab = []
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, html = self.cm.getPage(baseUrl, {"header": dict(HTTP_HEADER)})
        if not sts:
            return []
        m = re.search(r"\(function\(\){\s*(var.+?)\s*var\s*_cr.+?_ept\s*=\s*'([^']+).+?_ws\s*=\s*'([^']+)", html, re.DOTALL)
        if not m:
            return []
        varsBlock, ept, ws = m.group(1), m.group(2), m.group(3)
        if "fromCharCode" in varsBlock:
            s = re.findall(r"=\s*(\[[^;]+)", varsBlock)
            if not s:
                return []
            if len(s) == 2:
                cr = xd(literal_eval(s[0]), literal_eval(s[1]))
            else:
                t = int(varsBlock[:-2].split("]")[-1])
                cr = "".join([chr(i + t) for i in literal_eval(s[0])])
        else:
            s = re.findall(r"=((?:atob\()?'[^']+)", varsBlock)
            if len(s) < 2:
                return []
            if "atob(" in s[0]:
                cr = stdB64Decode(s[0].split("'")[-1]).decode("latin-1") + stdB64Decode(s[1].split("'")[-1]).decode("latin-1")
            else:
                cr = s[0].split("'")[-1][::-1] + s[1].split("'")[-1][::-1]

        ts = int(time.time() * 1000)
        time.sleep(1.5)
        ref = urlparser.getDomain(baseUrl, False)
        postData = {
            "cr": cr,
            "pt": xd(ept, cr),
            "wc": wc(ws, cr),
            "_ts2": int(time.time() * 1000) - randint(100, 500),
            "bs": {"ts": ts, "sw": 1280, "sh": 720, "plt": "", "tz": 240, "lang": "en-US", "pl": "", "ct": 4, "dm": 24, "td": 0, "cv": 1, "wg": 1},
        }
        HTTP_HEADER["Referer"] = ref
        HTTP_HEADER["Origin"] = ref[:-1]
        streamUrl = baseUrl.split("?")[0].rstrip("/") + "/stream"
        sts, data = self.cm.getPage(streamUrl, {"header": HTTP_HEADER, "raw_post_data": True}, json_dumps(postData))
        if not sts:
            return []
        try:
            res = json_loads(data)
        except Exception:
            return []
        if not (res.get("s") and res.get("d") and res.get("x")):
            return []
        key = sha256((str(res.get("p1", "")) + str(res.get("p2", "")) + str(res.get("p3", "")) + str(res.get("p4", "")) + cr + str(res.get("x", ""))).encode()).digest()
        payload = aesCbcDecrypt(stdB64Decode(res.get("d", "")), res.get("v", ""), key)
        if not payload:
            return []
        try:
            pdata = json_loads(payload)
        except Exception:
            return []
        playerHtml = ""
        epd = pdata.get("encrypted_player_data")
        if epd and epd.get("ct"):
            simpleKey = unhexlify(str(epd.get("k1", "")) + str(epd.get("k2", "")) + str(epd.get("k3", "")) + str(epd.get("k4", "")))
            if len(simpleKey) in [16, 24, 32]:
                playerHtml = aesCbcDecrypt(stdB64Decode(epd.get("ct", "")), epd.get("iv", ""), simpleKey) or ""
        elif pdata.get("processed_template"):
            playerHtml = pdata.get("processed_template")
        if not playerHtml:
            return []
        videoSrc = re.search(r"videoSrc:\s*'([^']+)", playerHtml)
        if not videoSrc:
            return []
        urlMeta = {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": ref, "Origin": ref[:-1]}
        subTracks = []
        subBlock = re.search(r"subtitles:\s*(\[.+?\])\s*,", playerHtml, re.DOTALL)
        if subBlock:
            try:
                for sub in json_loads(subBlock.group(1)):
                    src = sub.get("src") or sub.get("file") or sub.get("url")
                    if src:
                        subTracks.append({"title": "", "url": src, "lang": sub.get("lang") or sub.get("label") or ""})
            except Exception:
                pass
        if subTracks:
            urlMeta["external_sub_tracks"] = subTracks
        url = urlparser.decorateUrl(videoSrc.group(1), urlMeta)
        urltab.append({"name": "Drakkar", "url": url})
        return urltab

    def parserCOUDMAILRU(self, baseUrl):  # Fix 221125
        printDBG("parserCOUDMAILRU baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        urltab = []
        host = urlparser.getDomain(baseUrl, False)
        m = re.search(r'"weblink"\s*:\s*"([^"]+?)"', data)
        r = re.search(r'1","url":"([^"]+)"[^>],"view', data)
        if r and m:
            b = base64.b64encode(m.group(1).encode("utf-8")).decode("utf-8")
            url = "%s/0p/%s.m3u8?double_encode=1" % (r.group(1), b)
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
            urltab.extend(getDirectM3U8Playlist(url))
        return urltab

    def parserJWPLAYER(self, baseUrl):  # update 170126
        def jw_hidden(html, url):
            domain = urlparser.getDomain(url, False)[:-1]
            mediaid = url.rstrip(".html").split("/")[-1].split("-")[-1]
            forms = {}
            for form in re.finditer(r"<form[^>]*>(.*?)</form>", html, re.DOTALL | re.I):
                purl = re.search(r'action\s*=\s*[\'"]([^\'"]+)', form.group(0))
                for field in re.finditer(r'type=[\'"]?(hidden|submit)[\'"]?[^>]*>', form.group(1)):
                    name = re.search(r'name\s*=\s*[\'"]([^\'"]+)', field.group(0))
                    value = re.search(r'value\s*=\s*[\'"]([^\'"]*)', field.group(0))
                    if name and value:
                        name = name.group(1)
                        value = value.group(1)
                        if name == "file_code" and value == "":
                            value = mediaid
                        forms[name] = value
                if purl:
                    purl = purl.group(1)
                    if purl.startswith("/"):
                        purl = domain + purl
                    if purl and forms:
                        GetIPTVSleep().Sleep(6)
                        sts, data = self.cm.getPage(purl, urlParams, forms)
                        if sts:
                            return data
            return ""

        printDBG("parserJWPLAYER baseUrl[%s]" % baseUrl)
        urltab = []
        COOKIE_FILE = GetCookieDir("%s.cookie" % urlparser.getDomain(baseUrl))
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl.meta.get("Referer", urlparser.getDomain(baseUrl, False))
        urlParams = {"header": HTTP_HEADER, "use_cookie": True, "load_cookie": True, "save_cookie": True, "cookiefile": COOKIE_FILE}
        if "mxdrop" in baseUrl or "mixdro" in baseUrl or "mixdrp" in baseUrl or "m1xdrop" in baseUrl:
            baseUrl = baseUrl.replace(".co/", ".ag/").replace(".club/", ".ag/")
            baseUrl = "/".join(baseUrl.split("/")[:5]).replace("/f/", "/e/") if "/f/" in baseUrl else baseUrl
        if "hglink.to" in baseUrl:
            baseUrl = baseUrl.replace("hglink.to", "dumbalag.com")
        if "cybervynx.com" in baseUrl:
            baseUrl = baseUrl.replace("cybervynx.com", "guxhag.com")
        if "savefiles.com/" in baseUrl:
            baseUrl = baseUrl.replace("/v/", "/").replace("/e/", "/")
            if "/d/" in baseUrl:
                baseUrl = baseUrl.replace("/d/", "/").replace("_n", "")
        if "streamwish.to" in baseUrl:
            baseUrl = baseUrl.replace("streamwish.to", "hglamioz.com")
        if "rubyvidhub.com" in baseUrl or "rubystm.com" in baseUrl or "streamruby" in baseUrl:
            HTTP_HEADER.pop("Referer", None)  # embed is refused ("restricted for this domain") whenever a Referer is sent
        if "dropload." in baseUrl:
            baseUrl = re.sub(r"dropload\.co/embed-([^./]+)\.html", r"dr0pstream.com/e/\1", baseUrl)
            baseUrl = baseUrl.replace("dropload.tv", "dr0pstream.com").replace("dropload.io", "dr0pstream.com")
        sts, data = self.cm.getPage(baseUrl, urlParams)
        if not sts:
            return []
        if "p,a,c,k,e" not in data and "mp4" not in data and "m3u8" not in data:
            src = re.search(r'(?:data-embed|iframe\s+src)="([^"]+)"', data)
            if src:
                sts, data = self.cm.getPage(src.group(1), urlParams)
                if not sts:
                    return []
            elif "<form" in data:
                data = jw_hidden(data, baseUrl)
        if "function(p,a,c,k,e" in data:
            data = get_packed_data(data)
            if not data:
                return []
        host = urlparser.getDomain(baseUrl, False)
        url = re.search(r"""["']((?:https?:)?//[^'^"]+?\.(?:mp4|m3u8|mkv)(?:\?[^"^']+?)?)["']""", data)
        if not url:
            url = re.search(r"""file":"([^"]+)""", data)
        subTracks = []
        sub = re.findall(r"""{\s*file:\s*["']([^"']+)["'],\s*label:\s*["']([^"']+)["'],\s*kind:\s*["'](?:captions|subtitles)["']""", data)
        if not sub:
            sub = re.findall(r"""file_path":"([^"]+)","language":"([^"]+)""", data)
        if sub:
            for src, label in sub:
                src = src.replace(r"\/", "/")
                subTracks.append({"title": "", "url": "https:" + src if src.startswith("//") else src, "lang": label})
        if url:
            url = url.group(1)
            url = "https:" + url if url.startswith("//") else url
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks})
            if ".m3u8" in url:
                urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
            elif ".mpd" in url:
                urltab.extend(getMPDLinksWithMeta(url))
            else:
                urltab.append({"name": "MP4", "url": url})
        return urltab

    def parserOKRU(self, baseUrl):  # Fix 061225
        printDBG("parserOKRU baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        urltab = []
        match = re.search(r'data-options="([^"]+)', data)
        if match:
            match = match.group(1).replace("&quot;", '"').replace("&amp;", "&")
            js = json_loads(match).get("flashvars", {}).get("metadata")
            js = json_loads(js)
            url = js.get("hlsManifestUrl") or js.get("ondemandHls") or js.get("hlsMasterPlaylistUrl")
            if url:
                url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
                urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
        return urltab

    def parserVIDSRC(self, baseUrl):  # add 171225
        printDBG("parserVIDSRC baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        urltab = []
        baseUrl = baseUrl.replace("vidsrc.to", "vidsrc.xyz").replace("vidsrc.pm", "vidsrc.xyz").replace("moviesapi.club/movie", "cdn.moviesapi.to/embed/movie").replace("moviesapi.to/movie", "cdn.moviesapi.to/embed/movie")
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        url = re.search(r"""src=['"]([^"]+)['"] f""", data)
        if not url:
            return []
        url = url.group(1)
        url = "https:" + url if url.startswith("//") else url
        host = urlparser.getDomain(url, False)
        sts, data = self.cm.getPage(url, {"header": HTTP_HEADER})
        if not sts:
            return []
        HTTP_HEADER["Referer"] = url
        url = re.search(r""" src: ['"]([^'"]+)""", data)
        if not url:
            return []
        url = host[:-1] + url.group(1)
        sts, data = self.cm.getPage(url, {"header": HTTP_HEADER})
        if not sts:
            return []
        match = re.findall(r'id="([^"]+)" style="display:none;">([^<]+)', data)
        if match:
            a, b = match[0]
            d = crsdiv(b, a)
            if d:
                url = d.split(" ")[0].replace("{v1}", "thrumbleandjaxon.com")
                url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
                if ".m3u8" in url:
                    urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
        return urltab

    def parserVIDSRCMOV(self, baseUrl):  # add 240826
        printDBG("parserVIDSRCMOV baseUrl[%s]" % baseUrl)
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        inner = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', data)
        if not inner:
            return []
        innerUrl = inner.group(1)
        innerUrl = "https:" + innerUrl if innerUrl.startswith("//") else innerUrl
        return self.parserVIDSRC(innerUrl)

    def parserGUPLOAD(self, baseUrl):
        printDBG("parserGUPLOAD baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        urltab = []
        match = re.search(r"""decodePayload.*?['\"]([A-Za-z0-9+/=]+)['\"]""", data)
        if match:
            data = base64.b64decode(match.group(1)).decode()
            url = json_loads(data.split("|", 1)[1]).get("videoUrl")
            if url:
                url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
                urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
        return urltab

    def parserVIDSONIC(self, baseUrl):
        printDBG("parserVIDSONIC baseUrl[%s]" % baseUrl)
        urltab = []
        subTracks = []
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        match = re.search(r"""const\s+_0x1\s*=\s*'([^']+)';""", data)
        if not match:
            return []
        clean = match.group(1).replace("|", "")
        url = "".join(chr(int(clean[i: i + 2], 16)) for i in range(0, len(clean), 2))
        sub = re.search(r'data-subtitles\s*=\s*(["\'])(?P<content>.*?)\1', data)
        if sub:
            raw_content = sub.group("content").replace("&quot;", '"')
            var = re.findall(r'"lang":"([^"]+)","path":"([^"]+)', raw_content)
            for label, src in var:
                subTracks.append({"title": "", "url": "https:" + src if src.startswith("//") else src, "lang": label})
        url = urlparser.decorateUrl(url[::-1], {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks})
        urltab.extend(getDirectM3U8Playlist(url))
        return urltab

    def parserVIXEO(self, baseUrl):  # add 020926 - vixeo.io (filmpalast "Vixeo HD"), a vidsonic.net front
        printDBG("parserVIXEO baseUrl[%s]" % baseUrl)
        urltab = []
        subTracks = []
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        m = re.search(r'data-config=(["\'])([A-Za-z0-9+/=_-]+)\1', data)
        if not m:
            return []
        blob = m.group(2).replace("-", "+").replace("_", "/").rstrip("=")
        try:
            cfg = json_loads(base64.b64decode(blob + "=" * (-len(blob) % 4)).decode())
        except Exception:
            printExc()
            return []
        # cfg["source"] is "|"-separated hex; concatenated, hex-decoded and byte-reversed it yields the stream url
        src = str(cfg.get("source", "") or "").replace("|", "")
        if not src:
            return []
        url = "".join(chr(int(src[i:i + 2], 16)) for i in range(0, len(src), 2))[::-1]
        for sub in (cfg.get("subtitles") or []):
            surl = sub.get("url") or sub.get("src") or sub.get("file") or ""
            if surl:
                subTracks.append({"title": "", "url": "https:" + surl if surl.startswith("//") else surl, "lang": sub.get("label") or sub.get("lang") or ""})
        url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks})
        if ".m3u8" in url:
            urltab.extend(getDirectM3U8Playlist(url))
        else:
            urltab.append({"name": "MP4", "url": url})
        return urltab

    def parserVIDCLOUD(self, baseUrl):  # add 280126
        printDBG("parserVIDCLOUD baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        url = baseUrl.split("?")[0].rsplit("/", 1)
        sts, data = self.cm.getPage("%s/getSources?id=%s" % (url[0], url[1]), {"header": HTTP_HEADER})
        if not sts:
            return []
        urltab = []
        subTracks = []
        js = json_loads(data)
        if not js.get("encrypted"):
            for s in js.get("tracks"):
                if s.get("file") and s.get("label"):
                    subTracks.append({"title": "", "url": s.get("file"), "lang": s.get("label")})
            for x in js.get("sources"):
                url = urlparser.decorateUrl(x.get("file"), {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks})
                urltab.extend(getDirectM3U8Playlist(url))
        return urltab

    def parserCOVERAPI(self, baseUrl):  # update 270226
        printDBG("parserCOVERAPI baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Accept-Language"] = "el,en-US;q=0.9,en;q=0.8"
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        news_id = re.search(r"news_id':'(\d+)'", data)
        if news_id:
            mod = "players3" if "player3" in data else "players"
            postdata = {"mod": mod, "news_id": news_id.group(1)}
            HTTP_HEADER["Referer"] = baseUrl
            sts, data = self.cm.getPage("%sengine/ajax/controller.php" % host, {"header": HTTP_HEADER}, postdata)
            if not sts:
                return []
            js = json_loads(data)
            if js.get("file"):
                url = js.get("file").split(" or ")[0]
                if "playlist" in url:
                    sts, data = self.cm.getPage(url, {"header": HTTP_HEADER})
                    if not sts:
                        return []
                    js = json_loads(data)
                    if js.get("playlist"):
                        js = js.get("playlist")[0]
                        for p in js.get("playlist", []):
                            if p.get("comment", "").endswith(baseUrl.meta.get("Episode")):
                                url = p.get("file")
            return urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
        return []

    def parserMEGAFILES(self, baseUrl):  # update 270226
        printDBG("parserMEGAFILES baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        urltab = []
        subTracks = []
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        var = re.findall(r'var\s+(\w+)\s*=\s*"([^"]*)"', data)
        if var:
            ids = dict(var)
            mid = ids.get("movieId")
            user_id = "zh&72ciO39tgH5" + "_" + ids.get("userId")
            vrf = generate_vrf(mid, user_id)
            url = "%sapi/%s/servers?id=%s&type=%s&v=%s&vrf=%s&imdbId=%s" % (host, mid, mid, ids.get("movieType"), ids.get("v"), vrf, ids.get("imdbId", "null"))
            var = re.findall(r"var\s+(\w+)\s*=\s*(\d+);", data)
            if var:
                tv = dict(var)
                url += "&season=%s&episode=%s" % (tv.get("season"), tv.get("episode"))
            sts, data = self.cm.getPage(url, {"header": HTTP_HEADER})
            if not sts:
                return []
            js = json_loads(data).get("data")
            url = "%sapi/source/%s" % (host, js[0].get("hash"))
            sts, data = self.cm.getPage(url, {"header": HTTP_HEADER})
            if not sts:
                return []
            js = json_loads(data).get("data")
            if isinstance(js.get("subtitles"), list):
                subTracks = [{"title": "", "url": sub.get("file"), "lang": sub.get("label")} for sub in js.get("subtitles", []) if sub.get("file") and sub.get("label")]
            url = urlparser.decorateUrl(js.get("source"), {"User-Agent": HTTP_HEADER["User-Agent"], "Accept": "*/*", "Referer": host, "Origin": host[:-1], "external_sub_tracks": subTracks})
            urltab.extend(getDirectM3U8Playlist(url))
        return urltab

    def parserVIXSRC(self, baseUrl):  # fix 300526
        printDBG("parserVIXSRC baseUrl[%s]" % baseUrl)
        urltab = []
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = baseUrl.meta.get("Referer", host)
        sts, data = self.cm.getPage(baseUrl.replace(host, host + "api/"), {"header": HTTP_HEADER})
        if not sts:
            return []
        src = json_loads(data).get("src", "")
        if src.startswith("/"):
            src = host[:-1] + src
        HTTP_HEADER["Referer"] = host
        HTTP_HEADER["Upgrade-Insecure-Requests"] = "1"
        sts, data = self.cm.getPage(src, {"header": HTTP_HEADER})
        if not sts:
            return []
        tok = re.search(r"token':\s*'([^']+)", data)
        exp = re.search(r"expires':\s*'([^']+)", data)
        hurl = re.search(r"url:\s*'([^']+)", data)
        if not all([tok, exp, hurl]):
            return []
        url = "%s%s&token=%s&expires=%s&h=1" % (hurl.group(1), "&" if "?" in hurl.group(1) else "?", tok.group(1), exp.group(1))
        if "?lang=it" in baseUrl:
            url += "&lang=it"
        if url.startswith("/"):
            url = host + url
        url = strwithmeta(url, {"iptv_proto": "m3u8", "User-Agent": HTTP_HEADER["User-Agent"], "Referer": src, "Accept": "*/*"})
        urltab.extend(getDirectM3U8Playlist(url, checkExt=False, variantCheck=False, sortWithMaxBitrate=99999999))
        return urltab

    def parserFLYFILE(self, baseUrl):  # add 030626
        printDBG("parserFLYFILE baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER['Referer'] = baseUrl  # FIX: Added
        HTTP_HEADER['Origin'] = host[:-1] if host.endswith('/') else host  # FIX: Added
        mid = baseUrl.split("?")[0].split("/")[-1]
        sts, data = self.cm.getPage("https://api.%s/api/streaming/assign/%s" % (urlparser.getDomain(baseUrl), mid), {"header": HTTP_HEADER})
        if not sts:
            return []
        data = json_loads(data)
        urltab = []
        if data.get("url") and data.get("token"):
            url = "%s/hls/%s/master.m3u8" % (data["url"].rstrip("/"), data["token"])
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
            urltab.extend(getDirectM3U8Playlist(url))
        return urltab

    def parserANONMP4(self, baseUrl):  # fix 050626
        printDBG("parserANONMP4 baseUrl[%s]" % baseUrl)
        urltab = []
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER['Referer'] = baseUrl  # FIX: Added
        HTTP_HEADER['Origin'] = host[:-1] if host.endswith('/') else host  # FIX: Added
        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        url = re.search(r"fetch\('(https://cryoapi\.shadowapi\.skin/load/[^']+)'\)", data)  # FIX: Changed from SINGLE_API_URL
        if url:
            HTTP_HEADER.update({"Referer": host, "Origin": host[:-1]})
            sts, data = self.cm.getPage(url.group(1), {"header": HTTP_HEADER})
            if not sts:
                return []
            js = json_loads(data)
            if "tracks" in js:
                for x in js.get("tracks", []):
                    name = "[%s] " % x.get("track_name", "unk")
                    sts, data = self.cm.getPage(x.get("track_url"), {"header": HTTP_HEADER})
                    if not sts:
                        continue
                    js = json_loads(data)
                    url = urlparser.decorateUrl(js.get("hls"), {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
                    for p in getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999):  # Add language
                        p["name"] = name + p.get("name", "")
                        urltab.append(p)
            else:
                url = urlparser.decorateUrl(js.get("hls"), {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": host, "Origin": host[:-1]})
                urltab.extend(getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999))
        return urltab

    def parserVIDROCK(self, baseUrl):  # add 030926 - vidrock.net (7reels "AdRock"); per-server AES-256-GCM blobs from a plain JSON API
        printDBG("parserVIDROCK baseUrl[%s]" % baseUrl)
        m = re.search(r"vidrock\.net/(?:api/)?(movie/\d+|tv/\d+/\d+/\d+)", baseUrl)
        if not m:
            return []
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = "https://vidrock.net/"
        sts, data = self.cm.getPage("https://vidrock.net/api/" + m.group(1), {"header": HTTP_HEADER})
        if not sts:
            return []
        try:
            servers = json_loads(data)
        except Exception:
            printExc()
            return []
        cipher = python_aesgcm.new(unhexlify("7f3e9c2a8b5d1f4e6a9c3b7d2e5f8a1c4b6d9e2f5a8c1b4d7e9f2a5c8b1d4e7f"))
        urltab = []
        for name, info in servers.items():
            enc = (info or {}).get("url")
            if not enc:
                continue
            try:
                blob = base64.b64decode(enc.replace("-", "+").replace("_", "/") + "=" * (-len(enc) % 4))
                plain = cipher.open(blob[:12], blob[12:])
            except Exception:
                printExc()
                continue
            if not plain:
                continue
            url = ensure_str(plain).strip()
            if not url.startswith("http"):
                continue
            url = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": "https://vidrock.net/", "Origin": "https://vidrock.net"})
            if ".m3u8" in url:
                for item in getDirectM3U8Playlist(url, sortWithMaxBitrate=99999999):
                    item["name"] = "%s %s" % (name, item.get("name", ""))
                    urltab.append(item)
            else:
                urltab.append({"name": name, "url": url})
        return urltab

    def parserVIDNEO(self, baseUrl):  # fix 060726
        printDBG("parserVIDNEO baseUrl[%s]" % baseUrl)
        host = urlparser.getDomain(baseUrl, False)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER['Referer'] = baseUrl
        HTTP_HEADER['Origin'] = host[:-1] if host.endswith('/') else host

        sts, data = self.cm.getPage(baseUrl, {"header": HTTP_HEADER})
        if not sts:
            return []

        urltab = []
        r = re.search(r'({\\"src.+})]}]', data)
        if r:
            try:
                json_str = r.group(1).replace('\\', '')
                jd = json_loads(json_str)
                src = jd.get('src')

                if src:
                    if src.startswith('/'):
                        src = "https://%s%s" % (urlparser.getDomain(baseUrl), src)

                    url = urlparser.decorateUrl(src, {
                        "User-Agent": HTTP_HEADER["User-Agent"],
                        "Referer": baseUrl,
                        "Origin": host[:-1] if host.endswith('/') else host
                    })

                    if '.m3u8' in url.lower():
                        urltab.extend(getDirectM3U8Playlist(url))
                    else:
                        urltab.append({'name': 'VidNeo Direct', 'url': url, 'need_resolve': 0})
            except Exception:
                printExc()
                return []

        return urltab

    def parserVIDNEST(self, baseUrl):  # add 250826
        def vidnestB64Decode(s):
            alphabet = "RB0fpH8ZEyVLkv7c2i6MAJ5u3IKFDxlS1NTsnGaqmXYdUrtzjwObCgQP94hoeW+/="
            rev = {c: i for i, c in enumerate(alphabet)}
            s = s + "=" * ((-len(s)) % 4)
            out = bytearray()
            for i in range(0, len(s), 4):
                chunk = s[i:i + 4]
                c0 = rev.get(chunk[0], 64)
                c1 = rev.get(chunk[1], 64)
                c2 = 64 if chunk[2] == "=" else rev.get(chunk[2], 64)
                c3 = 64 if chunk[3] == "=" else rev.get(chunk[3], 64)
                out.append(((c0 << 2) | (c1 >> 4)) & 0xFF)
                if c2 != 64:
                    out.append((((c1 & 0x0F) << 4) | (c2 >> 2)) & 0xFF)
                if c3 != 64:
                    out.append((((c2 & 0x03) << 6) | c3) & 0xFF)
            return bytes(out).decode("utf-8", "replace")

        def extractLinks(server, root):
            links = []
            try:
                if server == "moviebox":
                    for item in root.get("url", []) or []:
                        if item.get("link"):
                            links.append((item["link"], item.get("resolution", "")))
                elif server in ("allmovies", "delta"):
                    for item in root.get("streams", []) or []:
                        if item.get("url"):
                            links.append((item["url"], item.get("language", "")))
                elif server == "hollymoviehd":
                    for item in root.get("sources", []) or []:
                        if item.get("file"):
                            links.append((item["file"], item.get("label", "")))
                elif server in ("purstream", "klikxxi"):
                    for item in root.get("sources", []) or []:
                        if item.get("url"):
                            links.append((item["url"], item.get("quality", item.get("name", ""))))
                elif server == "vidlink":
                    playlist = root.get("data", {}).get("stream", {}).get("playlist")
                    if playlist:
                        links.append((playlist, ""))
                elif server == "onehd":
                    if root.get("url"):
                        links.append((root["url"], ""))
            except Exception:
                printExc()
            return links

        printDBG("parserVIDNEST baseUrl[%s]" % baseUrl)
        urltab = []
        m = re.search(r"/(movie|tv)/(\d+)(?:/(\d+)/(\d+))?", baseUrl)
        if not m:
            return []
        mediaType, tmdbId, season, episode = m.group(1), m.group(2), m.group(3), m.group(4)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = "https://vidnest.fun/"
        HTTP_HEADER["Origin"] = "https://vidnest.fun"
        servers = ["moviebox", "allmovies", "catflix", "purstream", "hollymoviehd", "lamda", "flixhq", "vidlink", "onehd", "klikxxi"]
        for server in servers:
            if mediaType == "tv" and season and episode:
                apiUrl = "https://new.vidnest.fun/%s/tv/%s/%s/%s" % (server, tmdbId, season, episode)
            else:
                apiUrl = "https://new.vidnest.fun/%s/movie/%s" % (server, tmdbId)
            if server == "onehd":
                apiUrl += "?server=upcloud"
            sts, data = self.cm.getPage(apiUrl, {"header": dict(HTTP_HEADER), "timeout": 10})
            if not sts:
                continue
            try:
                resp = json_loads(data)
                payload = resp.get("data")
                if not payload:
                    continue
                if resp.get("encrypted"):
                    payload = vidnestB64Decode(payload)
                root = json_loads(payload)
            except Exception:
                continue
            for url, label in extractLinks(server, root):
                if url.startswith("//"):
                    url = "https:" + url
                decoUrl = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": "https://vidnest.fun/"})
                name = "VidNest %s" % server.capitalize()
                if label:
                    name += " %s" % label
                if ".m3u8" in url.lower():
                    for item in getDirectM3U8Playlist(decoUrl, sortWithMaxBitrate=99999999):
                        subName = item.get("name", "").replace("None", "").strip()
                        item["name"] = ("%s %s" % (name, subName)).strip()
                        urltab.append(item)
                else:
                    urltab.append({"name": name, "url": decoUrl})
        return urltab

    def parserPEACHIFY(self, baseUrl):  # add 250826
        printDBG("parserPEACHIFY baseUrl[%s]" % baseUrl)
        urltab = []
        m = re.search(r"/(movie|tv)/(\d+)(?:/(\d+)/(\d+))?", baseUrl)
        if not m:
            return []
        mediaType, tmdbId, season, episode = m.group(1), m.group(2), m.group(3), m.group(4)
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = "https://peachify.top/"
        HTTP_HEADER["Origin"] = "https://peachify.top"
        apiBase = "https://x.eat-peach.sbs"
        servers = ["moviebox", "air", "holly", "hr", "multi"]
        for server in servers:
            if mediaType == "tv" and season and episode:
                apiUrl = "%s/%s/tv/%s/%s/%s" % (apiBase, server, tmdbId, season, episode)
            else:
                apiUrl = "%s/%s/movie/%s" % (apiBase, server, tmdbId)
            sts, data = self.cm.getPage(apiUrl, {"header": dict(HTTP_HEADER), "timeout": 10})
            if not sts:
                continue
            try:
                payload = json_loads(data).get("data")
                if not payload:
                    continue
                sts2, decData = self.cm.getPage(
                    "https://enc-dec.app/api/dec-peachify",
                    {"header": {"Content-Type": "application/json"}, "raw_post_data": True, "timeout": 10},
                    json_dumps({"text": payload}),
                )
                if not sts2:
                    continue
                decResp = json_loads(decData)
                if decResp.get("status") != 200:
                    continue
                sources = decResp.get("result", {}).get("sources", [])
            except Exception:
                continue
            for src in sources or []:
                url = src.get("url")
                if not url:
                    continue
                name = "Peachify %s" % server.capitalize()
                if src.get("dub"):
                    name += " %s" % src["dub"]
                if src.get("quality"):
                    name += " %sp" % src["quality"]
                decoUrl = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": "https://peachify.top/", "Origin": "https://peachify.top"})
                if ".m3u8" in url.lower():
                    urltab.extend(getDirectM3U8Playlist(decoUrl, sortWithMaxBitrate=99999999))
                else:
                    urltab.append({"name": name, "url": decoUrl})
        return urltab

    def parserVIDEASY(self, baseUrl):  # updated 040926 - site moved its backend from api.videasy.net to api.speedracelight.com and now requires a /seed step plus a (double URL-encoded) title for sources-with-title
        printDBG("parserVIDEASY baseUrl[%s]" % baseUrl)
        urltab = []
        m = re.search(r"/(movie|tv)/(\d+)(?:/(\d+)/(\d+))?", baseUrl)
        if not m:
            return []
        mediaType, tmdbId, season, episode = m.group(1), m.group(2), m.group(3), m.group(4)

        # title/year travel as plain query params on the candidate URL itself
        # (decorateParamsFromUrl only whitelists header-ish keys into .meta, so
        # we read them back out of the raw url text here instead).
        from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote
        titleMatch = re.search(r"[?&]title=([^&]+)", baseUrl)
        yearMatch = re.search(r"[?&]year=([^&]+)", baseUrl)
        title = urllib_unquote(titleMatch.group(1)) if titleMatch else ""
        year = urllib_unquote(yearMatch.group(1)) if yearMatch else ""
        encTitle = urllib_quote(urllib_quote(title, safe=""), safe="")

        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = "https://player.videasy.to/"
        HTTP_HEADER["Origin"] = "https://player.videasy.to"

        sts0, seedData = self.cm.getPage("https://api.speedracelight.com/seed?mediaId=%s" % tmdbId, {"header": dict(HTTP_HEADER), "timeout": 10})
        if not sts0:
            return []
        try:
            seed = json_loads(seedData).get("seed")
        except Exception:
            seed = None
        if not seed:
            return []

        # server list per smy778/EncDecEndpoints samples/videasy.py, refined against
        # the live API (vsrc/meine confirmed 404 - left out)
        servers = ["cdn", "hdmovie", "m4uhd", "lamovie", "superflix"]
        for name in servers:
            apiUrl = ("https://api.speedracelight.com/%s/sources-with-title"
                      "?title=%s&mediaType=%s&year=%s&tmdbId=%s&imdbId=&episodeId=%s&seasonId=%s&enc=2&seed=%s"
                      % (name, encTitle, mediaType, year, tmdbId, episode or "1", season or "1", seed))
            sts, data = self.cm.getPage(apiUrl, {"header": dict(HTTP_HEADER), "timeout": 10})
            if not sts:
                continue
            blob = data.strip()
            if not blob or len(blob) < 10:
                continue
            sts2, decData = self.cm.getPage(
                "https://enc-dec.app/api/dec-videasy",
                {"header": {"Content-Type": "application/json"}, "raw_post_data": True, "timeout": 10},
                json_dumps({"text": blob, "id": tmdbId, "seed": seed}),
            )
            if not sts2:
                continue
            try:
                decResp = json_loads(decData)
                if decResp.get("status") != 200:
                    continue
                result = decResp.get("result", {})
            except Exception:
                continue

            sources = result.get("sources") if isinstance(result, dict) else None
            found = []
            if sources:
                for src in sources:
                    u = src.get("url")
                    if u:
                        found.append((u, src.get("quality")))
            else:
                # schema-agnostic fallback: walk the whole result for any
                # http(s) link ending up as a playable stream
                stack = [result]
                while stack:
                    node = stack.pop()
                    if isinstance(node, dict):
                        stack.extend(node.values())
                    elif isinstance(node, list):
                        stack.extend(node)
                    elif isinstance(node, basestring) and node.startswith("http") and (".m3u8" in node or ".mp4" in node):
                        found.append((node, None))

            for url, quality in found:
                itemName = "Videasy %s" % name.capitalize()
                decoUrl = urlparser.decorateUrl(url, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": "https://player.videasy.to/", "Origin": "https://player.videasy.to", "iptv_use_ffmpeg": True})
                qm = re.search(r"(\d{3,4})p", url)
                if quality or qm:
                    # this link already names its own single quality (either the
                    # API told us, or it's baked into the URL, e.g. .../s1080p-.../
                    # ...m3u8) - no need to probe the playlist to discover it.
                    itemName += " %s" % (quality or ("%sp" % qm.group(1)))
                    urltab.append({"name": itemName, "url": decoUrl})
                elif ".m3u8" in url.lower():
                    # genuine multi-variant master playlist - let the helper
                    # discover the actual qualities inside it.
                    for item in getDirectM3U8Playlist(decoUrl, sortWithMaxBitrate=99999999):
                        item["name"] = ("%s %s" % (itemName, item.get("name", ""))).strip()
                        urltab.append(item)
                else:
                    urltab.append({"name": itemName, "url": decoUrl})
        return urltab

    def parserVIDLINK(self, baseUrl):  # vidlink.pro; enc-dec.app encrypts the tmdb id, /api/b returns the sources json directly (no 2nd decrypt)
        printDBG("parserVIDLINK baseUrl[%s]" % baseUrl)
        urltab = []
        m = re.search(r"/(movie|tv)/(\d+)(?:/(\d+)/(\d+))?", baseUrl)
        if not m:
            return []
        mediaType, tmdbId, season, episode = m.group(1), m.group(2), m.group(3), m.group(4)
        api = "https://enc-dec.app/api"
        HTTP_HEADER = self.cm.getDefaultHeader()
        sts, data = self.cm.getPage("%s/enc-vidlink?%s" % (api, urllib_urlencode({"text": tmdbId})), {"header": {"User-Agent": HTTP_HEADER["User-Agent"]}})
        if not sts:
            return []
        try:
            enc = json_loads(data).get("result")
        except Exception:
            printExc()
            return []
        if not enc:
            return []
        if mediaType == "tv":
            apiUrl = "https://vidlink.pro/api/b/tv/%s/%s/%s" % (enc, season or "1", episode or "1")
        else:
            apiUrl = "https://vidlink.pro/api/b/movie/%s" % enc
        provHdr = {"User-Agent": HTTP_HEADER["User-Agent"], "Origin": "https://vidlink.pro", "Referer": "https://vidlink.pro/"}
        sts, data = self.cm.getPage(apiUrl, {"header": provHdr})
        if not sts:
            return []
        try:
            res = json_loads(data)
        except Exception:
            printExc()
            return []
        if not isinstance(res, dict):
            return []
        subTracks = []
        try:
            for c in (((res.get("stream") or {}) if isinstance(res.get("stream"), dict) else {}).get("captions") or res.get("captions") or []):
                cu = c.get("url") or c.get("file")
                if cu:
                    subTracks.append({"title": c.get("label", ""), "url": cu, "lang": c.get("language", c.get("label", ""))})
        except Exception:
            printExc()
        found = []
        stack = [res]
        seen = set()
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                stack.extend(node.values())
            elif isinstance(node, list):
                stack.extend(node)
            elif isinstance(node, basestring) and node.startswith("http") and node not in seen and (".m3u8" in node or ".mp4" in node):
                seen.add(node)
                found.append(node)
        for url in found:
            deco = {"User-Agent": provHdr["User-Agent"], "Referer": "https://vidlink.pro/", "Origin": "https://vidlink.pro", "iptv_use_ffmpeg": True}
            if subTracks:
                deco["external_sub_tracks"] = subTracks
            decoUrl = urlparser.decorateUrl(url, deco)
            if ".m3u8" in url.lower():
                for item in getDirectM3U8Playlist(decoUrl, sortWithMaxBitrate=99999999):
                    item["name"] = ("Vidlink %s" % item.get("name", "")).strip()
                    urltab.append(item)
            else:
                urltab.append({"name": "Vidlink", "url": decoUrl})
        return urltab

    def parserVIDCORE(self, baseUrl):  # vidcore.net/.io + vidup.to + vidfast.pro/.vc (shared codebase); page token -> enc-dec.app enc/dec chain
        printDBG("parserVIDCORE baseUrl[%s]" % baseUrl)
        urltab = []
        m = re.search(r"/(movie|tv)/([A-Za-z0-9]+)(?:/(\d+)/(\d+))?", baseUrl)
        if not m:
            return []
        mediaType, mid, season, episode = m.group(1), m.group(2), m.group(3), m.group(4)
        lowUrl = baseUrl.lower()
        if "vidfast" in lowUrl:
            host = "vidfast.vc" if "vidfast.vc" in lowUrl else "vidfast.pro"
            name = "vidfast"
        elif "vidup" in lowUrl:
            host, name = "vidup.to", "vidup"
        else:
            host, name = "vidcore.io", "vidcore"
        ref = "https://%s/" % host
        api = "https://enc-dec.app/api"
        HTTP_HEADER = self.cm.getDefaultHeader()
        HTTP_HEADER["Referer"] = ref
        if mediaType == "tv" and season and episode:
            pageUrl = "%stv/%s/%s/%s/" % (ref, mid, season, episode)
        else:
            pageUrl = "%smovie/%s/" % (ref, mid)
        sts, data = self.cm.getPage(pageUrl, {"header": HTTP_HEADER})
        if not sts:
            return []
        # the page carries the real request token as \"en\":\"...\"; a Firebase
        # service-worker registration on the same page also has a \"token\":\"APA91...\"
        # - prefer "en", and never hand a Firebase FCM token to the API
        token = None
        for pat in (r'\\"en\\":\\"([^\\"]+)', r'\\"token\\":\\"([^\\"]+)'):
            for cand in re.findall(pat, data):
                if cand.startswith("APA91") or len(cand) > 400:
                    continue
                token = cand
                break
            if token:
                break
        if not token:
            return []
        sts, data = self.cm.getPage("%s/enc-%s?%s" % (api, name, urllib_urlencode({"text": token})), {"header": {"User-Agent": HTTP_HEADER["User-Agent"]}})
        if not sts:
            return []
        try:
            parts = json_loads(data)["result"]
            serversUrl, streamBase, csrf = parts["servers"], parts["stream"], parts["token"]
        except Exception:
            printExc()
            return []
        provHdr = {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": ref, "X-Requested-With": "XMLHttpRequest", "X-CSRF-Token": csrf}
        sts, serversEnc = self.cm.getPage(serversUrl, {"header": provHdr, "raw_post_data": True}, "")
        if not sts:
            return []
        sts, data = self.cm.getPage("%s/dec-%s" % (api, name), {"header": {"Content-Type": "application/json"}, "raw_post_data": True}, json_dumps({"text": serversEnc}))
        if not sts:
            return []
        try:
            serverList = json_loads(data).get("result") or []
        except Exception:
            printExc()
            return []
        for srv in serverList[:10]:
            srvData = srv.get("data")
            if not srvData:
                continue
            sts, streamEnc = self.cm.getPage("%s/%s" % (streamBase, srvData), {"header": provHdr, "raw_post_data": True}, "")
            if not sts:
                continue
            sts, data = self.cm.getPage("%s/dec-%s" % (api, name), {"header": {"Content-Type": "application/json"}, "raw_post_data": True}, json_dumps({"text": streamEnc}))
            if not sts:
                continue
            try:
                res = json_loads(data)
                if res.get("status") != 200:
                    continue
                streamUrl = res.get("result", {}).get("url")
            except Exception:
                continue
            if not streamUrl:
                continue
            label = ("%s %s" % (name.capitalize(), srv.get("name", ""))).strip()
            decoUrl = urlparser.decorateUrl(streamUrl, {"User-Agent": HTTP_HEADER["User-Agent"], "Referer": ref, "Origin": ref[:-1]})
            if ".m3u8" in streamUrl:
                for item in getDirectM3U8Playlist(decoUrl, sortWithMaxBitrate=99999999):
                    item["name"] = "%s %s" % (label, item.get("name", ""))
                    urltab.append(item)
            else:
                urltab.append({"name": label, "url": decoUrl})
        # "Euro" has repeatedly been observed serving short ad clips instead of
        # the real movie on its top-quality tier (across multiple titles) - push
        # it to the back so it isn't the first thing the user tries.
        urltab.sort(key=lambda item: 1 if "euro" in item.get("name", "").lower() else 0)
        return urltab
